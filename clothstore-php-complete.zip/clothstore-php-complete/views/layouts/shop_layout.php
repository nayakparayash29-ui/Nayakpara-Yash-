<?php
/**
 * Shop Layout Wrapper
 * Global customer-facing luxury HTML layout shell
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';

// Flash messages
$flashSuccess = getFlash('success');
$flashError   = getFlash('error');
$flashInfo    = getFlash('info');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title><?= isset($pageTitle) ? e($pageTitle) . ' | ' : '' ?><?= e(APP_NAME) ?> — Modern Haute Couture & Apparel</title>
    
    <!-- Google Fonts: Cormorant Garamond, Syne, Plus Jakarta Sans & Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <!-- Base Utility Styles + Luxury Design System -->
    <link rel="stylesheet" href="<?= asset_url('/css/style.css') ?>"/>
    <link rel="stylesheet" href="<?= asset_url('/css/shop.css') ?>"/>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>✨</text></svg>">
</head>
<body class="layout-shop">
    <?php require __DIR__ . '/header.php'; ?>

    <!-- Flash message alerts -->
    <?php if ($flashSuccess): ?>
        <div class="container pt-4">
            <div class="alert alert-success flex items-center justify-between shadow-sm rounded-2xl border border-emerald-200">
                <div class="flex items-center gap-2">
                    <span class="text-base">✓</span>
                    <span><?= e($flashSuccess) ?></span>
                </div>
                <button type="button" class="btn-icon btn-ghost btn-sm" onclick="this.closest('.alert').remove()">&times;</button>
            </div>
        </div>
    <?php endif ?>
    <?php if ($flashError): ?>
        <div class="container pt-4">
            <div class="alert alert-error flex items-center justify-between shadow-sm rounded-2xl border border-rose-200">
                <div class="flex items-center gap-2">
                    <span class="text-base">⚠️</span>
                    <span><?= e($flashError) ?></span>
                </div>
                <button type="button" class="btn-icon btn-ghost btn-sm" onclick="this.closest('.alert').remove()">&times;</button>
            </div>
        </div>
    <?php endif ?>
    <?php if ($flashInfo): ?>
        <div class="container pt-4">
            <div class="alert alert-info flex items-center justify-between shadow-sm rounded-2xl border border-sky-200">
                <div class="flex items-center gap-2">
                    <span class="text-base">ℹ️</span>
                    <span><?= e($flashInfo) ?></span>
                </div>
                <button type="button" class="btn-icon btn-ghost btn-sm" onclick="this.closest('.alert').remove()">&times;</button>
            </div>
        </div>
    <?php endif ?>

    <!-- Main Page Content -->
    <main class="layout-main">
        <?php
        if (isset($viewContent) && is_string($viewContent)) {
            if (file_exists($viewContent)) require $viewContent;
            else echo $viewContent;
        }
        ?>
    </main>

    <!-- Global Quick View Modal Dialog -->
    <div id="productDialog" class="dialog-overlay hidden" data-closable="true" style="z-index: 1050;">
        <div class="dialog rounded-3xl bg-white border border-border shadow-2xl overflow-hidden animate-fade-in-scale" style="max-width: 54rem; width: 100%;">
            <div class="flex items-center justify-between px-6 py-4 border-b border-border bg-slate-50/50">
                <div class="flex items-center gap-2">
                    <span class="text-xs uppercase tracking-widest font-extrabold text-primary bg-primary/10 px-2.5 py-0.5 rounded-full">Quick Look</span>
                    <h3 id="pdTitle" class="dialog-title text-base font-bold text-foreground m-0 truncate max-w-md">Product Preview</h3>
                </div>
                <button id="pdClose" type="button" class="btn btn-ghost btn-icon rounded-full" aria-label="Close dialog" onclick="document.getElementById('productDialog').classList.add('hidden')">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
                </button>
            </div>
            <div id="pdBody" class="dialog-content p-6 max-h-[82vh] overflow-y-auto"></div>
        </div>
    </div>

    <?php require __DIR__ . '/footer.php'; ?>

    <script>window.APP_BASE = '<?= BASE_PATH ?>';</script>
    <script src="<?= asset_url('/js/app.js') ?>"></script>
    <?php if (!empty($extraScripts)) echo $extraScripts; ?>
</body>
</html>

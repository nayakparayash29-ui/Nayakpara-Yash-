<?php
/**
 * Shopping View Footer
 * Dark editorial luxury footer with categorized navigation, newsletter,
 * authenticity guarantee, and payment badges.
 */
if (!defined('APP_NAME')) require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
?>
<footer class="footer-lux">
    <div class="footer-perks">
        <div class="container footer-perks-grid">
            <div class="footer-perk">
                <span class="footer-perk-icon" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 7h13v10H3z"/><path d="M16 10h4l1 3v4h-5"/><circle cx="7" cy="18" r="1.6"/><circle cx="18" cy="18" r="1.6"/></svg>
                </span>
                <div>
                    <h5>Express Delivery</h5>
                    <p>Complimentary over ₹1,000</p>
                </div>
            </div>
            <div class="footer-perk">
                <span class="footer-perk-icon" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 12a8 8 0 0 1 13.5-5.8L20 8"/><path d="M20 4v4h-4"/><path d="M20 12a8 8 0 0 1-13.5 5.8L4 16"/><path d="M4 20v-4h4"/></svg>
                </span>
                <div>
                    <h5>7-Day Concierge</h5>
                    <p>Complimentary doorstep pickup</p>
                </div>
            </div>
            <div class="footer-perk">
                <span class="footer-perk-icon" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3l1.6 4.2L18 9l-4.4 1.8L12 15l-1.6-4.2L6 9l4.4-1.8z"/><path d="M5 16l.7 1.8L7.5 19l-1.8.7L5 21.5 4.3 19.7 2.5 19l1.8-.7z"/></svg>
                </span>
                <div>
                    <h5>100% Authentic</h5>
                    <p>Archival grade materials</p>
                </div>
            </div>
            <div class="footer-perk">
                <span class="footer-perk-icon" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6z"/><path d="M9 12l2 2 4-4"/></svg>
                </span>
                <div>
                    <h5>Encrypted Checkout</h5>
                    <p>Bank-grade 256-Bit SSL</p>
                </div>
            </div>
        </div>
    </div>

    <div class="container footer-main">
        <div class="footer-grid">
            <div class="footer-brand">
                <a href="<?= base_url('/shop/home') ?>" class="footer-logo">
                    <span class="footer-logo-mark" aria-hidden="true">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l1.8 6.2L20 10l-6.2 1.8L12 18l-1.8-6.2L4 10l6.2-1.8z"/></svg>
                    </span>
                    <span class="footer-logo-name"><?= e(APP_NAME) ?></span>
                </a>
                <p class="footer-blurb">
                    A modern clothing atelier dedicated to timeless aesthetics, mindful tailoring, and architectural silhouettes designed for your everyday lifestyle.
                </p>
                <div class="footer-subscribe">
                    <p class="footer-subscribe-label">Join The Atelier Circle</p>
                    <form data-newsletter-form class="footer-newsletter-wrap">
                        <input type="email" name="email" placeholder="Enter your email address" required class="footer-newsletter-input" aria-label="Email address"/>
                        <button type="submit" class="footer-newsletter-btn">Subscribe</button>
                    </form>
                    <p class="footer-subscribe-note">Enjoy 15% off your inaugural order &amp; early access to private seasonal sales.</p>
                </div>
            </div>

            <div class="footer-col">
                <h4 class="footer-lux-title">Collections</h4>
                <ul class="footer-links">
                    <li><a href="<?= base_url('/shop/listing') ?>">The Full Catalog</a></li>
                    <li><a href="<?= base_url('/shop/listing') ?>?category=Men">Men's Tailoring</a></li>
                    <li><a href="<?= base_url('/shop/listing') ?>?category=Women">Women's Studio</a></li>
                    <li><a href="<?= base_url('/shop/listing') ?>?category=Kids">Kids &amp; Youth</a></li>
                    <li><a href="<?= base_url('/shop/listing') ?>?category=Footwear">Footwear &amp; Sneakers</a></li>
                    <li><a href="<?= base_url('/shop/listing') ?>?category=Accessories">Accessories Edit</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4 class="footer-lux-title">Client Services</h4>
                <ul class="footer-links">
                    <li><a href="<?= base_url('/shop/about') ?>">The Atelier Story</a></li>
                    <li><a href="<?= base_url('/shop/account?tab=orders') ?>">Track Active Order</a></li>
                    <li><a href="<?= base_url('/shop/policies/shipping') ?>">Shipping &amp; Delivery</a></li>
                    <li><a href="<?= base_url('/shop/policies/returns') ?>">Returns &amp; Exchanges</a></li>
                    <li><a href="<?= base_url('/shop/policies/privacy') ?>">Privacy Policy</a></li>
                    <li><a href="<?= base_url('/shop/policies/terms') ?>">Terms of Service</a></li>
                    <li><a href="<?= base_url('/shop/contact') ?>">Concierge Helpdesk</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4 class="footer-lux-title">Concierge</h4>
                <ul class="footer-contact">
                    <li>
                        <span class="footer-contact-icon" aria-hidden="true">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6.5 3.5l2.2 4.2-1.6 1a12 12 0 0 0 6.2 6.2l1-1.6 4.2 2.2-1.2 2.4A2 2 0 0 1 15.5 19 16 16 0 0 1 5 8.5a2 2 0 0 1 1.5-1.8z"/></svg>
                        </span>
                        <a href="tel:+919876543210">+91 98765 43210</a>
                    </li>
                    <li>
                        <span class="footer-contact-icon" aria-hidden="true">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 7 9-7"/></svg>
                        </span>
                        <a href="mailto:concierge@clothstore.com">concierge@clothstore.com</a>
                    </li>
                    <li>
                        <span class="footer-contact-icon" aria-hidden="true">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.2"/></svg>
                        </span>
                        <span>123 Fashion Atelier, CG Road, Ahmedabad, Gujarat 380009</span>
                    </li>
                    <li>
                        <span class="footer-contact-icon" aria-hidden="true">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8"/><path d="M12 8v4.5l3 2"/></svg>
                        </span>
                        <span>Mon — Sat: 10:00 AM — 7:00 PM IST</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <div class="container footer-bottom-inner">
            <p>&copy; <?= date('Y') ?> <?= e(APP_NAME) ?> Atelier Pvt. Ltd. All rights reserved.</p>
            <div class="footer-pay">
                <span>Certified Secure Checkout:</span>
                <div class="footer-pay-badges" aria-label="Accepted payment methods">
                    <span class="pay-badge">VISA</span>
                    <span class="pay-badge">MC</span>
                    <span class="pay-badge">UPI</span>
                    <span class="pay-badge">RuPay</span>
                </div>
            </div>
        </div>
    </div>
</footer>

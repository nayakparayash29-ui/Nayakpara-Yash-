<?php
/**
 * Shopping View Header
 * Architectural luxury navigation bar with ticker strip, responsive menu,
 * live search capsule, counters, and user account dropdown.
 */
if (!defined('APP_NAME')) require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';

$user = currentUser();
$active = $active ?? '';
$cartCount = 0;
$wishlistCount = 0;

if ($user) {
    require_once __DIR__ . '/../../models/Cart.php';
    require_once __DIR__ . '/../../models/Wishlist.php';
    $cartModel = new CartModel();
    $wishlistModel = new WishlistModel();
    
    $cart = $cartModel->getPopulatedCart($user['id']);
    $cartCount = $cart ? count($cart['items']) : 0;
    $wishlistCount = $wishlistModel->countByUser($user['id']);
}
?>
<!-- Top luxury announcement strip -->
<div class="announcement-bar py-2">
    <div class="container flex items-center justify-between text-xs">
        <div class="flex items-center gap-2">
            <span class="announcement-pill">New Season</span>
            <span>Complimentary express delivery on all orders above ₹1,000 across India.</span>
        </div>
        <div class="flex items-center gap-4 hidden-mobile">
            <a href="<?= base_url('/shop/policies/shipping') ?>" class="hover:text-white transition">Track Order</a>
            <span class="opacity-30">|</span>
            <a href="<?= base_url('/shop/contact') ?>" class="hover:text-white transition">Concierge Support</a>
        </div>
    </div>
</div>

<!-- Main sticky luxury header -->
<header class="header-shop shadow-sm">
    <div class="container header-inner">
        <!-- Left: Mobile menu toggle + Brand Logo -->
        <div class="flex items-center gap-3">
            <button type="button" class="btn btn-ghost btn-icon mobile-menu-btn md:hidden rounded-full p-2" data-mobile-nav-toggle aria-label="Open menu">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
                    <line x1="3" y1="12" x2="21" y2="12"></line>
                    <line x1="3" y1="6" x2="21" y2="6"></line>
                    <line x1="3" y1="18" x2="21" y2="18"></line>
                </svg>
            </button>

            <!-- Brand Logo -->
            <a href="<?= base_url('/shop/home') ?>" class="brand-logo-lux">
                <div class="brand-logo-emblem">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/>
                        <path d="M16 10a4 4 0 0 1-8 0"/>
                    </svg>
                </div>
                <div class="brand-logo-text">
                    <span class="brand-logo-name"><?= e(APP_NAME) ?></span>
                    <span class="brand-logo-sub">Haute Prêt-à-Porter</span>
                </div>
            </a>
        </div>

        <!-- Center: Desktop Navigation Links -->
        <nav class="nav-lux hidden md:flex items-center">
            <a href="<?= base_url('/shop/home') ?>" class="nav-lux-item <?= $active === 'home' ? 'active' : '' ?>">Home</a>
            <a href="<?= base_url('/shop/listing') ?>" class="nav-lux-item <?= ($active === 'listing' && empty($_GET['category'])) ? 'active' : '' ?>">Catalog</a>
            <a href="<?= base_url('/shop/listing') ?>?category=Men" class="nav-lux-item <?= ($active === 'listing' && ($_GET['category'] ?? '') === 'Men') ? 'active' : '' ?>">Men</a>
            <a href="<?= base_url('/shop/listing') ?>?category=Women" class="nav-lux-item <?= ($active === 'listing' && ($_GET['category'] ?? '') === 'Women') ? 'active' : '' ?>">Women</a>
            <a href="<?= base_url('/shop/listing') ?>?category=Kids" class="nav-lux-item <?= ($active === 'listing' && ($_GET['category'] ?? '') === 'Kids') ? 'active' : '' ?>">Kids</a>
            <a href="<?= base_url('/shop/listing') ?>?category=Footwear" class="nav-lux-item <?= ($active === 'listing' && ($_GET['category'] ?? '') === 'Footwear') ? 'active' : '' ?>">Footwear</a>
            <a href="<?= base_url('/shop/about') ?>" class="nav-lux-item <?= $active === 'about' ? 'active' : '' ?>">Story</a>
        </nav>

        <!-- Right: Search Capsule + Wishlist + Cart + Profile -->
        <div class="flex items-center gap-3">
            <!-- Capsule Search Input -->
            <form class="search-capsule hidden-mobile" data-search-form>
                <input type="search" name="q" placeholder="Search styles, fabrics, brands..."
                       value="<?= e($_GET['q'] ?? '') ?>"
                       class="search-capsule-input" autocomplete="off"/>
                <button type="submit" class="search-capsule-btn" aria-label="Search catalog">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
                        <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                    </svg>
                </button>
            </form>

            <!-- Wishlist Button -->
            <a href="<?= base_url('/shop/wishlist') ?>" class="header-action-btn" title="Saved Wishlist" aria-label="Wishlist">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
                <span id="headerWishlistCount" class="badge-count badge-count-wish" style="<?= $wishlistCount > 0 ? '' : 'display:none;' ?>">
                    <?= $wishlistCount ?>
                </span>
            </a>

            <!-- Cart Drawer Toggle -->
            <button type="button" data-sheet-toggle="cartSheet" class="header-action-btn" title="Shopping Bag" aria-label="Cart">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                </svg>
                <span id="headerCartCount" class="badge-count badge-count-cart" style="<?= $cartCount > 0 ? '' : 'display:none;' ?>">
                    <?= $cartCount ?>
                </span>
            </button>

            <!-- User Menu / Sign in -->
            <?php if ($user): ?>
                <div class="relative">
                    <button type="button" class="user-menu-pill" data-dropdown-trigger="user-menu" aria-label="User account menu">
                        <div class="user-menu-avatar">
                            <?= strtoupper(substr(e($user['userName'] ?? 'U'), 0, 1)) ?>
                        </div>
                        <span class="hidden-mobile text-xs font-bold text-foreground max-w-[100px] truncate"><?= e($user['userName']) ?></span>
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" class="text-muted-foreground hidden-mobile">
                            <polyline points="6 9 12 15 18 9"/>
                        </svg>
                    </button>

                    <!-- Dropdown Content -->
                    <div class="dropdown-menu" data-dropdown="user-menu">
                        <div class="p-3 bg-slate-50 rounded-xl mb-1 border border-border/60">
                            <p class="text-xs font-bold text-foreground m-0 leading-tight"><?= e($user['userName']) ?></p>
                            <p class="text-[11px] text-muted-foreground m-0 mt-0.5 truncate"><?= e($user['email']) ?></p>
                            <?php if ($user['role'] === 'admin'): ?>
                                <span class="badge badge-default text-[9px] mt-1.5 uppercase font-bold px-1.5 py-0">Administrator</span>
                            <?php endif ?>
                        </div>
                        <a href="<?= base_url('/shop/account?tab=profile') ?>" class="dropdown-item">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                            My Profile
                        </a>
                        <a href="<?= base_url('/shop/account?tab=orders') ?>" class="dropdown-item">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/></svg>
                            My Orders
                        </a>
                        <a href="<?= base_url('/shop/wishlist') ?>" class="dropdown-item">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                            Saved Wishlist
                        </a>
                        <?php if ($user['role'] === 'admin'): ?>
                            <div class="border-t border-border my-1"></div>
                            <a href="<?= base_url('/admin/dashboard') ?>" class="dropdown-item text-primary font-bold">
                                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                                Admin Dashboard
                            </a>
                        <?php endif ?>
                        <div class="border-t border-border my-1"></div>
                        <button type="button" class="dropdown-item text-destructive" onclick="handleLogout()">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                            Sign Out
                        </button>
                    </div>
                </div>
            <?php else: ?>
                <a href="<?= base_url('/auth/login') ?>" class="btn-lux btn-lux-primary btn-lux-sm">
                    Sign In
                </a>
            <?php endif ?>
        </div>
    </div>
</header>

<!-- Mobile Navigation Drawer -->
<div id="mobileNavBackdrop" class="mobile-nav-backdrop"></div>
<aside id="mobileNavDrawer" class="mobile-nav-drawer" aria-label="Mobile Navigation">
    <div class="p-4 border-b border-border flex items-center justify-between">
        <a href="<?= base_url('/shop/home') ?>" class="brand-logo-lux" data-mobile-nav-close>
            <div class="brand-logo-emblem" style="width:34px;height:34px;">
                👕
            </div>
            <span class="font-bold text-base text-foreground"><?= e(APP_NAME) ?></span>
        </a>
        <button type="button" class="btn btn-ghost btn-icon" data-mobile-nav-close aria-label="Close menu">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
    </div>

    <!-- Mobile Search -->
    <div class="p-3 border-b border-border bg-slate-50">
        <form data-search-form class="search-capsule w-full">
            <input type="search" name="q" placeholder="Search catalog..."
                   value="<?= e($_GET['q'] ?? '') ?>"
                   class="search-capsule-input" autocomplete="off"/>
            <button type="submit" class="search-capsule-btn">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            </button>
        </form>
    </div>

    <!-- Mobile Navigation Links -->
    <div class="p-4 space-y-1 overflow-y-auto flex-1">
        <p class="text-[10px] uppercase tracking-widest font-extrabold text-muted-foreground px-3 py-1">Atelier Collections</p>
        <a href="<?= base_url('/shop/home') ?>" class="dropdown-item font-semibold" data-mobile-nav-close>
            <span>🏠 Home</span>
        </a>
        <a href="<?= base_url('/shop/listing') ?>" class="dropdown-item font-semibold" data-mobile-nav-close>
            <span>🛍️ All Collections</span>
        </a>
        <a href="<?= base_url('/shop/listing') ?>?category=Men" class="dropdown-item font-semibold" data-mobile-nav-close>
            <span>👔 Men's Fashion</span>
        </a>
        <a href="<?= base_url('/shop/listing') ?>?category=Women" class="dropdown-item font-semibold" data-mobile-nav-close>
            <span>👗 Women's Studio</span>
        </a>
        <a href="<?= base_url('/shop/listing') ?>?category=Kids" class="dropdown-item font-semibold" data-mobile-nav-close>
            <span>🧸 Kids & Youth</span>
        </a>
        <a href="<?= base_url('/shop/listing') ?>?category=Footwear" class="dropdown-item font-semibold" data-mobile-nav-close>
            <span>👟 Footwear</span>
        </a>
        <a href="<?= base_url('/shop/about') ?>" class="dropdown-item font-semibold" data-mobile-nav-close>
            <span>📜 Atelier Story</span>
        </a>

        <div class="border-t border-border my-3 pt-2"></div>
        <p class="text-[10px] uppercase tracking-widest font-extrabold text-muted-foreground px-3 py-1">Personal Account</p>
        <a href="<?= base_url('/shop/wishlist') ?>" class="dropdown-item flex items-center justify-between" data-mobile-nav-close>
            <span>❤️ My Wishlist</span>
            <?php if ($wishlistCount > 0): ?>
                <span class="badge badge-destructive text-xs"><?= $wishlistCount ?></span>
            <?php endif ?>
        </a>
        <a href="<?= base_url('/shop/cart') ?>" class="dropdown-item flex items-center justify-between" data-mobile-nav-close>
            <span>🛒 Shopping Bag</span>
            <?php if ($cartCount > 0): ?>
                <span class="badge badge-default text-xs"><?= $cartCount ?></span>
            <?php endif ?>
        </a>
        <?php if ($user): ?>
            <a href="<?= base_url('/shop/account?tab=profile') ?>" class="dropdown-item" data-mobile-nav-close>
                <span>👤 Profile Details</span>
            </a>
            <a href="<?= base_url('/shop/account?tab=orders') ?>" class="dropdown-item" data-mobile-nav-close>
                <span>📦 My Orders</span>
            </a>
            <?php if ($user['role'] === 'admin'): ?>
                <a href="<?= base_url('/admin/dashboard') ?>" class="dropdown-item text-primary font-bold" data-mobile-nav-close>
                    <span>⚡ Admin Dashboard</span>
                </a>
            <?php endif ?>
            <button type="button" class="dropdown-item text-destructive w-full" onclick="handleLogout()">
                <span>🚪 Sign Out</span>
            </button>
        <?php else: ?>
            <div class="pt-3">
                <a href="<?= base_url('/auth/login') ?>" class="btn-lux btn-lux-primary w-full text-center" data-mobile-nav-close>
                    Sign In / Register
                </a>
            </div>
        <?php endif ?>
    </div>
</aside>

<!-- Slide-Over Shopping Bag Drawer (Cart Sheet) -->
<div class="sheet-overlay" data-sheet-overlay="cartSheet"></div>
<div id="cartSheet" class="sheet">
    <div class="sheet-header">
        <div class="flex items-center gap-2">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
            </svg>
            <h3 class="sheet-title">Shopping Bag (<span id="cartSheetCount"><?= $cartCount ?></span>)</h3>
        </div>
        <button class="btn btn-ghost btn-icon rounded-full" data-sheet-toggle="cartSheet" aria-label="Close bag drawer">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
    </div>
    <div class="sheet-content" id="cartSheetContent">
        <?php if ($user): ?>
            <?php require __DIR__ . '/../shop/cart_sheet.php'; ?>
        <?php else: ?>
            <div class="text-center py-14 px-4">
                <div class="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4 text-slate-400">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
                </div>
                <h4 class="font-bold text-lg m-0">Your Bag is Waiting</h4>
                <p class="mt-2 text-xs text-muted-foreground max-w-xs mx-auto">Sign in to your account to access your saved items and enjoy seamless checkout.</p>
                <a href="<?= base_url('/auth/login') ?>" class="btn-lux btn-lux-primary btn-lux-sm mt-5 inline-block">Sign In to Continue</a>
            </div>
        <?php endif ?>
    </div>
</div>

<script>window.CART_USER_ID = <?= $user ? (int)$user['id'] : 0 ?>;</script>
<script>
async function handleLogout() {
    try {
        await Auth.logout();
        toast('Goodbye', 'Signed out successfully', 'success');
        setTimeout(() => window.location.href = (window.APP_BASE || '') + '/auth/login', 300);
    } catch(e) {
        window.location.href = (window.APP_BASE || '') + '/auth/login';
    }
}
</script>

<?php
/**
 * Modern Shared Admin Layout
 * Clean, Professional, Consistent & Fully Responsive
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
requireAdmin();

$user = currentUser();
$active = $active ?? 'dashboard';
$flashSuccess = getFlash('success');
$flashError   = getFlash('error');
$flashInfo    = getFlash('info');

// Notification stats calculation
require_once __DIR__ . '/../../models/Product.php';
require_once __DIR__ . '/../../models/Order.php';
$pm = new ProductModel();
$om = new OrderModel();
$lowStock     = $pm->getLowStock(10);
$outOfStock   = $pm->getOutOfStock();
$newOrders    = $om->countByStatus('pending');
$totalAlerts  = $newOrders + count($lowStock) + count($outOfStock);

// Breadcrumb label mapping
$navLabels = [
    'dashboard'   => 'Dashboard',
    'analytics'   => 'Analytics',
    'products'    => 'Products',
    'orders'      => 'Orders',
    'customers'   => 'Customers',
    'categories'  => 'Categories & Brands',
    'features'    => 'Banners / Features',
    'inventory'   => 'Inventory',
    'reviews'     => 'Reviews',
    'coupons'     => 'Coupons & Discounts',
    'feedback'    => 'Feedback',
    'settings'    => 'Settings',
];
$currentPageTitle = $navLabels[$active] ?? ucwords(str_replace('-', ' ', $active));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title><?= e($currentPageTitle) ?> | Admin · <?= e(APP_NAME) ?></title>
    <!-- Base styles and Admin Design System -->
    <link rel="stylesheet" href="<?= asset_url('/css/style.css') ?>"/>
    <link rel="stylesheet" href="<?= asset_url('/css/admin.css') ?>"/>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>⚡</text></svg>">
</head>
<body>
<div id="adminLayout">
    <!-- Mobile Drawer Backdrop -->
    <div id="adminBackdrop" class="adm-backdrop"></div>

    <!-- Professional Sidebar Navigation -->
    <aside class="adm-sidebar">
        <div class="adm-sidebar-header">
            <a href="<?= base_url('/admin/dashboard') ?>" class="adm-brand">
                <div class="adm-brand-logo">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/>
                    </svg>
                </div>
                <div class="adm-brand-text">
                    <span class="adm-brand-title"><?= e(APP_NAME) ?></span>
                    <span class="adm-brand-badge">Admin Panel</span>
                </div>
            </a>
            <!-- Mobile Close Button (X) -->
            <button type="button" id="admSidebarClose" class="adm-toggle-btn adm-mobile-close" title="Close navigation">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>
        </div>

        <nav class="adm-sidebar-nav">
            <!-- OVERVIEW -->
            <div class="adm-nav-heading">Overview</div>
            <a href="<?= base_url('/admin/dashboard') ?>" class="adm-nav-link <?= $active === 'dashboard' ? 'active' : '' ?>" title="Dashboard">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                <span>Dashboard</span>
            </a>
            <a href="<?= base_url('/admin/analytics') ?>" class="adm-nav-link <?= $active === 'analytics' ? 'active' : '' ?>" title="Analytics">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
                <span>Analytics</span>
            </a>

            <!-- CATALOG & SALES -->
            <div class="adm-nav-heading">Catalog & Sales</div>
            <a href="<?= base_url('/admin/products') ?>" class="adm-nav-link <?= $active === 'products' ? 'active' : '' ?>" title="Products">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>
                <span>Products</span>
            </a>
            <a href="<?= base_url('/admin/orders') ?>" class="adm-nav-link <?= $active === 'orders' ? 'active' : '' ?>" title="Orders">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/></svg>
                <span>Orders</span>
                <?php if ($newOrders > 0): ?>
                    <span class="adm-nav-badge danger"><?= $newOrders ?></span>
                <?php endif ?>
            </a>
            <a href="<?= base_url('/admin/categories') ?>" class="adm-nav-link <?= $active === 'categories' ? 'active' : '' ?>" title="Categories & Brands">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
                <span>Categories & Brands</span>
            </a>
            <a href="<?= base_url('/admin/inventory') ?>" class="adm-nav-link <?= $active === 'inventory' ? 'active' : '' ?>" title="Inventory">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                <span>Inventory</span>
                <?php if (count($lowStock) || count($outOfStock)): ?>
                    <span class="adm-nav-badge warning"><?= count($lowStock) + count($outOfStock) ?></span>
                <?php endif ?>
            </a>

            <!-- CRM & MARKETING -->
            <div class="adm-nav-heading">CRM & Marketing</div>
            <a href="<?= base_url('/admin/customers') ?>" class="adm-nav-link <?= $active === 'customers' ? 'active' : '' ?>" title="Customers">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                <span>Customers</span>
            </a>
            <a href="<?= base_url('/admin/features') ?>" class="adm-nav-link <?= $active === 'features' ? 'active' : '' ?>" title="Banners / Features">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                <span>Banners / Features</span>
            </a>
            <a href="<?= base_url('/admin/coupons') ?>" class="adm-nav-link <?= $active === 'coupons' ? 'active' : '' ?>" title="Coupons">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 12V8H6a2 2 0 0 1-2-2c0-1.1.9-2 2-2h12v4"/><path d="M4 6v12c0 1.1.9 2 2 2h14v-4"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/></svg>
                <span>Coupons</span>
            </a>
            <a href="<?= base_url('/admin/reviews') ?>" class="adm-nav-link <?= $active === 'reviews' ? 'active' : '' ?>" title="Reviews">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                <span>Reviews</span>
            </a>
            <a href="<?= base_url('/admin/feedback') ?>" class="adm-nav-link <?= $active === 'feedback' ? 'active' : '' ?>" title="Feedback">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                <span>Feedback</span>
            </a>

            <!-- SYSTEM -->
            <div class="adm-nav-heading">System</div>
            <a href="<?= base_url('/admin/settings') ?>" class="adm-nav-link <?= $active === 'settings' ? 'active' : '' ?>" title="Settings">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.22.562.824 1.068 1.51 1.134.53.05 1.28.379 1.76.869"/></svg>
                <span>Settings</span>
            </a>
        </nav>

        <div class="adm-sidebar-footer">
            <a href="<?= base_url('/shop/home') ?>" class="adm-store-btn" target="_blank" title="Open storefront in new tab">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                <span>View Storefront</span>
            </a>
            <button type="button" class="adm-store-btn" onclick="handleLogout()" style="color:var(--adm-danger);" title="Sign out of Admin">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                <span>Logout</span>
            </button>
        </div>
    </aside>

    <!-- Main Content Wrapper -->
    <div class="adm-main-wrap">
        <!-- Top Navbar -->
        <header class="adm-header">
            <div class="adm-header-left">
                <!-- Mobile Drawer Trigger -->
                <button type="button" id="admMobileToggle" class="adm-toggle-btn adm-mobile-only" title="Toggle mobile navigation">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
                </button>
                <!-- Desktop Sidebar Collapse Toggle -->
                <button type="button" id="admCollapseToggle" class="adm-toggle-btn hidden md:flex" title="Toggle sidebar width">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="14" y2="12"/><line x1="4" y1="18" x2="18" y2="18"/></svg>
                </button>

                <!-- Breadcrumbs -->
                <nav class="adm-breadcrumbs">
                    <a href="<?= base_url('/admin/dashboard') ?>">Admin</a>
                    <span class="separator">/</span>
                    <span class="current"><?= e($currentPageTitle) ?></span>
                </nav>
            </div>

            <div class="adm-header-right">
                <!-- Direct Store Link -->
                <a href="<?= base_url('/shop/home') ?>" class="btn btn-outline btn-sm hidden sm:inline-flex" target="_blank" title="View Customer Storefront">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                    <span>Storefront</span>
                </a>

                <!-- Notifications Dropdown -->
                <div class="adm-dropdown-wrap">
                    <button type="button" class="adm-icon-btn" data-adm-dropdown-trigger="notif" title="Notifications">
                        <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                        <?php if ($totalAlerts > 0): ?>
                            <span class="adm-icon-badge"><?= $totalAlerts ?></span>
                        <?php endif ?>
                    </button>
                    <div class="adm-dropdown-pop" style="min-width: 290px;">
                        <div class="adm-dropdown-header flex items-center justify-between">
                            <span class="font-bold text-sm">Notifications</span>
                            <span class="badge badge-primary text-[10px]"><?= $totalAlerts ?> New</span>
                        </div>
                        <div style="max-height: 280px; overflow-y: auto;">
                            <?php if ($newOrders > 0): ?>
                                <a href="<?= base_url('/admin/orders') ?>" class="adm-dropdown-item">
                                    <div class="adm-stat-icon primary" style="width:30px;height:30px;margin-right:4px;">
                                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/></svg>
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <p class="m-0 text-xs font-semibold leading-tight"><?= $newOrders ?> Pending Order<?= $newOrders > 1 ? 's' : '' ?></p>
                                        <p class="m-0 text-[11px] text-muted-foreground mt-0.5">Requires confirmation</p>
                                    </div>
                                </a>
                            <?php endif ?>

                            <?php foreach (array_slice($lowStock, 0, 3) as $lp): ?>
                                <a href="<?= base_url('/admin/inventory') ?>" class="adm-dropdown-item">
                                    <div class="adm-stat-icon warning" style="width:30px;height:30px;margin-right:4px;">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/></svg>
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <p class="m-0 text-xs font-semibold leading-tight truncate"><?= e($lp['title']) ?></p>
                                        <p class="m-0 text-[11px] text-amber-600 mt-0.5"><?= (int)$lp['totalStock'] ?> left in stock</p>
                                    </div>
                                </a>
                            <?php endforeach ?>

                            <?php foreach (array_slice($outOfStock, 0, 2) as $op): ?>
                                <a href="<?= base_url('/admin/products') ?>" class="adm-dropdown-item">
                                    <div class="adm-stat-icon danger" style="width:30px;height:30px;margin-right:4px;">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <p class="m-0 text-xs font-semibold leading-tight truncate"><?= e($op['title']) ?></p>
                                        <p class="m-0 text-[11px] text-red-600 mt-0.5">Out of stock</p>
                                    </div>
                                </a>
                            <?php endforeach ?>

                            <?php if ($totalAlerts === 0): ?>
                                <div class="p-4 text-center text-xs text-muted-foreground">
                                    ✨ All clear! No new store alerts.
                                </div>
                            <?php endif ?>
                        </div>
                    </div>
                </div>

                <!-- User Profile Menu -->
                <div class="adm-dropdown-wrap">
                    <button type="button" class="adm-user-trigger" data-adm-dropdown-trigger="profile">
                        <div class="adm-avatar">
                            <?= strtoupper(substr(e($user['userName'] ?? 'A'), 0, 1)) ?>
                        </div>
                        <div class="adm-user-info">
                            <p class="adm-user-name"><?= e($user['userName'] ?? 'Admin') ?></p>
                            <p class="adm-user-role">Administrator</p>
                        </div>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="text-muted-foreground ml-1"><path d="M6 9l6 6 6-6"/></svg>
                    </button>
                    <div class="adm-dropdown-pop" style="min-width: 220px;">
                        <div class="adm-dropdown-header">
                            <p class="text-xs font-bold m-0"><?= e($user['userName'] ?? 'Admin') ?></p>
                            <p class="text-[11px] text-muted-foreground m-0 mt-0.5 truncate"><?= e($user['email'] ?? 'admin@store.com') ?></p>
                        </div>
                        <a href="<?= base_url('/admin/settings') ?>" class="adm-dropdown-item">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.22.562.824 1.068 1.51 1.134.53.05 1.28.379 1.76.869"/></svg>
                            <span>Store Settings</span>
                        </a>
                        <a href="<?= base_url('/shop/home') ?>" class="adm-dropdown-item" target="_blank">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                            <span>Customer Storefront</span>
                        </a>
                        <div style="border-top: 1px solid var(--adm-border); margin: 0.35rem 0;"></div>
                        <button type="button" class="adm-dropdown-item danger" onclick="handleLogout()">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                            <span>Sign Out</span>
                        </button>
                    </div>
                </div>
            </div>
        </header>

        <!-- Flash Notifications -->
        <?php if ($flashSuccess): ?>
            <div style="padding: 1.25rem 2rem 0;">
                <div class="alert alert-success" style="display:flex;align-items:center;justify-content:space-between;border-radius:var(--adm-radius-md);">
                    <span><?= e($flashSuccess) ?></span>
                    <button type="button" class="btn-icon btn-ghost btn-xs" onclick="this.parentElement.remove()">✕</button>
                </div>
            </div>
        <?php endif ?>
        <?php if ($flashError): ?>
            <div style="padding: 1.25rem 2rem 0;">
                <div class="alert alert-error" style="display:flex;align-items:center;justify-content:space-between;border-radius:var(--adm-radius-md);">
                    <span><?= e($flashError) ?></span>
                    <button type="button" class="btn-icon btn-ghost btn-xs" onclick="this.parentElement.remove()">✕</button>
                </div>
            </div>
        <?php endif ?>
        <?php if ($flashInfo): ?>
            <div style="padding: 1.25rem 2rem 0;">
                <div class="alert alert-info" style="display:flex;align-items:center;justify-content:space-between;border-radius:var(--adm-radius-md);">
                    <span><?= e($flashInfo) ?></span>
                    <button type="button" class="btn-icon btn-ghost btn-xs" onclick="this.parentElement.remove()">✕</button>
                </div>
            </div>
        <?php endif ?>

        <!-- Main View Container -->
        <main class="adm-content">
            <?php
            if (isset($viewContent) && is_string($viewContent)) {
                if (file_exists($viewContent)) require $viewContent;
                else echo $viewContent;
            }
            ?>
        </main>
    </div>
</div>

<script>
window.APP_BASE = '<?= BASE_PATH ?>';
window.productImageUrl = function (image) {
    if (!image) return '';
    const base = window.APP_BASE || '';
    const match = String(image).match(/uploads\/([^?\s"']+)$/i);
    if (match) return base + '/uploads/' + match[1];
    if (/^(https?:|data:)/i.test(image)) return image;
    if (image.charAt(0) === '/') return base + image;
    return base + '/uploads/' + image;
};
</script>
<script src="<?= asset_url('/js/app.js') ?>"></script>
<script src="<?= asset_url('/js/admin.js') ?>"></script>
<script>
async function handleLogout() {
    showConfirmModal({
        title: 'Sign Out',
        message: 'Are you sure you want to end your administrative session?',
        confirmText: 'Sign Out',
        isDanger: true,
        onConfirm: async () => {
            try {
                await Auth.logout();
                toast('Success', 'Logged out successfully', 'success');
                setTimeout(() => location.href = (window.APP_BASE || '') + '/auth/login', 400);
            } catch(e) {}
        }
    });
}
</script>
<?php if (!empty($extraScripts)) echo $extraScripts; ?>
</body>
</html>

<?php
/**
 * Auth layout — shared shell for login, registration, and password reset.
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';

$flashSuccess = getFlash('success');
$flashError   = getFlash('error');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title><?= isset($pageTitle) ? e($pageTitle) . ' | ' : '' ?><?= e(APP_NAME) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= asset_url('/css/style.css') ?>"/>
    <link rel="stylesheet" href="<?= asset_url('/css/shop.css') ?>"/>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>C</text></svg>">
</head>
<body class="auth-wrapper-lux">
    <div class="auth-card-lux">
        <div class="auth-brand">
            <a href="<?= base_url('/shop/home') ?>" class="auth-brand-link">
                <span class="brand-logo-emblem" aria-hidden="true">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/>
                        <path d="M16 10a4 4 0 0 1-8 0"/>
                    </svg>
                </span>
                <span class="auth-brand-name"><?= e(APP_NAME) ?></span>
            </a>
        </div>

        <?php if ($flashSuccess): ?>
            <div class="form-alert form-alert-success" role="status"><?= e($flashSuccess) ?></div>
        <?php endif ?>
        <?php if ($flashError): ?>
            <div class="form-alert" role="alert"><?= e($flashError) ?></div>
        <?php endif ?>

        <div class="auth-body">
            <?php
            if (isset($viewContent) && is_string($viewContent)) {
                if (file_exists($viewContent)) require $viewContent;
                else echo $viewContent;
            }
            ?>
        </div>

        <div class="auth-foot">
            <a href="<?= base_url('/shop/home') ?>">Continue shopping</a>
            <a href="<?= base_url('/shop/policies/privacy') ?>">Privacy</a>
            <a href="<?= base_url('/shop/policies/terms') ?>">Terms</a>
            <a href="<?= base_url('/shop/contact') ?>">Help</a>
        </div>
    </div>

    <script>window.APP_BASE = '<?= BASE_PATH ?>';</script>
    <script src="<?= asset_url('/js/app.js') ?>"></script>
</body>
</html>

<?php
/**
 * 404 Not Found Page
 * Luxury editorial error screen with brand emblem and navigation return.
 */
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/functions.php';
http_response_code(404);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>404 — Archival Page Not Located | <?= e(APP_NAME) ?></title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;0,700;1,400;1,600&family=Inter:wght@300;400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Syne:wght@600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?= base_url('/css/style.css') ?>"/>
    <link rel="stylesheet" href="<?= base_url('/css/shop.css') ?>"/>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>✨</text></svg>">
</head>
<body class="auth-wrapper-lux">
    <div class="auth-card-lux p-8 sm:p-12 text-center space-y-5 animate-fade-in-scale">
        <div class="brand-logo-emblem mx-auto mb-2" style="width:48px;height:48px;">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
        </div>

        <span class="inline-block text-[10px] uppercase font-extrabold tracking-widest px-3 py-1 rounded-full bg-slate-100 text-slate-800">
            Error Code 404
        </span>

        <h1 class="font-display text-5xl sm:text-6xl font-black text-foreground m-0 tracking-tight">
            404
        </h1>

        <div class="space-y-1">
            <h2 class="font-display text-xl font-bold text-foreground m-0">Garment Not Located</h2>
            <p class="text-xs text-muted-foreground max-w-xs mx-auto leading-relaxed m-0">
                The atelier link you accessed may have moved, transitioned to our seasonal archive, or is temporarily retired.
            </p>
        </div>

        <div class="pt-3 flex flex-wrap justify-center gap-3">
            <a href="<?= base_url('/shop/home') ?>" class="btn-lux btn-lux-primary btn-lux-sm">
                Return to Atelier &rarr;
            </a>
            <a href="<?= base_url('/shop/listing') ?>" class="btn-lux btn-lux-outline btn-lux-sm">
                Browse Collections
            </a>
        </div>
    </div>
</body>
</html>

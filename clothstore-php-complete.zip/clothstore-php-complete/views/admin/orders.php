<?php
/**
 * Modern Admin Orders Management
 * Live order tracking, CSV export, fulfillment updates & details inspection
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'orders';

require_once __DIR__ . '/../../models/Order.php';
$om = new OrderModel();
$orders = $om->findAll();

$statusMap = [
    'pending'   => ['warning', 'Pending'],
    'confirmed' => ['info', 'Confirmed'],
    'shipped'   => ['secondary', 'Shipped'],
    'delivered' => ['success', 'Delivered'],
    'cancelled' => ['destructive', 'Cancelled'],
];
?>

<!-- Page Header -->
<div class="adm-page-header">
    <div class="adm-page-title-wrap">
        <h1 class="adm-page-title">Orders Management (<?= count($orders) ?>)</h1>
        <p class="adm-page-subtitle">Track customer orders, confirm payments, update fulfillment states, and dispatch items</p>
    </div>
    <div class="adm-page-actions">
        <button type="button" id="exportOrdersBtn" class="btn btn-outline btn-sm">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            <span>Export Orders (CSV)</span>
        </button>
    </div>
</div>

<!-- Table Card -->
<div class="adm-card">
    <!-- Toolbar -->
    <div class="adm-toolbar">
        <div class="adm-toolbar-group flex-1">
            <select id="statusFilter" class="form-select" style="max-width: 170px;">
                <option value="all">All Statuses</option>
                <option value="pending">Pending</option>
                <option value="confirmed">Confirmed</option>
                <option value="shipped">Shipped</option>
                <option value="delivered">Delivered</option>
                <option value="cancelled">Cancelled</option>
            </select>

            <select id="paymentFilter" class="form-select" style="max-width: 160px;">
                <option value="all">All Payments</option>
                <option value="paid">Paid</option>
                <option value="pending">Payment Pending</option>
            </select>

            <input id="orderSearch" type="search" placeholder="Search order #, customer ID, or method..." class="form-input" style="max-width: 280px;"/>
        </div>

        <div class="adm-toolbar-group">
            <button type="button" id="resetOrderFilters" class="btn btn-outline btn-sm">Reset</button>
            <select id="orderPageSize" class="form-select" style="width: auto;">
                <option value="10">10 / page</option>
                <option value="25">25 / page</option>
                <option value="50">50 / page</option>
            </select>
        </div>
    </div>

    <!-- Orders Table -->
    <div class="adm-card-body p-0">
        <div class="adm-table-wrap">
            <table class="adm-table" id="ordersTable">
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Customer</th>
                        <th>Items</th>
                        <th>Total Amount</th>
                        <th>Fulfillment</th>
                        <th>Payment Status</th>
                        <th>Order Date</th>
                        <th style="text-align: right;">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($orders as $o):
                    $st = $statusMap[$o['orderStatus']] ?? ['secondary', ucfirst($o['orderStatus'])];
                    $customerName = trim((string)($o['customerName'] ?? ''));
                    if ($customerName === '') $customerName = 'Customer';
                    $searchTerms = strtolower('#' . $o['id'] . ' ' . $customerName . ' ' . ($o['customerEmail'] ?? '') . ' ' . $o['userId'] . ' ' . $o['orderStatus'] . ' ' . $o['paymentStatus'] . ' ' . ($o['paymentMethod'] ?? ''));
                ?>
                    <tr class="<?= e($o['orderStatus']) ?>"
                        data-id="<?= (int)$o['id'] ?>"
                        data-status="<?= e($o['orderStatus']) ?>"
                        data-payment="<?= e($o['paymentStatus']) ?>"
                        data-search="<?= e($searchTerms) ?>">
                        <td class="font-mono font-bold text-primary">
                            #<?= str_pad((int)$o['id'], 6, '0', STR_PAD_LEFT) ?>
                        </td>
                        <td>
                            <div class="flex items-center gap-2">
                                <div class="adm-avatar" style="width: 28px; height: 28px; font-size: 11px;">
                                    <?= e(strtoupper(substr($customerName, 0, 1))) ?>
                                </div>
                                <div class="min-w-0">
                                    <span class="text-sm font-medium text-main block truncate"><?= e($customerName) ?></span>
                                    <?php if (!empty($o['customerEmail'])): ?>
                                        <span class="text-[11px] text-muted-foreground block truncate"><?= e($o['customerEmail']) ?></span>
                                    <?php endif ?>
                                </div>
                            </div>
                        </td>
                        <td class="text-xs text-muted-foreground"><?= count($o['cartItems'] ?? []) ?> item(s)</td>
                        <td class="font-bold text-main text-xs"><?= formatCurrency($o['totalAmount']) ?></td>
                        <td>
                            <span class="badge badge-<?= $st[0] ?> text-[11px]"><?= $st[1] ?></span>
                        </td>
                        <td>
                            <?php if ($o['paymentStatus'] === 'paid'): ?>
                                <span class="badge badge-success text-[10px]">Paid</span>
                            <?php else: ?>
                                <span class="badge badge-warning text-[10px]">Pending</span>
                            <?php endif ?>
                            <span class="text-[10px] text-muted-foreground block mt-0.5"><?= e(strtoupper($o['paymentMethod'] ?? 'COD')) ?></span>
                        </td>
                        <td class="text-xs text-muted-foreground">
                            <?= date('d M Y', strtotime($o['orderDate'] ?? 'now')) ?>
                            <span class="text-[10px] block opacity-75"><?= date('h:i A', strtotime($o['orderDate'] ?? 'now')) ?></span>
                        </td>
                        <td style="text-align: right;">
                            <button type="button" class="btn btn-outline btn-xs viewOrderBtn"
                                data-id="<?= (int)$o['id'] ?>"
                                data-order="#<?= str_pad((int)$o['id'], 6, '0', STR_PAD_LEFT) ?>"
                                data-items='<?= json_encode($o['cartItems'] ?? [], JSON_HEX_TAG) ?>'
                                data-total="<?= e($o['totalAmount']) ?>"
                                data-status="<?= e($o['orderStatus']) ?>"
                                data-payment="<?= e($o['paymentStatus']) ?>"
                                data-method="<?= e($o['paymentMethod'] ?? 'Cash on Delivery') ?>"
                                data-date="<?= date('d M Y, h:i A', strtotime($o['orderDate'] ?? 'now')) ?>"
                                data-address="<?= e(($o['addressInfo']['address'] ?? '') . ', ' . ($o['addressInfo']['city'] ?? '') . ' - ' . ($o['addressInfo']['pincode'] ?? '')) ?>"
                                data-phone="<?= e($o['addressInfo']['phone'] ?? 'N/A') ?>"
                                data-customer="<?= e($customerName) ?>">
                                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                                <span>Inspect</span>
                            </button>
                        </td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination Footer -->
    <div id="orderPagination" class="adm-pagination-bar"></div>
</div>

<!-- Order Inspection & Status Update Modal -->
<div id="orderDialog" class="dialog-overlay hidden" data-closable="true">
    <div class="dialog" style="max-width: 42rem;">
        <div class="dialog-header">
            <div>
                <h3 class="dialog-title" id="dlgOrderTitle">Order Details</h3>
                <p class="dialog-description" id="dlgOrderSubtitle"></p>
            </div>
            <button type="button" id="orderDlgClose" class="btn btn-ghost btn-icon btn-sm" title="Close dialog">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>
        </div>
        <div class="dialog-content space-y-4">
            <!-- Status & Summary -->
            <div class="grid grid-cols-2 gap-3">
                <div class="p-3 rounded-xl bg-slate-50 border border-border">
                    <span class="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">Current Status</span>
                    <p class="font-bold text-sm m-0 mt-1" id="dlgStatus">-</p>
                </div>
                <div class="p-3 rounded-xl bg-slate-50 border border-border">
                    <span class="text-[11px] font-bold text-muted-foreground uppercase tracking-wider">Payment Record</span>
                    <p class="font-bold text-sm m-0 mt-1" id="dlgPayment">-</p>
                </div>
            </div>

            <!-- Shipping Information -->
            <div>
                <span class="text-xs font-bold text-main block mb-1.5">Shipping Destination</span>
                <div class="p-3 rounded-xl border border-border bg-white space-y-1">
                    <p class="text-xs text-main m-0 leading-relaxed font-medium" id="dlgAddress">-</p>
                    <p class="text-[11px] text-muted-foreground m-0">📞 <span id="dlgPhone">-</span></p>
                </div>
            </div>

            <!-- Ordered Line Items -->
            <div>
                <span class="text-xs font-bold text-main block mb-1.5">Line Items</span>
                <div class="space-y-2 max-h-48 overflow-y-auto pr-1" id="dlgItems"></div>
            </div>

            <div class="border-t border-border pt-3 flex items-center justify-between">
                <span class="text-sm font-semibold text-muted-foreground">Order Total:</span>
                <span class="text-xl font-extrabold text-primary" id="dlgTotal">-</span>
            </div>

            <!-- Status Modifier Form (WORKING) -->
            <div class="border-t border-border pt-4 mt-2">
                <span class="text-xs font-bold text-main block mb-2">Update Order & Payment Status</span>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="label">Fulfillment Status</label>
                        <select id="updateStatusSelect" class="form-select">
                            <option value="pending">Pending</option>
                            <option value="confirmed">Confirmed</option>
                            <option value="shipped">Shipped</option>
                            <option value="delivered">Delivered</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                    <div>
                        <label class="label">Payment Status</label>
                        <select id="updatePaymentSelect" class="form-select">
                            <option value="pending">Pending</option>
                            <option value="paid">Paid</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <div class="dialog-footer">
            <button type="button" id="orderDlgCancel" class="btn btn-outline btn-sm">Close</button>
            <button type="button" id="btnUpdateOrderStatus" class="btn btn-primary btn-sm">Save Status Update</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Initialize Table Controller with Search, Multi-Filter, and Pagination
    const tableCtrl = window.initAdminTable('ordersTable', {
        searchId: 'orderSearch',
        paginationId: 'orderPagination',
        pageSizeId: 'orderPageSize',
        defaultPageSize: 10,
        extraFilters: [
            { id: 'statusFilter', attr: 'data-status' },
            { id: 'paymentFilter', attr: 'data-payment' },
        ],
    });

    const statusFilter = document.getElementById('statusFilter');
    const paymentFilter = document.getElementById('paymentFilter');

    document.getElementById('resetOrderFilters').addEventListener('click', () => {
        document.getElementById('orderSearch').value = '';
        statusFilter.value = 'all';
        paymentFilter.value = 'all';
        tableCtrl.refresh();
    });

    // CSV Export Button
    document.getElementById('exportOrdersBtn').onclick = () => {
        window.exportTableToCSV('ordersTable', 'orders_export.csv');
        toast('Exported', 'Orders CSV file downloaded successfully', 'success');
    };

    // Modal Handling
    const dlg = document.getElementById('orderDialog');
    let currentSelectedOrderId = null;

    function closeDlg() { dlg.classList.add('hidden'); }
    document.getElementById('orderDlgClose').onclick = closeDlg;
    document.getElementById('orderDlgCancel').onclick = closeDlg;

    // View Details Button Handler
    document.querySelectorAll('.viewOrderBtn').forEach(b => {
        b.onclick = () => {
            currentSelectedOrderId = b.dataset.id;
            document.getElementById('dlgOrderTitle').textContent = 'Order ' + b.dataset.order;
            document.getElementById('dlgOrderSubtitle').textContent = (b.dataset.customer || 'Customer') + ' · Placed on ' + b.dataset.date;
            document.getElementById('dlgStatus').textContent = b.dataset.status.toUpperCase();
            document.getElementById('dlgPayment').textContent = (b.dataset.payment === 'paid' ? 'PAID · ' : 'PENDING · ') + b.dataset.method;
            document.getElementById('dlgAddress').textContent = b.dataset.address || 'Standard Address';
            document.getElementById('dlgPhone').textContent = b.dataset.phone || 'N/A';
            document.getElementById('dlgTotal').textContent = '₹' + Number(b.dataset.total || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

            // Preset status dropdowns
            document.getElementById('updateStatusSelect').value = b.dataset.status || 'pending';
            document.getElementById('updatePaymentSelect').value = b.dataset.payment || 'pending';

            let items = [];
            try { items = JSON.parse(b.dataset.items || '[]'); } catch(e) {}

            const itemsHtml = items.length ? items.map(it => `
                <div class="flex items-center gap-3 p-2 rounded-lg bg-slate-50 border border-border">
                    <div class="w-10 h-10 bg-white rounded border border-border overflow-hidden flex-shrink-0">
                        ${it.image ? `<img src="${productImageUrl(it.image)}" class="w-full h-full object-cover"/>` : ''}
                    </div>
                    <div class="flex-1 min-w-0">
                        <p class="text-xs font-bold text-main m-0 truncate">${it.title || 'Product Item'}</p>
                        <p class="text-[11px] text-muted-foreground m-0">Qty: ${it.quantity || 1}</p>
                    </div>
                    <span class="font-bold text-xs text-main">₹${Number(it.price || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
            `).join('') : '<p class="text-xs text-muted-foreground text-center py-2">No line items recorded.</p>';

            document.getElementById('dlgItems').innerHTML = itemsHtml;
            dlg.classList.remove('hidden');
        };
    });

    // WORKING Status Update Request
    const updateBtn = document.getElementById('btnUpdateOrderStatus');
    updateBtn.onclick = async () => {
        if (!currentSelectedOrderId) return;
        const newStatus = document.getElementById('updateStatusSelect').value;
        const newPayment = document.getElementById('updatePaymentSelect').value;

        setButtonLoading(updateBtn, true, 'Updating...');
        try {
            await api(`/admin/orders/${currentSelectedOrderId}`, {
                method: 'PUT',
                body: { orderStatus: newStatus, paymentStatus: newPayment }
            });
            toast('Updated', `Order #${currentSelectedOrderId} status changed to ${newStatus}`, 'success');
            closeDlg();
            setTimeout(() => location.reload(), 450);
        } catch(err) {
            setButtonLoading(updateBtn, false);
        }
    };
});
</script>

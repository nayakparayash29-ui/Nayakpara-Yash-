<?php
/**
 * Modern Admin Customer Feedback Moderation
 * Star rating distribution, qualitative sentiment analysis, and review moderation
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'feedback';

require_once __DIR__ . '/../../models/Review.php';

if (!function_exists('renderStars')) {
    function renderStars($rating = 0, $size = 14) {
        $rating = min(5, max(0, round((float)$rating)));
        $out = '<span class="stars inline-flex items-center gap-0.5">';
        for ($i = 1; $i <= 5; $i++) {
            $fill = $i <= $rating ? '#eab308' : '#e2e8f0';
            $out .= '<svg width="' . (int)$size . '" height="' . (int)$size . '" viewBox="0 0 24 24" fill="' . $fill . '" stroke="' . $fill . '" stroke-width="0"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
        }
        return $out . '</span>';
    }
}

$rm = new ReviewModel();
$reviews = $rm->findAll();
$totalReviews = count($reviews);

$starCounts = [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0];
$sumRating = 0;
foreach ($reviews as $r) {
    $v = min(5, max(1, (int)($r['reviewValue'] ?? 0)));
    if ($v >= 1) {
        $starCounts[$v] = ($starCounts[$v] ?? 0) + 1;
        $sumRating += $v;
    }
}
$avgRating = $totalReviews > 0 ? round($sumRating / $totalReviews, 1) : 0;
?>

<!-- Page Header -->
<div class="adm-page-header">
    <div class="adm-page-title-wrap">
        <h1 class="adm-page-title">Customer Feedback & Sentiment (<?= $totalReviews ?>)</h1>
        <p class="adm-page-subtitle">Analyze customer reviews, identify product experience trends, and moderate feedback</p>
    </div>
</div>

<!-- Ratings Overview Cards -->
<div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-5 mb-6">
    <!-- Star Distribution Gauge Card -->
    <div class="adm-card lg:col-span-2">
        <div class="adm-card-body flex items-center gap-6">
            <div class="text-center px-3 flex-shrink-0">
                <p class="text-5xl font-black text-main m-0 leading-none"><?= number_format($avgRating, 1) ?></p>
                <div class="my-2.5"><?= renderStars($avgRating, 17) ?></div>
                <span class="text-[11px] text-muted-foreground block font-medium">From <?= $totalReviews ?> verified ratings</span>
            </div>
            <div class="flex-1 border-l border-border pl-5 space-y-2">
                <?php for ($star = 5; $star >= 1; $star--):
                    $cnt = $starCounts[$star] ?? 0;
                    $pct = $totalReviews > 0 ? round(($cnt / $totalReviews) * 100) : 0;
                    $barColor = ['#10b981', '#3b82f6', '#f59e0b', '#f97316', '#ef4444'][5 - $star];
                ?>
                    <div class="flex items-center gap-2 text-xs">
                        <span class="w-8 font-bold text-muted-foreground"><?= $star ?> ★</span>
                        <div class="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                            <div class="h-full rounded-full" style="width: <?= $pct ?>%; background-color: <?= $barColor ?>;"></div>
                        </div>
                        <span class="w-8 text-right font-mono font-semibold text-muted-foreground text-[11px]"><?= $cnt ?></span>
                    </div>
                <?php endfor ?>
            </div>
        </div>
    </div>

    <!-- Total Reviews Card -->
    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Total Testimonials</span>
            <div class="adm-stat-icon success">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= $totalReviews ?></div>
        <div class="adm-stat-trend">
            <span>Customer verified reviews</span>
        </div>
    </div>

    <!-- 5-Star Reviews Card -->
    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">5-Star Ratings</span>
            <div class="adm-stat-icon warning">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= $starCounts[5] ?></div>
        <div class="adm-stat-trend up">
            <span><?= $totalReviews > 0 ? round(($starCounts[5] / $totalReviews) * 100) : 0 ?>% of all feedback</span>
        </div>
    </div>

    <!-- 4-Star Reviews Card -->
    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">4-Star Ratings</span>
            <div class="adm-stat-icon info">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= $starCounts[4] ?></div>
        <div class="adm-stat-trend">
            <span>Solid positive reviews</span>
        </div>
    </div>

    <!-- Critical Reviews Card -->
    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Critical (1–2 ★)</span>
            <div class="adm-stat-icon danger">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= $starCounts[1] + $starCounts[2] ?></div>
        <div class="adm-stat-trend down">
            <span>Requires quality attention</span>
        </div>
    </div>
</div>

<!-- Feedback Stream Card -->
<div class="adm-card">
    <div class="adm-toolbar">
        <div class="adm-toolbar-group flex-1">
            <select id="fbRatingFilter" class="form-select" style="max-width: 170px;">
                <option value="all">All Star Ratings</option>
                <option value="5">5 Stars</option>
                <option value="4">4 Stars</option>
                <option value="3">3 Stars</option>
                <option value="2">2 Stars</option>
                <option value="1">1 Star</option>
            </select>
            <input id="fbSearchInput" type="search" placeholder="Search customer comment or product..." class="form-input" style="max-width: 320px;"/>
        </div>
        <div class="adm-toolbar-group">
            <button type="button" id="resetFbFilters" class="btn btn-outline btn-sm">Reset</button>
        </div>
    </div>

    <div class="adm-card-body p-0">
        <div id="feedbackList" class="divide-y divide-border">
            <?php if (empty($reviews)): ?>
                <div class="text-center py-12 text-muted-foreground text-sm">
                    No customer feedback comments registered yet.
                </div>
            <?php else:
                foreach ($reviews as $idx => $r):
                    $rv = (int)($r['reviewValue'] ?? 0);
                    $rvBadge = $rv >= 5 ? 'badge-success' : ($rv >= 4 ? 'badge-info' : ($rv >= 3 ? 'badge-warning' : 'badge-danger'));
                    $searchTerms = strtolower(($r['userName'] ?? '') . ' ' . ($r['product_title'] ?? '') . ' ' . ($r['reviewMessage'] ?? '') . ' ' . $rv);
            ?>
                <div class="p-4 hover:bg-slate-50 transition group fb-item"
                     data-rating="<?= $rv ?>"
                     data-search="<?= e($searchTerms) ?>">
                    <div class="flex items-start gap-3.5">
                        <div class="adm-avatar flex-shrink-0" style="width: 36px; height: 36px;">
                            <?= strtoupper(substr(e($r['userName'] ?? 'U'), 0, 1)) ?>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-start justify-between gap-3 flex-wrap">
                                <div>
                                    <div class="flex items-center gap-2 flex-wrap">
                                        <span class="font-bold text-sm text-main"><?= e($r['userName'] ?? 'Anonymous Buyer') ?></span>
                                        <?= renderStars($rv, 13) ?>
                                        <span class="badge <?= $rvBadge ?> text-[10px]"><?= $rv ?>★</span>
                                    </div>
                                    <p class="text-[11px] text-muted-foreground m-0 mt-0.5">
                                        <?php if (!empty($r['product_title'])): ?>
                                            <span>Target: <strong><?= e($r['product_title']) ?></strong></span>
                                            <span class="mx-1">·</span>
                                        <?php endif ?>
                                        <span><?= date('d M Y, h:i A', strtotime($r['created_at'] ?? 'now')) ?></span>
                                    </p>
                                </div>
                                <div class="flex items-center gap-1 opacity-70 group-hover:opacity-100 transition">
                                    <button type="button" class="btn btn-ghost btn-icon btn-sm text-destructive delFbBtn" data-id="<?= (int)($r['id'] ?? 0) ?>" title="Delete Feedback">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>
                                    </button>
                                </div>
                            </div>

                            <!-- Associated Product Miniature -->
                            <?php if (!empty($r['product_image']) || !empty($r['product_title'])): ?>
                                <div class="flex items-center gap-2.5 mt-2.5 mb-2 p-2 rounded-lg bg-slate-50 border border-border w-fit max-w-full">
                                    <?php if (!empty($r['product_image'])): ?>
                                        <div class="w-8 h-8 rounded border border-border overflow-hidden flex-shrink-0 bg-white">
                                            <img src="<?= e(product_image_url($r['product_image'])) ?>" alt="" class="w-full h-full object-cover"/>
                                        </div>
                                    <?php endif ?>
                                    <span class="text-xs font-semibold text-main truncate max-w-[240px]"><?= e($r['product_title'] ?? 'Product') ?></span>
                                </div>
                            <?php endif ?>

                            <!-- Feedback Message Text -->
                            <?php if (!empty($r['reviewMessage'])): ?>
                                <p class="text-xs text-slate-700 m-0 mt-2 leading-relaxed font-normal bg-white p-2.5 rounded-lg border border-border">
                                    <?= e($r['reviewMessage']) ?>
                                </p>
                            <?php else: ?>
                                <span class="text-xs italic text-muted-foreground block mt-1">(Buyer left a star rating without written text)</span>
                            <?php endif ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; endif ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const qInput = document.getElementById('fbSearchInput');
    const rFilter = document.getElementById('fbRatingFilter');

    function applyFbFilters() {
        const q = qInput.value.toLowerCase().trim();
        const r = rFilter.value;

        document.querySelectorAll('.fb-item').forEach(el => {
            const matchR = (r === 'all' || String(el.dataset.rating) === String(r));
            const matchQ = (!q || (el.dataset.search || '').includes(q));
            el.style.display = (matchR && matchQ) ? '' : 'none';
        });
    }

    qInput.addEventListener('input', applyFbFilters);
    rFilter.addEventListener('change', applyFbFilters);

    document.getElementById('resetFbFilters').addEventListener('click', () => {
        qInput.value = '';
        rFilter.value = 'all';
        applyFbFilters();
    });

    // Delete Feedback Trigger
    document.querySelectorAll('.delFbBtn').forEach(b => {
        b.onclick = () => {
            showConfirmModal({
                title: 'Delete Customer Feedback',
                message: 'Are you sure you want to permanently delete this testimonial? Product average rating will be updated.',
                confirmText: 'Delete Feedback',
                isDanger: true,
                onConfirm: async () => {
                    try {
                        await api(`/admin/reviews/${b.dataset.id}`, { method: 'DELETE' });
                        toast('Deleted', 'Feedback was successfully removed', 'success');
                        setTimeout(() => location.reload(), 400);
                    } catch(e) {}
                }
            });
        };
    });
});
</script>

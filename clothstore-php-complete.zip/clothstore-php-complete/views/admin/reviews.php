<?php
/**
 * Modern Admin Reviews Moderation
 * Customer ratings audit, content moderation, and product feedback inspection
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'reviews';

require_once __DIR__ . '/../../models/Review.php';

if (!function_exists('renderStars')) {
    function renderStars($rating = 0, $size = 15) {
        $rating = min(5, max(0, round((float)$rating)));
        $out = '<span class="stars inline-flex items-center gap-0.5">';
        for ($i = 1; $i <= 5; $i++) {
            $fill = $i <= $rating ? '#eab308' : '#e2e8f0';
            $out .= '<svg width="' . (int)$size . '" height="' . (int)$size . '" viewBox="0 0 24 24" fill="' . $fill . '" stroke="' . $fill . '" stroke-width="0"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
        }
        return $out . '</span>';
    }
}

$rm = new ReviewModel();
$reviews = $rm->findAll();
$totalReviews = count($reviews);
?>

<!-- Page Header -->
<div class="adm-page-header">
    <div class="adm-page-title-wrap">
        <h1 class="adm-page-title">Product Reviews Moderation (<?= $totalReviews ?>)</h1>
        <p class="adm-page-subtitle">Inspect customer testimonials, audit product satisfaction scores, and moderate user content</p>
    </div>
    <div class="adm-page-actions">
        <button type="button" id="exportReviewsBtn" class="btn btn-outline btn-sm">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            <span>Export Reviews (CSV)</span>
        </button>
    </div>
</div>

<!-- Table Card -->
<div class="adm-card">
    <div class="adm-toolbar">
        <div class="adm-toolbar-group flex-1">
            <select id="reviewFilter" class="form-select" style="max-width: 170px;">
                <option value="all">All Ratings</option>
                <option value="5">5 Stars</option>
                <option value="4">4 Stars</option>
                <option value="3">3 Stars</option>
                <option value="low">Critical (≤ 2 Stars)</option>
            </select>
            <input id="reviewSearch" type="search" placeholder="Search customer, comment, or product..." class="form-input" style="max-width: 320px;"/>
        </div>
        <div class="adm-toolbar-group">
            <button type="button" id="resetRevFilters" class="btn btn-outline btn-sm">Reset</button>
            <select id="revPageSize" class="form-select" style="width: auto;">
                <option value="10">10 / page</option>
                <option value="25">25 / page</option>
                <option value="50">50 / page</option>
            </select>
        </div>
    </div>

    <div class="adm-card-body p-0">
        <div class="adm-table-wrap">
            <table class="adm-table" id="reviewsTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Product</th>
                        <th>Customer</th>
                        <th>Rating Score</th>
                        <th>Feedback Message</th>
                        <th>Submitted</th>
                        <th style="text-align: right;">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($reviews as $idx => $r):
                    $rv = (int)($r['reviewValue'] ?? 0);
                    $badgeCls = $rv >= 5 ? 'badge-success' : ($rv >= 4 ? 'badge-info' : ($rv >= 3 ? 'badge-warning' : 'badge-danger'));
                    $filterClass = $rv <= 2 ? 'low' : (string)$rv;
                    $searchTerms = strtolower(($r['userName'] ?? '') . ' ' . ($r['product_title'] ?? '') . ' ' . ($r['reviewMessage'] ?? '') . ' ' . $rv);
                ?>
                    <tr class="<?= $filterClass ?>"
                        data-id="<?= (int)($r['id'] ?? $idx) ?>"
                        data-rating="<?= $rv ?>"
                        data-status="<?= $filterClass ?>"
                        data-search="<?= e($searchTerms) ?>">
                        <td class="font-mono text-xs text-muted-foreground">#<?= str_pad((int)($r['id'] ?? $idx), 5, '0', STR_PAD_LEFT) ?></td>
                        <td>
                            <div class="flex items-center gap-2.5">
                                <div class="w-10 h-10 rounded-lg bg-slate-100 border border-border overflow-hidden flex-shrink-0">
                                    <?php if (!empty($r['product_image'])): ?>
                                        <img src="<?= e(product_image_url($r['product_image'])) ?>" alt="" class="w-full h-full object-cover"/>
                                    <?php endif ?>
                                </div>
                                <div class="min-w-0">
                                    <p class="font-bold text-main text-xs m-0 truncate max-w-[190px]"><?= e($r['product_title'] ?? 'Product') ?></p>
                                    <span class="text-[10px] text-muted-foreground font-mono">PID: #<?= (int)($r['product_id'] ?? 0) ?></span>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="flex items-center gap-2">
                                <div class="adm-avatar" style="width: 28px; height: 28px; font-size: 11px;">
                                    <?= strtoupper(substr(e($r['userName'] ?? 'U'), 0, 1)) ?>
                                </div>
                                <span class="text-xs font-semibold"><?= e($r['userName'] ?? 'Anonymous') ?></span>
                            </div>
                        </td>
                        <td>
                            <div class="flex items-center gap-1.5">
                                <?= renderStars($rv, 13) ?>
                                <span class="badge <?= $badgeCls ?> text-[10px]"><?= $rv ?>★</span>
                            </div>
                        </td>
                        <td style="max-width: 280px;">
                            <?php if (!empty($r['reviewMessage'])): ?>
                                <p class="text-xs text-main m-0 line-clamp-2 leading-relaxed"><?= e($r['reviewMessage']) ?></p>
                            <?php else: ?>
                                <span class="text-xs italic text-muted-foreground">(No text comment)</span>
                            <?php endif ?>
                        </td>
                        <td class="text-xs text-muted-foreground">
                            <?= date('d M Y', strtotime($r['created_at'] ?? 'now')) ?>
                        </td>
                        <td style="text-align: right;">
                            <div class="flex items-center justify-end gap-1">
                                <button type="button" class="btn btn-outline btn-xs viewRevBtn"
                                    data-id="<?= (int)($r['id'] ?? 0) ?>"
                                    data-user="<?= e($r['userName'] ?? 'Anonymous') ?>"
                                    data-product="<?= e($r['product_title'] ?? 'Product') ?>"
                                    data-product-img="<?= e($r['product_image'] ?? '') ?>"
                                    data-rating="<?= $rv ?>"
                                    data-message="<?= e($r['reviewMessage'] ?? 'No text provided') ?>"
                                    data-date="<?= date('d M Y, h:i A', strtotime($r['created_at'] ?? 'now')) ?>"
                                    title="Inspect Review">
                                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                                    <span>Inspect</span>
                                </button>
                                <button type="button" class="btn btn-ghost btn-icon btn-sm text-destructive delRevBtn"
                                    data-id="<?= (int)($r['id'] ?? 0) ?>"
                                    title="Delete Review">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="revPagination" class="adm-pagination-bar"></div>
</div>

<!-- Review Inspection Modal -->
<div id="reviewDialog" class="dialog-overlay hidden" data-closable="true">
    <div class="dialog" style="max-width: 34rem;">
        <div class="dialog-header">
            <div>
                <h3 class="dialog-title">Review Inspection</h3>
                <p class="dialog-description" id="dlgRevDate"></p>
            </div>
            <button type="button" id="reviewDlgClose" class="btn btn-ghost btn-icon btn-sm">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>
        </div>
        <div class="dialog-content space-y-4">
            <!-- Product Preview -->
            <div class="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-border">
                <div class="w-12 h-12 rounded-lg bg-white border border-border overflow-hidden flex-shrink-0" id="dlgRevProdImg"></div>
                <div class="min-w-0">
                    <p class="text-xs font-bold text-main m-0 truncate" id="dlgRevProdTitle">-</p>
                    <span class="text-[11px] text-muted-foreground">Product Target</span>
                </div>
            </div>

            <!-- Customer & Rating -->
            <div class="grid grid-cols-2 gap-3">
                <div class="p-3 rounded-xl border border-border bg-white">
                    <span class="text-[11px] font-bold text-muted-foreground uppercase">Author</span>
                    <p class="font-bold text-xs m-0 mt-1" id="dlgRevAuthor">-</p>
                </div>
                <div class="p-3 rounded-xl border border-border bg-white">
                    <span class="text-[11px] font-bold text-muted-foreground uppercase">Rating Score</span>
                    <div class="flex items-center gap-1.5 mt-1" id="dlgRevRatingStars"></div>
                </div>
            </div>

            <!-- Full Message -->
            <div>
                <span class="text-xs font-bold text-main block mb-1.5">Customer Comment</span>
                <div class="p-3.5 rounded-xl border border-border bg-slate-50 text-xs text-main leading-relaxed" id="dlgRevMessage"></div>
            </div>
        </div>
        <div class="dialog-footer">
            <button type="button" id="reviewDlgCancel" class="btn btn-outline btn-sm">Close</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const tableCtrl = window.initAdminTable('reviewsTable', {
        searchId: 'reviewSearch',
        paginationId: 'revPagination',
        pageSizeId: 'revPageSize',
        defaultPageSize: 10,
        extraFilters: [
            { id: 'reviewFilter', attr: 'data-status' },
        ],
    });

    const revFilter = document.getElementById('reviewFilter');

    document.getElementById('resetRevFilters').addEventListener('click', () => {
        document.getElementById('reviewSearch').value = '';
        revFilter.value = 'all';
        tableCtrl.refresh();
    });

    // CSV Export
    document.getElementById('exportReviewsBtn').onclick = () => {
        window.exportTableToCSV('reviewsTable', 'reviews_moderation.csv');
        toast('Exported', 'Reviews CSV exported successfully', 'success');
    };

    // Modal Inspection Handlers
    const dlg = document.getElementById('reviewDialog');
    function closeDlg() { dlg.classList.add('hidden'); }
    document.getElementById('reviewDlgClose').onclick = closeDlg;
    document.getElementById('reviewDlgCancel').onclick = closeDlg;

    document.querySelectorAll('.viewRevBtn').forEach(b => {
        b.onclick = () => {
            document.getElementById('dlgRevDate').textContent = 'Submitted on ' + b.dataset.date;
            document.getElementById('dlgRevAuthor').textContent = b.dataset.user;
            document.getElementById('dlgRevProdTitle').textContent = b.dataset.product;
            
            const prodImgBox = document.getElementById('dlgRevProdImg');
            if (b.dataset.productImg) {
                prodImgBox.innerHTML = `<img src="${productImageUrl(b.dataset.productImg)}" class="w-full h-full object-cover"/>`;
            } else {
                prodImgBox.innerHTML = `<span class="text-[10px] text-muted-foreground p-1">No Pic</span>`;
            }

            const starsBox = document.getElementById('dlgRevRatingStars');
            const score = parseInt(b.dataset.rating || '5');
            let starsHtml = '';
            for (let i = 1; i <= 5; i++) {
                const fill = i <= score ? '#eab308' : '#e2e8f0';
                starsHtml += `<svg width="15" height="15" viewBox="0 0 24 24" fill="${fill}"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`;
            }
            starsBox.innerHTML = starsHtml + `<span class="badge badge-primary text-[10px] ml-1">${score}★</span>`;

            document.getElementById('dlgRevMessage').textContent = b.dataset.message;
            dlg.classList.remove('hidden');
        };
    });

    // Delete Review Handler (WORKING)
    document.querySelectorAll('.delRevBtn').forEach(b => {
        b.onclick = () => {
            showConfirmModal({
                title: 'Delete Customer Review',
                message: 'Permanently remove this review? The product average rating score will be recalculated.',
                confirmText: 'Delete Review',
                isDanger: true,
                onConfirm: async () => {
                    try {
                        await api(`/admin/reviews/${b.dataset.id}`, { method: 'DELETE' });
                        toast('Deleted', 'Review was removed successfully', 'success');
                        setTimeout(() => location.reload(), 400);
                    } catch(e) {}
                }
            });
        };
    });
});
</script>

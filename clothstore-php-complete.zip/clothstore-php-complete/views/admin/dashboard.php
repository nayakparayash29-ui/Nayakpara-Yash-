<?php
/**
 * Modern Admin Dashboard
 * Real-time metrics, interactive sales chart, order fulfillment & inventory alerts
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'dashboard';

require_once __DIR__ . '/../../models/Product.php';
require_once __DIR__ . '/../../models/Order.php';
require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../models/Review.php';

$pm = new ProductModel();
$om = new OrderModel();
$um = new UserModel();
$rm = new ReviewModel();

$totalRevenue  = $om->totalRevenue();
$totalOrders   = count($om->findAll());
$totalProducts = $pm->countAll();
$totalCustomers = count($um->getAll('user'));
$confirmed     = $om->countByStatus('confirmed');
$pending       = $om->countByStatus('pending');
$delivered     = $om->countByStatus('delivered');
$shipped       = $om->countByStatus('shipped');
$salesChart    = $om->salesByDate(14);
$topProducts   = $om->topSelling(5);
$recentOrders  = array_slice($om->findAll(), 0, 6);
$lowStock      = $pm->getLowStock(10);
$outOfStock    = $pm->getOutOfStock();
$totalReviews  = $rm->countAll();
?>

<!-- Page Header -->
<div class="adm-page-header">
    <div class="adm-page-title-wrap">
        <h1 class="adm-page-title">Store Overview</h1>
        <p class="adm-page-subtitle">Real-time business performance, fulfillment status, and inventory health</p>
    </div>
    <div class="adm-page-actions">
        <a href="<?= base_url('/admin/products') ?>" class="btn btn-outline btn-sm">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            <span>Add Product</span>
        </a>
        <a href="<?= base_url('/admin/orders') ?>" class="btn btn-primary btn-sm">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/></svg>
            <span>Manage Orders</span>
        </a>
    </div>
</div>

<!-- Stat Cards Grid -->
<div class="adm-stat-grid">
    <!-- Total Revenue -->
    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Total Revenue</span>
            <div class="adm-stat-icon primary">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= formatCurrency($totalRevenue) ?></div>
        <div class="adm-stat-trend up">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
            <span><?= $confirmed ?> confirmed orders</span>
        </div>
    </div>

    <!-- Total Orders -->
    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Total Orders</span>
            <div class="adm-stat-icon warning">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= number_format($totalOrders) ?></div>
        <div class="adm-stat-trend">
            <span class="badge badge-warning text-[11px] px-2"><?= $pending ?> awaiting processing</span>
        </div>
    </div>

    <!-- Active Catalog -->
    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Total Products</span>
            <div class="adm-stat-icon success">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= number_format($totalProducts) ?></div>
        <div class="adm-stat-trend">
            <span class="text-amber-600 font-semibold"><?= count($lowStock) ?> low stock</span>
            <span class="text-muted-foreground">·</span>
            <span class="text-red-600 font-semibold"><?= count($outOfStock) ?> OOS</span>
        </div>
    </div>

    <!-- Total Customers -->
    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Total Customers</span>
            <div class="adm-stat-icon info">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= number_format($totalCustomers) ?></div>
        <div class="adm-stat-trend">
            <span><?= $totalReviews ?> verified customer reviews</span>
        </div>
    </div>
</div>

<!-- Charts & Fulfillment Overview -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
    <!-- Order Progress Pipeline -->
    <div class="adm-card">
        <div class="adm-card-header">
            <div>
                <h2 class="adm-card-title">Fulfillment Pipeline</h2>
                <p class="adm-card-description">Live status distribution across orders</p>
            </div>
        </div>
        <div class="adm-card-body space-y-4">
            <?php
            $stages = [
                ['Pending Confirmation', $pending,   '#f59e0b', 'badge-warning'],
                ['Confirmed / Processing', $confirmed, '#3b82f6', 'badge-info'],
                ['Shipped / In Transit',   $shipped,   '#8b5cf6', 'badge-secondary'],
                ['Delivered Successfully', $delivered, '#10b981', 'badge-success'],
            ];
            foreach ($stages as [$label, $count, $color, $badgeCls]):
                $pct = $totalOrders > 0 ? round(($count / $totalOrders) * 100) : 0;
            ?>
                <div>
                    <div class="flex items-center justify-between text-xs mb-1.5">
                        <span class="font-semibold text-main"><?= $label ?></span>
                        <div class="flex items-center gap-1.5">
                            <span class="badge <?= $badgeCls ?> text-[10px] py-0 px-1.5"><?= $count ?></span>
                            <span class="text-muted-foreground font-mono"><?= $pct ?>%</span>
                        </div>
                    </div>
                    <div class="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                        <div class="h-full rounded-full transition-all duration-500" style="width: <?= $pct ?>%; background-color: <?= $color ?>;"></div>
                    </div>
                </div>
            <?php endforeach ?>
            
            <div class="pt-3 border-t border-border flex items-center justify-between text-xs text-muted-foreground">
                <span>Completed Fulfillment Rate</span>
                <strong class="text-emerald-600 font-bold"><?= $totalOrders > 0 ? round(($delivered / $totalOrders) * 100) : 0 ?>%</strong>
            </div>
        </div>
    </div>

    <!-- Revenue Chart (Last 14 Days) -->
    <div class="adm-card lg:col-span-2">
        <div class="adm-card-header flex items-center justify-between">
            <div>
                <h2 class="adm-card-title">Revenue Trajectory</h2>
                <p class="adm-card-description">Daily sales income overview (Last 14 days)</p>
            </div>
            <a href="<?= base_url('/admin/analytics') ?>" class="text-xs font-semibold text-primary hover:underline">Full Analytics →</a>
        </div>
        <div class="adm-card-body">
            <?php
            $maxRevenue = 100;
            foreach ($salesChart as $s) {
                if ((float)$s['revenue'] > $maxRevenue) $maxRevenue = (float)$s['revenue'];
            }
            ?>
            <div class="adm-chart">
                <?php if (empty($salesChart)): ?>
                    <div class="flex items-center justify-center w-full h-full text-muted-foreground text-sm">
                        <span>No sales records recorded yet.</span>
                    </div>
                <?php else:
                    foreach ($salesChart as $day):
                        $val = (float)$day['revenue'];
                        $hPct = max(8, round(($val / $maxRevenue) * 100));
                        $formattedDate = date('d M', strtotime($day['date']));
                ?>
                    <div class="adm-chart-col">
                        <div class="adm-chart-tip"><?= formatCurrency($val) ?></div>
                        <div class="adm-chart-track"><div class="adm-chart-bar" style="height: <?= $hPct ?>%;"></div></div>
                        <span class="adm-chart-label"><?= $formattedDate ?></span>
                    </div>
                <?php endforeach; endif ?>
            </div>
            <div class="flex items-center justify-between mt-3 text-xs text-muted-foreground">
                <span>Peak Daily Income: <strong class="text-main"><?= formatCurrency($maxRevenue) ?></strong></span>
                <span>Active 14-Day Window</span>
            </div>
        </div>
    </div>
</div>

<!-- Recent Orders & Top Selling Products -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
    <!-- Recent Orders Table -->
    <div class="adm-card lg:col-span-2">
        <div class="adm-card-header flex items-center justify-between">
            <div>
                <h2 class="adm-card-title">Recent Customer Orders</h2>
                <p class="adm-card-description">Latest transactions placed through storefront</p>
            </div>
            <a href="<?= base_url('/admin/orders') ?>" class="btn btn-outline btn-sm">View All Orders</a>
        </div>
        <div class="adm-card-body p-0">
            <div class="adm-table-wrap">
                <table class="adm-table">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Customer</th>
                            <th>Items</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Payment</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($recentOrders)): ?>
                        <tr><td colspan="6" class="text-center py-8 text-muted-foreground text-sm">No orders recorded yet.</td></tr>
                    <?php else:
                        $statusMap = [
                            'pending'   => ['warning', 'Pending'],
                            'confirmed' => ['info', 'Confirmed'],
                            'shipped'   => ['secondary', 'Shipped'],
                            'delivered' => ['success', 'Delivered'],
                            'cancelled' => ['destructive', 'Cancelled'],
                        ];
                        foreach ($recentOrders as $ro):
                            $st = $statusMap[$ro['orderStatus']] ?? ['secondary', ucfirst($ro['orderStatus'])];
                    ?>
                        <tr>
                            <td class="font-mono font-bold text-primary">
                                <a href="<?= base_url('/admin/orders') ?>" class="hover:underline">
                                    #<?= str_pad((int)$ro['id'], 6, '0', STR_PAD_LEFT) ?>
                                </a>
                            </td>
                            <td>
                                <div class="flex items-center gap-2">
                                    <div class="adm-avatar" style="width:26px;height:26px;font-size:11px;">
                                        U
                                    </div>
                                    <span class="text-xs font-semibold">User #<?= (int)$ro['userId'] ?></span>
                                </div>
                            </td>
                            <td class="text-xs text-muted-foreground"><?= count($ro['cartItems'] ?? []) ?> item(s)</td>
                            <td class="font-bold text-main"><?= formatCurrency($ro['totalAmount']) ?></td>
                            <td>
                                <span class="badge badge-<?= $st[0] ?> text-[11px]"><?= $st[1] ?></span>
                            </td>
                            <td>
                                <?php if ($ro['paymentStatus'] === 'paid'): ?>
                                    <span class="badge badge-success text-[10px]">Paid</span>
                                <?php else: ?>
                                    <span class="badge badge-warning text-[10px]">Pending</span>
                                <?php endif ?>
                            </td>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Top Selling Products -->
    <div class="adm-card">
        <div class="adm-card-header">
            <div>
                <h2 class="adm-card-title">Top Sellers</h2>
                <p class="adm-card-description">Highest volume products by revenue</p>
            </div>
        </div>
        <div class="adm-card-body space-y-3">
            <?php if (empty($topProducts)): ?>
                <p class="text-sm text-muted-foreground text-center py-6">No product sale data yet.</p>
            <?php else:
                foreach ($topProducts as $idx => $tp):
            ?>
                <div class="flex items-center gap-3 p-2 rounded-lg border border-border hover:bg-slate-50 transition">
                    <span class="text-xs font-bold text-muted-foreground w-4 text-center"><?= $idx + 1 ?></span>
                    <div class="w-11 h-11 bg-slate-100 rounded-md border border-border overflow-hidden flex-shrink-0">
                        <?php if (!empty($tp['image'])): ?>
                            <img src="<?= e(product_image_url($tp['image'])) ?>" alt="" class="w-full h-full object-cover"/>
                        <?php endif ?>
                    </div>
                    <div class="flex-1 min-w-0">
                        <p class="text-xs font-bold text-main m-0 truncate"><?= e($tp['title']) ?></p>
                        <p class="text-[11px] text-muted-foreground m-0 mt-0.5">
                            <?= (int)$tp['qty'] ?> units sold · <strong class="text-emerald-600"><?= formatCurrency($tp['revenue']) ?></strong>
                        </p>
                    </div>
                </div>
            <?php endforeach; endif ?>
        </div>
    </div>
</div>

<!-- Low Stock & Out of Stock Alerts -->
<?php if (count($lowStock) || count($outOfStock)): ?>
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <?php if (count($lowStock)): ?>
    <div class="adm-card" style="border-color: #fde68a;">
        <div class="adm-card-header" style="background:#fffbeb;">
            <div class="flex items-center gap-2">
                <span class="text-amber-600 font-bold">⚠️</span>
                <div>
                    <h3 class="adm-card-title text-amber-800">Low Stock Attention (<?= count($lowStock) ?>)</h3>
                    <p class="adm-card-description text-amber-700">Products with 10 or fewer units available</p>
                </div>
            </div>
            <a href="<?= base_url('/admin/inventory') ?>" class="btn btn-outline btn-xs">Manage Inventory</a>
        </div>
        <div class="adm-card-body space-y-2">
            <?php foreach (array_slice($lowStock, 0, 4) as $item): ?>
                <div class="flex items-center justify-between p-2 rounded-lg bg-white border border-amber-200">
                    <div class="flex items-center gap-3 min-w-0">
                        <div class="w-9 h-9 rounded bg-slate-100 overflow-hidden flex-shrink-0 border border-border">
                            <?php if (!empty($item['image'])): ?><img src="<?= e(product_image_url($item['image'])) ?>" class="w-full h-full object-cover"/><?php endif ?>
                        </div>
                        <div class="min-w-0">
                            <p class="text-xs font-bold text-main m-0 truncate"><?= e($item['title']) ?></p>
                            <p class="text-[11px] text-amber-600 m-0">Only <strong><?= (int)$item['totalStock'] ?></strong> units left</p>
                        </div>
                    </div>
                    <a href="<?= base_url('/admin/inventory') ?>" class="btn btn-outline btn-xs">Restock</a>
                </div>
            <?php endforeach ?>
        </div>
    </div>
    <?php endif ?>

    <?php if (count($outOfStock)): ?>
    <div class="adm-card" style="border-color: #fecaca;">
        <div class="adm-card-header" style="background:#fef2f2;">
            <div class="flex items-center gap-2">
                <span class="text-red-600 font-bold">🛑</span>
                <div>
                    <h3 class="adm-card-title text-red-800">Out of Stock Listings (<?= count($outOfStock) ?>)</h3>
                    <p class="adm-card-description text-red-700">Currently unavailable for customer purchases</p>
                </div>
            </div>
            <a href="<?= base_url('/admin/products') ?>" class="btn btn-outline btn-xs">Catalog</a>
        </div>
        <div class="adm-card-body space-y-2">
            <?php foreach (array_slice($outOfStock, 0, 4) as $item): ?>
                <div class="flex items-center justify-between p-2 rounded-lg bg-white border border-red-200">
                    <div class="flex items-center gap-3 min-w-0">
                        <div class="w-9 h-9 rounded bg-slate-100 overflow-hidden flex-shrink-0 border border-border grayscale opacity-60">
                            <?php if (!empty($item['image'])): ?><img src="<?= e(product_image_url($item['image'])) ?>" class="w-full h-full object-cover"/><?php endif ?>
                        </div>
                        <div class="min-w-0">
                            <p class="text-xs font-bold text-main m-0 truncate"><?= e($item['title']) ?></p>
                            <p class="text-[11px] text-red-600 m-0">Zero inventory</p>
                        </div>
                    </div>
                    <a href="<?= base_url('/admin/products') ?>" class="btn btn-danger btn-outline btn-xs">Refill</a>
                </div>
            <?php endforeach ?>
        </div>
    </div>
    <?php endif ?>
</div>
<?php endif ?>

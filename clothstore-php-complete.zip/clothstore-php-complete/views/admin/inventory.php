<?php
/**
 * Modern Admin Inventory Management Page
 * Real-time stock updates, quick restocking, out-of-stock toggles, and asset valuation
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'inventory';

require_once __DIR__ . '/../../models/Product.php';
$pm = new ProductModel();
$products = $pm->findAll();
$lowStock = $pm->getLowStock(10);
$outOfStock = $pm->getOutOfStock();

$totalSKUs = count($products);
$totalValue = 0;
foreach ($products as $p) {
    $price = (float)($p['salePrice'] > 0 ? $p['salePrice'] : $p['price']);
    $totalValue += $price * (int)($p['totalStock'] ?? 0);
}
?>

<!-- Page Header -->
<div class="adm-page-header">
    <div class="adm-page-title-wrap">
        <h1 class="adm-page-title">Inventory Management (<?= $totalSKUs ?> SKUs)</h1>
        <p class="adm-page-subtitle">Monitor catalog stock levels, replenish units, audit low-stock items, and calculate asset valuation</p>
    </div>
    <div class="adm-page-actions">
        <button type="button" id="exportInvBtn" class="btn btn-outline btn-sm">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            <span>Export Inventory (CSV)</span>
        </button>
        <a href="<?= base_url('/admin/products') ?>" class="btn btn-primary btn-sm">
            <span>Manage Catalog</span>
        </a>
    </div>
</div>

<!-- Inventory KPI Cards -->
<div class="adm-stat-grid">
    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Total Unique SKUs</span>
            <div class="adm-stat-icon primary">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= number_format($totalSKUs) ?></div>
        <div class="adm-stat-trend">
            <span>Catalog product count</span>
        </div>
    </div>

    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Low Stock Attention</span>
            <div class="adm-stat-icon warning">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= count($lowStock) ?></div>
        <div class="adm-stat-trend">
            <span class="text-amber-700">≤ 10 available units</span>
        </div>
    </div>

    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Out of Stock</span>
            <div class="adm-stat-icon danger">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= count($outOfStock) ?></div>
        <div class="adm-stat-trend">
            <span class="text-red-700">Require restocking</span>
        </div>
    </div>

    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Total Inventory Value</span>
            <div class="adm-stat-icon success">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= formatCurrency($totalValue) ?></div>
        <div class="adm-stat-trend up">
            <span>At current active selling prices</span>
        </div>
    </div>
</div>

<!-- Inventory Table Card -->
<div class="adm-card">
    <div class="adm-toolbar">
        <div class="adm-toolbar-group flex-1">
            <select id="invStockFilter" class="form-select" style="max-width: 180px;">
                <option value="all">All Inventory Statuses</option>
                <option value="instock">In Stock</option>
                <option value="low">Low Stock (≤10)</option>
                <option value="oos">Out of Stock (0)</option>
            </select>
            <input id="invSearch" type="search" placeholder="Search by product name, SKU, or brand..." class="form-input" style="max-width: 300px;"/>
        </div>
        <div class="adm-toolbar-group">
            <button type="button" id="resetInvFilters" class="btn btn-outline btn-sm">Reset</button>
            <select id="invPageSize" class="form-select" style="width: auto;">
                <option value="10">10 / page</option>
                <option value="25">25 / page</option>
                <option value="50">50 / page</option>
            </select>
        </div>
    </div>

    <div class="adm-card-body p-0">
        <div class="adm-table-wrap">
            <table class="adm-table" id="invTable">
                <thead>
                    <tr>
                        <th>Product & SKU</th>
                        <th>Category</th>
                        <th>Brand</th>
                        <th>Unit Price</th>
                        <th>Stock Count</th>
                        <th>Status</th>
                        <th style="text-align: right;">Quick Restock</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($products as $p):
                    $stock = (int)($p['totalStock'] ?? 0);
                    $price = (float)($p['salePrice'] > 0 ? $p['salePrice'] : $p['price']);
                    $filterClass = $stock === 0 ? 'oos' : ($stock <= 10 ? 'low' : 'instock');
                    $badgeCls = $stock === 0 ? 'badge-danger' : ($stock <= 10 ? 'badge-warning' : 'badge-success');
                    $badgeLbl = $stock === 0 ? 'Out of Stock' : ($stock <= 10 ? 'Low Stock' : 'In Stock');
                    $searchTerms = strtolower($p['title'] . ' ' . $p['category'] . ' ' . $p['brand'] . ' ' . $p['id']);
                ?>
                    <tr class="<?= $filterClass ?>"
                        data-id="<?= (int)$p['id'] ?>"
                        data-stock="<?= $stock ?>"
                        data-status="<?= $filterClass ?>"
                        data-search="<?= e($searchTerms) ?>">
                        <td>
                            <div class="flex items-center gap-3">
                                <div class="w-11 h-11 rounded-lg bg-slate-100 border border-border overflow-hidden flex-shrink-0">
                                    <?php if (!empty($p['image'])): ?>
                                        <img src="<?= e(product_image_url($p['image'])) ?>" alt="<?= e($p['title']) ?>" class="w-full h-full object-cover"/>
                                    <?php endif ?>
                                </div>
                                <div class="min-w-0">
                                    <p class="font-bold text-main m-0 leading-tight truncate max-w-[220px]"><?= e($p['title']) ?></p>
                                    <span class="text-[11px] text-muted-foreground font-mono">SKU: PRD-<?= str_pad((int)$p['id'], 5, '0', STR_PAD_LEFT) ?></span>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge badge-primary text-[11px]"><?= e($p['category']) ?></span>
                        </td>
                        <td class="text-xs font-semibold text-muted-foreground"><?= e($p['brand']) ?></td>
                        <td>
                            <p class="font-bold text-main text-xs m-0"><?= formatCurrency($price) ?></p>
                            <?php if ((float)$p['salePrice'] > 0): ?>
                                <span class="text-[10px] text-muted-foreground line-through"><?= formatCurrency((float)$p['price']) ?></span>
                            <?php endif ?>
                        </td>
                        <td>
                            <div class="flex items-center gap-2">
                                <span class="font-mono font-bold text-sm text-main stockCountLabel"><?= $stock ?></span>
                                <div class="w-16 h-2 bg-slate-100 rounded-full overflow-hidden">
                                    <?php $barW = min(100, round(($stock / 50) * 100)); ?>
                                    <div class="h-full rounded-full stockBar" 
                                         style="width: <?= $barW ?>%; background: <?= $stock === 0 ? '#ef4444' : ($stock <= 10 ? '#f59e0b' : '#10b981') ?>;"></div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge <?= $badgeCls ?> text-[10px] statusBadgeLabel"><?= $badgeLbl ?></span>
                        </td>
                        <td style="text-align: right;">
                            <div class="flex items-center justify-end gap-1.5 flex-wrap">
                                <!-- Real Working Restock Form -->
                                <form class="flex items-center gap-1 restockForm" data-id="<?= (int)$p['id'] ?>">
                                    <input type="number" min="1" placeholder="+Qty" class="form-input restockInput" style="width: 4rem; height: 30px; padding: 2px 6px; font-size: 12px;" required/>
                                    <button type="submit" class="btn btn-primary btn-xs" title="Add units to stock">
                                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                                        <span>Add</span>
                                    </button>
                                </form>
                                <button type="button" class="btn btn-outline btn-xs markOosBtn" data-id="<?= (int)$p['id'] ?>" title="Mark product as Out of Stock">
                                    OOS
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="invPagination" class="adm-pagination-bar"></div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Initialize Table Controller with Search, Multi-Filter, and Pagination
    const tableCtrl = window.initAdminTable('invTable', {
        searchId: 'invSearch',
        paginationId: 'invPagination',
        pageSizeId: 'invPageSize',
        defaultPageSize: 10,
        extraFilters: [
            { id: 'invStockFilter', attr: 'data-status' },
        ],
    });

    const stockFilter = document.getElementById('invStockFilter');

    document.getElementById('resetInvFilters').addEventListener('click', () => {
        document.getElementById('invSearch').value = '';
        stockFilter.value = 'all';
        tableCtrl.refresh();
    });

    // CSV Export
    document.getElementById('exportInvBtn').onclick = () => {
        window.exportTableToCSV('invTable', 'inventory_report.csv');
        toast('Exported', 'Inventory CSV report downloaded successfully', 'success');
    };

    // REAL WORKING Quick Restock Form Handler
    document.querySelectorAll('.restockForm').forEach(form => {
        form.onsubmit = async (e) => {
            e.preventDefault();
            const id = form.dataset.id;
            const input = form.querySelector('.restockInput');
            const submitBtn = form.querySelector('button[type="submit"]');
            const addQty = parseInt(input.value || '0');
            if (addQty <= 0) return;

            const row = form.closest('tr');
            const currentStock = parseInt(row.dataset.stock || '0');
            const newStock = currentStock + addQty;

            setButtonLoading(submitBtn, true, '');
            try {
                await api(`/admin/products/${id}`, {
                    method: 'PUT',
                    body: { totalStock: newStock }
                });

                // Update row in DOM
                row.dataset.stock = newStock;
                const newStatus = newStock === 0 ? 'oos' : (newStock <= 10 ? 'low' : 'instock');
                row.dataset.status = newStatus;
                row.className = newStatus;

                row.querySelector('.stockCountLabel').textContent = newStock;
                const badge = row.querySelector('.statusBadgeLabel');
                badge.className = `badge ${newStock <= 10 ? 'badge-warning' : 'badge-success'} text-[10px] statusBadgeLabel`;
                badge.textContent = newStock <= 10 ? 'Low Stock' : 'In Stock';

                const bar = row.querySelector('.stockBar');
                bar.style.width = Math.min(100, Math.round((newStock / 50) * 100)) + '%';
                bar.style.background = newStock <= 10 ? '#f59e0b' : '#10b981';

                input.value = '';
                toast('Restocked', `Added ${addQty} units. New stock is ${newStock}`, 'success');
            } catch(err) {
                // error toasted by api()
            } finally {
                setButtonLoading(submitBtn, false);
            }
        };
    });

    // REAL WORKING Mark OOS Button Handler
    document.querySelectorAll('.markOosBtn').forEach(btn => {
        btn.onclick = () => {
            const id = btn.dataset.id;
            const row = btn.closest('tr');
            showConfirmModal({
                title: 'Mark Out of Stock',
                message: 'Are you sure you want to set the stock level to 0? The item will immediately be marked as Out of Stock for customers.',
                confirmText: 'Mark 0 Stock',
                isDanger: true,
                onConfirm: async () => {
                    try {
                        await api(`/admin/products/${id}`, {
                            method: 'PUT',
                            body: { totalStock: 0 }
                        });

                        row.dataset.stock = 0;
                        row.dataset.status = 'oos';
                        row.className = 'oos';

                        row.querySelector('.stockCountLabel').textContent = 0;
                        const badge = row.querySelector('.statusBadgeLabel');
                        badge.className = 'badge badge-danger text-[10px] statusBadgeLabel';
                        badge.textContent = 'Out of Stock';

                        const bar = row.querySelector('.stockBar');
                        bar.style.width = '0%';
                        bar.style.background = '#ef4444';

                        toast('Updated', `Product #${id} marked as Out of Stock`, 'info');
                    } catch(err) {}
                }
            });
        };
    });
});
</script>

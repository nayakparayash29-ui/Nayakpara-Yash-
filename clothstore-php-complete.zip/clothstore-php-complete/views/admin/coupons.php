<?php
/**
 * Modern Admin Coupons & Discounts Management
 * Real MySQL database persistence, status toggling, code copying, and usage tracking
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'coupons';

require_once __DIR__ . '/../../models/Coupon.php';
$cm = new CouponModel();
$coupons = $cm->findAll();

$activeCount = count(array_filter($coupons, fn($c) => $c['status'] === 'active'));
$totalRedemptions = array_sum(array_column($coupons, 'usageCount'));
$expiringSoon = count(array_filter($coupons, function($c) {
    return $c['status'] === 'active' && !empty($c['expiry']) && strtotime($c['expiry']) <= strtotime('+7 days') && strtotime($c['expiry']) >= time();
}));
$percs = array_filter($coupons, fn($c) => $c['type'] === 'percent');
$avgDiscount = !empty($percs) ? round(array_sum(array_column($percs, 'value')) / count($percs)) : 0;
?>

<!-- Page Header -->
<div class="adm-page-header">
    <div class="adm-page-title-wrap">
        <h1 class="adm-page-title">Coupons & Promo Codes (<?= count($coupons) ?>)</h1>
        <p class="adm-page-subtitle">Configure checkout discounts, minimum order thresholds, and promotional campaigns</p>
    </div>
    <div class="adm-page-actions">
        <button type="button" id="createCouponBtn" class="btn btn-primary btn-sm">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            <span>Create Promo Coupon</span>
        </button>
    </div>
</div>

<!-- Coupon Stat Cards -->
<div class="adm-stat-grid">
    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Active Promo Codes</span>
            <div class="adm-stat-icon success">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= $activeCount ?></div>
        <div class="adm-stat-trend up">
            <span>Redeemable at customer checkout</span>
        </div>
    </div>

    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Total Redemptions</span>
            <div class="adm-stat-icon primary">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 12V8H6a2 2 0 0 1-2-2c0-1.1.9-2 2-2h12v4"/><path d="M4 6v12c0 1.1.9 2 2 2h14v-4"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= number_format($totalRedemptions) ?></div>
        <div class="adm-stat-trend">
            <span>All-time customer discount uses</span>
        </div>
    </div>

    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Expiring Soon</span>
            <div class="adm-stat-icon warning">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= $expiringSoon ?></div>
        <div class="adm-stat-trend">
            <span>Expires within 7 days</span>
        </div>
    </div>

    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Average Discount Rate</span>
            <div class="adm-stat-icon info">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="5" x2="5" y2="19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= $avgDiscount ?>%</div>
        <div class="adm-stat-trend">
            <span>Percentage-based coupons</span>
        </div>
    </div>
</div>

<!-- Coupons Table Card -->
<div class="adm-card">
    <div class="adm-toolbar">
        <div class="adm-toolbar-group flex-1">
            <input id="couponSearch" type="search" placeholder="Search coupon code or description..." class="form-input" style="max-width: 320px;"/>
        </div>
        <div class="adm-toolbar-group">
            <select id="couponPageSize" class="form-select" style="width: auto;">
                <option value="10">10 / page</option>
                <option value="25">25 / page</option>
            </select>
        </div>
    </div>

    <div class="adm-card-body p-0">
        <div class="adm-table-wrap">
            <table class="adm-table" id="couponsTable">
                <thead>
                    <tr>
                        <th>Coupon Code</th>
                        <th>Type</th>
                        <th>Discount Value</th>
                        <th>Min Purchase</th>
                        <th>Valid Until</th>
                        <th>Times Used</th>
                        <th>Live Status</th>
                        <th style="text-align: right;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($coupons as $c):
                    $isExpired = !empty($c['expiry']) && strtotime($c['expiry']) < time();
                    $statusBadge = $isExpired ? 'badge-danger' : ($c['status'] === 'active' ? 'badge-success' : 'badge-warning');
                    $statusLabel = $isExpired ? 'Expired' : ucfirst($c['status']);
                    $valTxt = $c['type'] === 'percent' ? ((float)$c['value']) . '%' : formatCurrency($c['value']);
                    $searchTerms = strtolower($c['code'] . ' ' . ($c['description'] ?? '') . ' ' . $c['type']);
                ?>
                    <tr data-id="<?= (int)$c['id'] ?>" data-search="<?= e($searchTerms) ?>">
                        <td>
                            <div>
                                <div class="flex items-center gap-2">
                                    <span class="font-mono font-bold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 text-xs border border-indigo-200"><?= e($c['code']) ?></span>
                                    <button type="button" class="btn btn-ghost btn-icon btn-xs copyCodeBtn" data-code="<?= e($c['code']) ?>" title="Copy coupon code">
                                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                                    </button>
                                </div>
                                <?php if (!empty($c['description'])): ?>
                                    <span class="text-[11px] text-muted-foreground block mt-1"><?= e($c['description']) ?></span>
                                <?php endif ?>
                            </div>
                        </td>
                        <td>
                            <?php if ($c['type'] === 'percent'): ?>
                                <span class="badge badge-info text-[10px]">% Percentage</span>
                            <?php else: ?>
                                <span class="badge badge-secondary text-[10px]">₹ Flat Off</span>
                            <?php endif ?>
                        </td>
                        <td class="font-bold text-main text-xs"><?= $valTxt ?></td>
                        <td>
                            <?= (float)$c['minPurchase'] > 0 ? formatCurrency($c['minPurchase']) : '<span class="text-xs text-muted-foreground">None</span>' ?>
                        </td>
                        <td class="text-xs">
                            <?= date('d M Y', strtotime($c['expiry'] ?? 'now')) ?>
                            <?php if ($isExpired): ?>
                                <span class="text-[10px] text-red-600 block font-bold">Expired</span>
                            <?php endif ?>
                        </td>
                        <td class="text-xs font-mono font-semibold text-muted-foreground"><?= number_format((int)$c['usageCount']) ?></td>
                        <td>
                            <div class="flex items-center gap-2">
                                <label class="switch">
                                    <input type="checkbox" class="toggleCouponSwitch" data-id="<?= (int)$c['id'] ?>"
                                        <?= $c['status'] === 'active' && !$isExpired ? 'checked' : '' ?>
                                        <?= $isExpired ? 'disabled' : '' ?>/>
                                    <span class="slider"></span>
                                </label>
                                <span class="badge <?= $statusBadge ?> text-[10px]"><?= $statusLabel ?></span>
                            </div>
                        </td>
                        <td style="text-align: right;">
                            <div class="flex items-center justify-end gap-1">
                                <button type="button" class="btn btn-ghost btn-icon btn-sm editCouponBtn"
                                    data-id="<?= (int)$c['id'] ?>"
                                    data-code="<?= e($c['code']) ?>"
                                    data-type="<?= e($c['type']) ?>"
                                    data-value="<?= e($c['value']) ?>"
                                    data-min="<?= e($c['minPurchase']) ?>"
                                    data-expiry="<?= e($c['expiry']) ?>"
                                    data-desc="<?= e($c['description']) ?>"
                                    title="Edit Coupon">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                </button>
                                <button type="button" class="btn btn-ghost btn-icon btn-sm text-destructive delCouponBtn"
                                    data-id="<?= (int)$c['id'] ?>"
                                    data-code="<?= e($c['code']) ?>"
                                    title="Delete Coupon">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="couponPagination" class="adm-pagination-bar"></div>
</div>

<!-- Create / Edit Coupon Modal (WORKING) -->
<div id="couponDialog" class="dialog-overlay hidden" data-closable="true">
    <div class="dialog" style="max-width: 38rem;">
        <div class="dialog-header">
            <div>
                <h3 class="dialog-title" id="couponDlgTitle">Create Promo Coupon</h3>
                <p class="dialog-description">Configure discount parameters and customer eligibility rules</p>
            </div>
            <button type="button" id="couponDlgClose" class="btn btn-ghost btn-icon btn-sm">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>
        </div>
        <form id="couponForm" class="dialog-content adm-form">
            <input type="hidden" id="cp_id"/>
            <div>
                <label class="label">Coupon Promo Code *</label>
                <input id="cp_code" type="text" required class="form-input font-mono uppercase" placeholder="e.g. FLASH30"/>
            </div>
            <div class="adm-form-grid">
                <div>
                    <label class="label">Discount Mode *</label>
                    <select id="cp_type" class="form-select" required>
                        <option value="percent">Percentage Off (%)</option>
                        <option value="flat">Flat Cash Discount (₹)</option>
                    </select>
                </div>
                <div>
                    <label class="label">Discount Value *</label>
                    <input id="cp_value" type="number" min="0" step="0.01" required class="form-input" placeholder="e.g. 25 or 500"/>
                </div>
            </div>
            <div class="adm-form-grid">
                <div>
                    <label class="label">Minimum Purchase (₹)</label>
                    <input id="cp_min" type="number" min="0" step="1" class="form-input" value="0"/>
                </div>
                <div>
                    <label class="label">Expiration Date *</label>
                    <input id="cp_expiry" type="date" required class="form-input"/>
                </div>
            </div>
            <div>
                <label class="label">Internal Description / Promo Purpose</label>
                <textarea id="cp_desc" rows="2" class="form-textarea" placeholder="e.g. Autumn promotional campaign code for registered users"></textarea>
            </div>
        </form>
        <div class="dialog-footer">
            <button type="button" id="couponDlgCancel" class="btn btn-outline btn-sm">Cancel</button>
            <button type="submit" form="couponForm" id="btnSaveCoupon" class="btn btn-primary btn-sm">Save Coupon</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    window.initAdminTable('couponsTable', {
        searchId: 'couponSearch',
        paginationId: 'couponPagination',
        pageSizeId: 'couponPageSize',
        defaultPageSize: 10,
    });

    // Copy Code Helper
    document.querySelectorAll('.copyCodeBtn').forEach(b => {
        b.onclick = async () => {
            try {
                await navigator.clipboard.writeText(b.dataset.code);
                toast('Copied', `Coupon code "${b.dataset.code}" copied to clipboard`, 'success');
            } catch(e) {
                toast('Code', b.dataset.code, 'info');
            }
        };
    });

    const dlg = document.getElementById('couponDialog');
    const form = document.getElementById('couponForm');
    const saveBtn = document.getElementById('btnSaveCoupon');

    function closeDlg() { dlg.classList.add('hidden'); }
    document.getElementById('couponDlgClose').onclick = closeDlg;
    document.getElementById('couponDlgCancel').onclick = closeDlg;

    // Reset Form for New Coupon
    document.getElementById('createCouponBtn').onclick = () => {
        form.reset();
        document.getElementById('cp_id').value = '';
        document.getElementById('couponDlgTitle').textContent = 'Create Promo Coupon';
        const d = new Date();
        d.setDate(d.getDate() + 30);
        document.getElementById('cp_expiry').value = d.toISOString().split('T')[0];
        dlg.classList.remove('hidden');
    };

    // Edit Coupon Trigger
    document.querySelectorAll('.editCouponBtn').forEach(b => {
        b.onclick = () => {
            document.getElementById('couponDlgTitle').textContent = 'Edit Coupon Parameters';
            document.getElementById('cp_id').value = b.dataset.id;
            document.getElementById('cp_code').value = b.dataset.code;
            document.getElementById('cp_type').value = b.dataset.type;
            document.getElementById('cp_value').value = b.dataset.value;
            document.getElementById('cp_min').value = b.dataset.min;
            document.getElementById('cp_expiry').value = b.dataset.expiry;
            document.getElementById('cp_desc').value = b.dataset.desc || '';
            dlg.classList.remove('hidden');
        };
    });

    // Form Submission (WORKING API)
    form.onsubmit = async (e) => {
        e.preventDefault();
        const id = document.getElementById('cp_id').value;
        const payload = {
            code: document.getElementById('cp_code').value.trim().toUpperCase(),
            type: document.getElementById('cp_type').value,
            value: parseFloat(document.getElementById('cp_value').value || 0),
            minPurchase: parseFloat(document.getElementById('cp_min').value || 0),
            expiry: document.getElementById('cp_expiry').value,
            description: document.getElementById('cp_desc').value.trim(),
        };

        setButtonLoading(saveBtn, true, 'Saving...');
        try {
            if (id) {
                await api(`/admin/coupons/${id}`, { method: 'PUT', body: payload });
                toast('Success', `Coupon "${payload.code}" updated successfully`, 'success');
            } else {
                await api('/admin/coupons', { method: 'POST', body: payload });
                toast('Success', `Coupon "${payload.code}" created successfully`, 'success');
            }
            closeDlg();
            setTimeout(() => location.reload(), 450);
        } catch(err) {
            setButtonLoading(saveBtn, false);
        }
    };

    // Toggle Status Switch (WORKING API)
    document.querySelectorAll('.toggleCouponSwitch').forEach(sw => {
        sw.onchange = async () => {
            const id = sw.dataset.id;
            try {
                await api(`/admin/coupons/${id}/toggle`, { method: 'POST' });
                toast('Status Updated', sw.checked ? 'Coupon activated' : 'Coupon paused', sw.checked ? 'success' : 'info');
                setTimeout(() => location.reload(), 400);
            } catch(e) {
                sw.checked = !sw.checked;
            }
        };
    });

    // Delete Coupon Trigger (WORKING API)
    document.querySelectorAll('.delCouponBtn').forEach(b => {
        b.onclick = () => {
            showConfirmModal({
                title: 'Delete Promo Coupon',
                message: `Are you sure you want to permanently delete coupon "<strong>${b.dataset.code}</strong>"?`,
                confirmText: 'Delete Coupon',
                isDanger: true,
                onConfirm: async () => {
                    try {
                        await api(`/admin/coupons/${b.dataset.id}`, { method: 'DELETE' });
                        toast('Deleted', 'Coupon removed successfully', 'success');
                        setTimeout(() => location.reload(), 400);
                    } catch(e) {}
                }
            });
        };
    });
});
</script>

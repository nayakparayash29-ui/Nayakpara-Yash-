<?php
/**
 * Modern Admin Store Settings Page
 * Real database persistence, tabbed configuration, payment gateways, and delivery rates
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'settings';

require_once __DIR__ . '/../../models/Setting.php';
$sm = new SettingModel();
$settings = $sm->getAll();

$tabs = [
    'general'       => ['label' => 'General Information', 'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.22.562.824 1.068 1.51 1.134.53.05 1.28.379 1.76.869"/></svg>'],
    'payments'      => ['label' => 'Payment Gateways',    'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>'],
    'shipping'      => ['label' => 'Shipping & Delivery', 'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>'],
    'notifications' => ['label' => 'Alerts & System',     'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>'],
];
$activeTab = $_GET['tab'] ?? 'general';
if (!isset($tabs[$activeTab])) $activeTab = 'general';
?>

<!-- Page Header -->
<div class="adm-page-header">
    <div class="adm-page-title-wrap">
        <h1 class="adm-page-title">Store Configuration</h1>
        <p class="adm-page-subtitle">Manage store identity, payment processors, delivery policies, and operational notifications</p>
    </div>
    <div class="adm-page-actions">
        <a href="<?= base_url('/shop/home') ?>" target="_blank" class="btn btn-outline btn-sm">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
            <span>Preview Storefront</span>
        </a>
    </div>
</div>

<div class="adm-card adm-settings">
    <nav class="adm-tabs" id="settingsTabNav">
        <?php foreach ($tabs as $key => $tab): ?>
            <button type="button"
               class="adm-tab <?= $activeTab === $key ? 'active' : '' ?>"
               data-tab="<?= $key ?>">
                <?= $tab['icon'] ?>
                <span><?= $tab['label'] ?></span>
            </button>
        <?php endforeach ?>
    </nav>

    <form id="settingsForm" class="adm-card-body adm-form">
        <!-- 1. GENERAL TAB -->
        <section class="tab-panel" data-panel="general" <?= $activeTab !== 'general' ? 'style="display:none;"' : '' ?>>
            <div class="border-b border-border pb-3 mb-4">
                <h2 class="text-sm font-bold text-main m-0">General Store Information</h2>
                <p class="text-xs text-muted-foreground m-0 mt-0.5">Used across customer invoices, storefront titles, and checkout metadata.</p>
            </div>

            <div class="adm-form-grid">
                <div>
                    <label class="label">Store Brand Name *</label>
                    <input type="text" id="s_store_name" class="form-input" value="<?= e($settings['store_name'] ?? 'ClothStore') ?>" required/>
                </div>
                <div>
                    <label class="label">Store Support Email *</label>
                    <input type="email" id="s_store_email" class="form-input" value="<?= e($settings['store_email'] ?? 'store@clothstore.com') ?>" required/>
                </div>
                <div>
                    <label class="label">Customer Care Phone</label>
                    <input type="tel" id="s_contact_phone" class="form-input" value="<?= e($settings['contact_phone'] ?? '+91 98765 43210') ?>"/>
                </div>
                <div>
                    <label class="label">Default Currency</label>
                    <select id="s_default_currency" class="form-select">
                        <option value="INR" <?= ($settings['default_currency'] ?? 'INR') === 'INR' ? 'selected' : '' ?>>Indian Rupee (₹ INR)</option>
                        <option value="USD" <?= ($settings['default_currency'] ?? '') === 'USD' ? 'selected' : '' ?>>US Dollar ($ USD)</option>
                        <option value="EUR" <?= ($settings['default_currency'] ?? '') === 'EUR' ? 'selected' : '' ?>>Euro (€ EUR)</option>
                        <option value="GBP" <?= ($settings['default_currency'] ?? '') === 'GBP' ? 'selected' : '' ?>>British Pound (£ GBP)</option>
                    </select>
                </div>
                <div class="span-2">
                    <label class="label">Physical Address</label>
                    <input type="text" id="s_address_line1" class="form-input" value="<?= e($settings['address_line1'] ?? '123 Fashion Street, MG Road') ?>"/>
                </div>
                <div>
                    <label class="label">City</label>
                    <input type="text" id="s_city" class="form-input" value="<?= e($settings['city'] ?? 'Mumbai') ?>"/>
                </div>
                <div>
                    <label class="label">State / Province</label>
                    <input type="text" id="s_state" class="form-input" value="<?= e($settings['state'] ?? 'Maharashtra') ?>"/>
                </div>
                <div>
                    <label class="label">Postal / PIN Code</label>
                    <input type="text" id="s_pincode" class="form-input" value="<?= e($settings['pincode'] ?? '400001') ?>"/>
                </div>
                <div>
                    <label class="label">Country</label>
                    <input type="text" id="s_country" class="form-input" value="<?= e($settings['country'] ?? 'India') ?>"/>
                </div>
            </div>
        </section>

        <!-- 2. PAYMENTS TAB -->
        <section class="tab-panel" data-panel="payments" <?= $activeTab !== 'payments' ? 'style="display:none;"' : '' ?>>
            <div class="border-b border-border pb-3 mb-4">
                <h2 class="text-sm font-bold text-main m-0">Payment Methods & Gateways</h2>
                <p class="text-xs text-muted-foreground m-0 mt-0.5">Control payment channels available to customers during checkout.</p>
            </div>

            <div class="space-y-4">
                <div class="p-4 rounded-xl border border-border bg-slate-50/50 space-y-3">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-lg bg-indigo-50 border border-indigo-200 text-indigo-700 flex items-center justify-center font-bold text-xs">
                                CARD
                            </div>
                            <div>
                                <p class="text-xs font-bold text-main m-0">Stripe card payments</p>
                                <p class="text-[11px] text-muted-foreground m-0">Customers pay by card on Stripe Checkout</p>
                            </div>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="s_stripe_enabled" <?= ($settings['stripe_enabled'] ?? '1') === '1' ? 'checked' : '' ?>/>
                            <span class="slider"></span>
                        </label>
                    </div>
                    <div class="adm-form-grid">
                        <div>
                            <label class="label">Publishable key</label>
                            <input type="text" id="s_stripe_key" class="form-input font-mono text-xs" placeholder="pk_test_..." value="<?= e($settings['stripe_key'] ?? '') ?>"/>
                        </div>
                        <div>
                            <label class="label">Secret key</label>
                            <div class="adm-inline-field">
                                <input type="password" id="s_stripe_secret" class="form-input font-mono text-xs" placeholder="sk_test_..." value="<?= e($settings['stripe_secret'] ?? '') ?>"/>
                                <button type="button" class="btn btn-outline btn-xs togglePasswordBtn">Reveal</button>
                            </div>
                        </div>
                    </div>
                    <p class="text-[11px] text-muted-foreground m-0">Keys come from the Stripe Dashboard. Checkout uses the secret key to open the card payment page.</p>
                </div>

                <!-- Cash on Delivery (COD) -->
                <div class="p-4 rounded-xl border border-border bg-slate-50/50 space-y-3">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center font-bold text-xs">
                                COD
                            </div>
                            <div>
                                <p class="text-xs font-bold text-main m-0">Cash on Delivery (COD)</p>
                                <p class="text-[11px] text-muted-foreground m-0">Enable buyers to pay upon doorstep delivery</p>
                            </div>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="s_cod_enabled" <?= ($settings['cod_enabled'] ?? '1') === '1' ? 'checked' : '' ?>/>
                            <span class="slider"></span>
                        </label>
                    </div>
                    <div>
                        <label class="label">Maximum Order Ceiling for COD (₹)</label>
                        <input type="number" id="s_cod_max_limit" class="form-input" style="max-width: 200px;" value="<?= e($settings['cod_max_limit'] ?? '5000') ?>"/>
                    </div>
                </div>
            </div>
        </section>

        <!-- 3. SHIPPING TAB -->
        <section class="tab-panel" data-panel="shipping" <?= $activeTab !== 'shipping' ? 'style="display:none;"' : '' ?>>
            <div class="border-b border-border pb-3 mb-4">
                <h2 class="text-sm font-bold text-main m-0">Shipping Rates & Thresholds</h2>
                <p class="text-xs text-muted-foreground m-0 mt-0.5">Define delivery fees and free shipping qualifying thresholds.</p>
            </div>

            <div class="adm-form-grid cols-3">
                <div>
                    <label class="label">Free Shipping Threshold (₹)</label>
                    <input type="number" id="s_free_shipping_threshold" class="form-input" value="<?= e($settings['free_shipping_threshold'] ?? '999') ?>" required/>
                    <span class="text-[11px] text-muted-foreground mt-1 block">Carts above this amount ship for free</span>
                </div>
                <div>
                    <label class="label">Standard Shipping Fee (₹)</label>
                    <input type="number" id="s_standard_shipping_rate" class="form-input" value="<?= e($settings['standard_shipping_rate'] ?? '79') ?>" required/>
                    <span class="text-[11px] text-muted-foreground mt-1 block">Default fee for non-qualifying carts</span>
                </div>
                <div>
                    <label class="label">Express Delivery Fee (₹)</label>
                    <input type="number" id="s_express_shipping_rate" class="form-input" value="<?= e($settings['express_shipping_rate'] ?? '149') ?>" required/>
                    <span class="text-[11px] text-muted-foreground mt-1 block">Optional next-day expedited rate</span>
                </div>
            </div>
        </section>

        <!-- 4. NOTIFICATIONS TAB -->
        <section class="tab-panel" data-panel="notifications" <?= $activeTab !== 'notifications' ? 'style="display:none;"' : '' ?>>
            <div class="border-b border-border pb-3 mb-4">
                <h2 class="text-sm font-bold text-main m-0">Automated Store Notifications</h2>
                <p class="text-xs text-muted-foreground m-0 mt-0.5">Toggle automated transactional notifications and stock alerts.</p>
            </div>

            <div class="space-y-3">
                <div class="flex items-center justify-between p-3 rounded-lg border border-border bg-white">
                    <div>
                        <p class="text-xs font-bold text-main m-0">New Order Confirmation Notification</p>
                        <p class="text-[11px] text-muted-foreground m-0">Trigger admin notification when buyer places an order</p>
                    </div>
                    <label class="switch">
                        <input type="checkbox" id="s_notif_order_placed" <?= ($settings['notif_order_placed'] ?? '1') === '1' ? 'checked' : '' ?>/>
                        <span class="slider"></span>
                    </label>
                </div>

                <div class="flex items-center justify-between p-3 rounded-lg border border-border bg-white">
                    <div>
                        <p class="text-xs font-bold text-main m-0">Low Inventory Level Alert</p>
                        <p class="text-[11px] text-muted-foreground m-0">Show alert in admin header when products fall below 10 units</p>
                    </div>
                    <label class="switch">
                        <input type="checkbox" id="s_notif_low_stock" <?= ($settings['notif_low_stock'] ?? '1') === '1' ? 'checked' : '' ?>/>
                        <span class="slider"></span>
                    </label>
                </div>

                <div class="flex items-center justify-between p-3 rounded-lg border border-border bg-white">
                    <div>
                        <p class="text-xs font-bold text-main m-0">Dispatch Notification to Customer</p>
                        <p class="text-[11px] text-muted-foreground m-0">Send update when order status transitions to 'Shipped'</p>
                    </div>
                    <label class="switch">
                        <input type="checkbox" id="s_notif_order_shipped" <?= ($settings['notif_order_shipped'] ?? '1') === '1' ? 'checked' : '' ?>/>
                        <span class="slider"></span>
                    </label>
                </div>
            </div>
        </section>

        <!-- Actions Footer -->
        <div class="adm-settings-actions">
            <button type="button" id="btnResetSettings" class="btn btn-outline btn-sm text-destructive">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>
                <span>Reset to Defaults</span>
            </button>
            <button type="submit" id="btnSaveSettings" class="btn btn-primary btn-sm">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
                <span>Save All Settings</span>
            </button>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Tab Switching Handler
    document.querySelectorAll('.adm-tab').forEach(btn => {
        btn.addEventListener('click', () => {
            const tabKey = btn.dataset.tab;
            document.querySelectorAll('.adm-tab').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            document.querySelectorAll('.tab-panel').forEach(p => {
                p.style.display = (p.dataset.panel === tabKey) ? '' : 'none';
            });

            // Update URL query state without reload
            const url = new URL(window.location.href);
            url.searchParams.set('tab', tabKey);
            window.history.replaceState({}, '', url);
        });
    });

    // Password Reveal Button
    document.querySelectorAll('.togglePasswordBtn').forEach(b => {
        b.onclick = () => {
            const inp = b.parentElement.querySelector('input');
            if (inp.type === 'password') {
                inp.type = 'text';
                b.textContent = 'Hide';
            } else {
                inp.type = 'password';
                b.textContent = 'Reveal';
            }
        };
    });

    // Form Save (WORKING API)
    const form = document.getElementById('settingsForm');
    const saveBtn = document.getElementById('btnSaveSettings');
    form.onsubmit = async (e) => {
        e.preventDefault();
        setButtonLoading(saveBtn, true, 'Saving...');

        const payload = {
            store_name: document.getElementById('s_store_name').value.trim(),
            store_email: document.getElementById('s_store_email').value.trim(),
            contact_phone: document.getElementById('s_contact_phone').value.trim(),
            default_currency: document.getElementById('s_default_currency').value,
            address_line1: document.getElementById('s_address_line1').value.trim(),
            city: document.getElementById('s_city').value.trim(),
            state: document.getElementById('s_state').value.trim(),
            pincode: document.getElementById('s_pincode').value.trim(),
            country: document.getElementById('s_country').value.trim(),
            stripe_enabled: document.getElementById('s_stripe_enabled').checked ? '1' : '0',
            stripe_key: document.getElementById('s_stripe_key').value.trim(),
            stripe_secret: document.getElementById('s_stripe_secret').value.trim(),
            cod_enabled: document.getElementById('s_cod_enabled').checked ? '1' : '0',
            cod_max_limit: document.getElementById('s_cod_max_limit').value.trim(),
            free_shipping_threshold: document.getElementById('s_free_shipping_threshold').value.trim(),
            standard_shipping_rate: document.getElementById('s_standard_shipping_rate').value.trim(),
            express_shipping_rate: document.getElementById('s_express_shipping_rate').value.trim(),
            notif_order_placed: document.getElementById('s_notif_order_placed').checked ? '1' : '0',
            notif_low_stock: document.getElementById('s_notif_low_stock').checked ? '1' : '0',
            notif_order_shipped: document.getElementById('s_notif_order_shipped').checked ? '1' : '0',
        };

        try {
            await api('/admin/settings', { method: 'POST', body: payload });
            toast('Saved', 'Store configuration saved to database successfully', 'success');
        } catch(err) {
            // Error handled by api()
        } finally {
            setButtonLoading(saveBtn, false);
        }
    };

    // Reset Defaults (WORKING API)
    document.getElementById('btnResetSettings').onclick = () => {
        showConfirmModal({
            title: 'Reset Store Settings',
            message: 'Are you sure you want to revert all settings to factory default values? Current overrides will be erased.',
            confirmText: 'Reset Defaults',
            isDanger: true,
            onConfirm: async () => {
                try {
                    await api('/admin/settings/reset', { method: 'POST' });
                    toast('Reset Complete', 'Settings reverted to defaults', 'success');
                    setTimeout(() => location.reload(), 400);
                } catch(err) {}
            }
        });
    };
});
</script>

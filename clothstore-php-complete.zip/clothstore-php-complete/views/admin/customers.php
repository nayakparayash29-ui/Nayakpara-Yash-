<?php
/**
 * Modern Admin Customers & CRM Page
 * Customer directory, profile inspection, role editing, and spend analytics
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'customers';

require_once __DIR__ . '/../../models/User.php';
require_once __DIR__ . '/../../models/Order.php';
$um = new UserModel();
$om = new OrderModel();

$users = $um->getAll('user');
$allOrders = $om->findAll();

$weekAgo = date('Y-m-d H:i:s', strtotime('-7 days'));
$newThisWeek = 0;
foreach ($users as $u) {
    if (($u['created_at'] ?? '') >= $weekAgo) $newThisWeek++;
}

$userOrderCounts = [];
$userRevenue = [];
foreach ($allOrders as $o) {
    $uid = (string)$o['userId'];
    $userOrderCounts[$uid] = ($userOrderCounts[$uid] ?? 0) + 1;
    if ($o['paymentStatus'] === 'paid') {
        $userRevenue[$uid] = ($userRevenue[$uid] ?? 0) + (float)$o['totalAmount'];
    }
}
$totalOrdersByUsers = array_sum($userOrderCounts);
$totalRevenueFromUsers = array_sum($userRevenue);
?>

<!-- Page Header -->
<div class="adm-page-header">
    <div class="adm-page-title-wrap">
        <h1 class="adm-page-title">Customers Directory (<?= count($users) ?>)</h1>
        <p class="adm-page-subtitle">Track registered buyers, analyze customer lifetime values, and manage account access</p>
    </div>
    <div class="adm-page-actions">
        <button type="button" id="exportCustBtn" class="btn btn-outline btn-sm">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            <span>Export Customers (CSV)</span>
        </button>
    </div>
</div>

<!-- Customer KPI Cards -->
<div class="adm-stat-grid">
    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Total Customers</span>
            <div class="adm-stat-icon primary">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= number_format(count($users)) ?></div>
        <div class="adm-stat-trend up">
            <span>↑ <?= $newThisWeek ?> new this week</span>
        </div>
    </div>

    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">New Registrations (7d)</span>
            <div class="adm-stat-icon warning">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= $newThisWeek ?></div>
        <div class="adm-stat-trend">
            <span>Recent buyer accounts</span>
        </div>
    </div>

    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Active Orders Placed</span>
            <div class="adm-stat-icon success">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= number_format($totalOrdersByUsers) ?></div>
        <div class="adm-stat-trend up">
            <span>From <?= count($userOrderCounts) ?> active buyers</span>
        </div>
    </div>

    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Lifetime Value (LTV)</span>
            <div class="adm-stat-icon primary">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= formatCurrency($totalRevenueFromUsers) ?></div>
        <div class="adm-stat-trend">
            <span>Avg <?= formatCurrency(count($userRevenue) ? $totalRevenueFromUsers / count($userRevenue) : 0) ?> / buyer</span>
        </div>
    </div>
</div>

<!-- Customers Table Card -->
<div class="adm-card">
    <div class="adm-toolbar">
        <div class="adm-toolbar-group flex-1">
            <input id="custSearch" type="search" placeholder="Search customer by name, email, or ID..." class="form-input" style="max-width: 320px;"/>
        </div>
        <div class="adm-toolbar-group">
            <select id="custPageSize" class="form-select" style="width: auto;">
                <option value="10">10 / page</option>
                <option value="25">25 / page</option>
                <option value="50">50 / page</option>
            </select>
        </div>
    </div>

    <div class="adm-card-body p-0">
        <div class="adm-table-wrap">
            <table class="adm-table" id="customersTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Customer</th>
                        <th>Email Address</th>
                        <th>Role</th>
                        <th>Joined Date</th>
                        <th>Orders</th>
                        <th>Total Spend</th>
                        <th style="text-align: right;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($users as $u):
                    $uid = (string)($u['id'] ?? ($u['_id'] ?? ''));
                    $orderCount = $userOrderCounts[$uid] ?? 0;
                    $spent = $userRevenue[$uid] ?? 0;
                    $searchTerms = strtolower($u['userName'] . ' ' . $u['email'] . ' ' . $uid);
                ?>
                    <tr data-id="<?= e($uid) ?>" data-search="<?= e($searchTerms) ?>">
                        <td class="font-mono text-xs text-muted-foreground">#<?= str_pad((int)$u['id'], 5, '0', STR_PAD_LEFT) ?></td>
                        <td>
                            <div class="flex items-center gap-2.5">
                                <div class="adm-avatar" style="width: 32px; height: 32px;">
                                    <?= strtoupper(substr(e($u['userName'] ?? 'U'), 0, 1)) ?>
                                </div>
                                <div class="min-w-0">
                                    <p class="font-bold text-main m-0 leading-tight truncate"><?= e($u['userName']) ?></p>
                                    <span class="text-[11px] text-muted-foreground">ID: <?= e($uid) ?></span>
                                </div>
                            </div>
                        </td>
                        <td class="text-xs">
                            <a href="mailto:<?= e($u['email']) ?>" class="text-primary hover:underline font-medium"><?= e($u['email']) ?></a>
                        </td>
                        <td>
                            <span class="badge badge-secondary text-[11px]"><?= ucfirst(e($u['role'])) ?></span>
                        </td>
                        <td class="text-xs text-muted-foreground">
                            <?= date('d M Y', strtotime($u['created_at'] ?? 'now')) ?>
                        </td>
                        <td>
                            <?php if ($orderCount > 0): ?>
                                <span class="badge badge-primary text-[10px]"><?= $orderCount ?> Order<?= $orderCount > 1 ? 's' : '' ?></span>
                            <?php else: ?>
                                <span class="text-xs text-muted-foreground">0</span>
                            <?php endif ?>
                        </td>
                        <td class="font-bold text-main text-xs">
                            <?= formatCurrency($spent) ?>
                        </td>
                        <td style="text-align: right;">
                            <div class="flex items-center justify-end gap-1">
                                <button type="button" class="btn btn-outline btn-xs viewCustBtn"
                                    data-id="<?= $uid ?>"
                                    data-name="<?= e($u['userName']) ?>"
                                    data-email="<?= e($u['email']) ?>"
                                    data-role="<?= e($u['role']) ?>"
                                    data-joined="<?= date('d M Y', strtotime($u['created_at'] ?? 'now')) ?>"
                                    data-orders="<?= $orderCount ?>"
                                    data-spent="<?= formatCurrency($spent) ?>"
                                    title="View Profile Details">
                                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                                    <span>View</span>
                                </button>
                                <button type="button" class="btn btn-ghost btn-icon btn-sm editCustBtn"
                                    data-id="<?= $uid ?>"
                                    data-name="<?= e($u['userName']) ?>"
                                    data-email="<?= e($u['email']) ?>"
                                    data-role="<?= e($u['role']) ?>"
                                    title="Edit Account Details">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                </button>
                                <button type="button" class="btn btn-ghost btn-icon btn-sm text-destructive delCustBtn"
                                    data-id="<?= $uid ?>"
                                    data-name="<?= e($u['userName']) ?>"
                                    title="Delete Customer Account">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="custPagination" class="adm-pagination-bar"></div>
</div>

<!-- View Details Modal -->
<div id="viewCustDialog" class="dialog-overlay hidden" data-closable="true">
    <div class="dialog" style="max-width: 32rem;">
        <div class="dialog-header">
            <div>
                <h3 class="dialog-title" id="vCustTitle">Customer Profile</h3>
                <p class="dialog-description" id="vCustSub"></p>
            </div>
            <button type="button" class="btn btn-ghost btn-icon btn-sm closeVCustBtn">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>
        </div>
        <div class="dialog-content space-y-4" id="vCustBody"></div>
        <div class="dialog-footer">
            <button type="button" class="btn btn-outline btn-sm closeVCustBtn">Close</button>
        </div>
    </div>
</div>

<!-- Edit Customer Modal (WORKING) -->
<div id="editCustDialog" class="dialog-overlay hidden" data-closable="true">
    <div class="dialog" style="max-width: 32rem;">
        <div class="dialog-header">
            <div>
                <h3 class="dialog-title">Edit Customer Record</h3>
                <p class="dialog-description">Update account information and system permissions</p>
            </div>
            <button type="button" class="btn btn-ghost btn-icon btn-sm closeECustBtn">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>
        </div>
        <form id="editCustForm" class="dialog-content adm-form">
            <input type="hidden" id="ec_id"/>
            <div>
                <label class="label">Username *</label>
                <input type="text" id="ec_name" required class="form-input"/>
            </div>
            <div>
                <label class="label">Email Address *</label>
                <input type="email" id="ec_email" required class="form-input"/>
            </div>
            <div>
                <label class="label">Account Role *</label>
                <select id="ec_role" class="form-select">
                    <option value="user">User (Customer)</option>
                    <option value="admin">Admin (Administrator)</option>
                </select>
            </div>
            <div>
                <label class="label">Reset Password (Optional)</label>
                <input type="password" id="ec_password" class="form-input" placeholder="Leave empty to keep existing password"/>
            </div>
        </form>
        <div class="dialog-footer">
            <button type="button" class="btn btn-outline btn-sm closeECustBtn">Cancel</button>
            <button type="submit" form="editCustForm" id="btnSaveCustomer" class="btn btn-primary btn-sm">Save Changes</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Initialize Table Controller with Search and Pagination
    window.initAdminTable('customersTable', {
        searchId: 'custSearch',
        paginationId: 'custPagination',
        pageSizeId: 'custPageSize',
        defaultPageSize: 10,
    });

    // CSV Export
    document.getElementById('exportCustBtn').onclick = () => {
        window.exportTableToCSV('customersTable', 'customers_directory.csv');
        toast('Exported', 'Customer directory CSV downloaded successfully', 'success');
    };

    // View Modal Handlers
    const vDlg = document.getElementById('viewCustDialog');
    document.querySelectorAll('.closeVCustBtn').forEach(b => b.onclick = () => vDlg.classList.add('hidden'));

    document.querySelectorAll('.viewCustBtn').forEach(b => {
        b.onclick = () => {
            document.getElementById('vCustTitle').textContent = b.dataset.name;
            document.getElementById('vCustSub').textContent = 'Registered buyer since ' + b.dataset.joined;
            document.getElementById('vCustBody').innerHTML = `
                <div class="grid grid-cols-2 gap-3">
                    <div class="p-3 rounded-xl bg-slate-50 border border-border">
                        <span class="text-[11px] font-bold text-muted-foreground uppercase">Email</span>
                        <p class="font-semibold text-xs m-0 mt-1 break-all">${b.dataset.email}</p>
                    </div>
                    <div class="p-3 rounded-xl bg-slate-50 border border-border">
                        <span class="text-[11px] font-bold text-muted-foreground uppercase">Orders Placed</span>
                        <p class="font-semibold text-xs m-0 mt-1">${b.dataset.orders}</p>
                    </div>
                    <div class="col-span-2 p-3 rounded-xl bg-indigo-50 border border-indigo-200">
                        <span class="text-[11px] font-bold text-indigo-700 uppercase">Lifetime Customer Value</span>
                        <p class="font-extrabold text-indigo-900 text-lg m-0 mt-0.5">${b.dataset.spent}</p>
                    </div>
                </div>
                <div class="p-3 rounded-xl border border-border space-y-1 text-xs">
                    <div class="flex justify-between"><span class="text-muted-foreground">User ID:</span><span class="font-mono font-bold">#${b.dataset.id}</span></div>
                    <div class="flex justify-between"><span class="text-muted-foreground">Access Role:</span><span class="badge badge-secondary text-[10px]">${b.dataset.role}</span></div>
                    <div class="flex justify-between"><span class="text-muted-foreground">Registration Date:</span><span class="font-medium">${b.dataset.joined}</span></div>
                </div>
            `;
            vDlg.classList.remove('hidden');
        };
    });

    // Edit Modal Handlers (WORKING)
    const eDlg = document.getElementById('editCustDialog');
    const eForm = document.getElementById('editCustForm');
    const saveBtn = document.getElementById('btnSaveCustomer');
    document.querySelectorAll('.closeECustBtn').forEach(b => b.onclick = () => eDlg.classList.add('hidden'));

    document.querySelectorAll('.editCustBtn').forEach(b => {
        b.onclick = () => {
            document.getElementById('ec_id').value = b.dataset.id;
            document.getElementById('ec_name').value = b.dataset.name;
            document.getElementById('ec_email').value = b.dataset.email;
            document.getElementById('ec_role').value = b.dataset.role || 'user';
            document.getElementById('ec_password').value = '';
            eDlg.classList.remove('hidden');
        };
    });

    eForm.onsubmit = async (e) => {
        e.preventDefault();
        const id = document.getElementById('ec_id').value;
        const payload = {
            userName: document.getElementById('ec_name').value.trim(),
            email: document.getElementById('ec_email').value.trim(),
            role: document.getElementById('ec_role').value,
        };
        const pwd = document.getElementById('ec_password').value.trim();
        if (pwd) payload.password = pwd;

        setButtonLoading(saveBtn, true, 'Saving...');
        try {
            await api(`/admin/users/${id}`, { method: 'PUT', body: payload });
            toast('Updated', 'Customer record updated successfully', 'success');
            eDlg.classList.add('hidden');
            setTimeout(() => location.reload(), 450);
        } catch (err) {
            setButtonLoading(saveBtn, false);
        }
    };

    // Delete Customer Trigger (WORKING)
    document.querySelectorAll('.delCustBtn').forEach(b => {
        b.onclick = () => {
            showConfirmModal({
                title: 'Delete Customer Account',
                message: `Are you sure you want to permanently delete customer <strong>${b.dataset.name}</strong>? All associated account access will be terminated.`,
                confirmText: 'Delete Account',
                isDanger: true,
                onConfirm: async () => {
                    try {
                        await api(`/admin/users/${b.dataset.id}`, { method: 'DELETE' });
                        toast('Deleted', 'Customer account was removed', 'success');
                        setTimeout(() => location.reload(), 400);
                    } catch(e) {}
                }
            });
        };
    });
});
</script>

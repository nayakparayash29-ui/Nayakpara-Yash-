<?php
/**
 * Modern Admin Categories & Brands Management
 * Full CRUD operations, product count synchronization, and visual taxonomy
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'categories';

require_once __DIR__ . '/../../models/Category.php';
$catModel = new CategoryModel();
$categories = $catModel->getCategories();
$brands = $catModel->getBrands();

$totalCatProducts = array_sum(array_column($categories, 'product_count'));
$totalBrandProducts = array_sum(array_column($brands, 'product_count'));

$catIcons = [
    'Men' => '👔', 'Women' => '👗', 'Kids' => '🧒', 'Footwear' => '👟',
    'Accessories' => '👜', 'Unisex' => '🧥', 'Shirts' => '👕', 'Pants' => '👖',
    'Jackets' => '🧥', 'Dresses' => '👗', 'Shoes' => '👞', 'Watches' => '⌚',
];
?>

<!-- Page Header -->
<div class="adm-page-header">
    <div class="adm-page-title-wrap">
        <h1 class="adm-page-title">Categories & Brands</h1>
        <p class="adm-page-subtitle">Organize store taxonomy, manage merchandise tags, and assign product classifications</p>
    </div>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <!-- Categories Column -->
    <div class="adm-card">
        <div class="adm-card-header flex items-center justify-between">
            <div>
                <h2 class="adm-card-title">Product Categories (<?= count($categories) ?>)</h2>
                <p class="adm-card-description">Store departments and product groupings</p>
            </div>
            <span class="badge badge-primary"><?= $totalCatProducts ?> Products</span>
        </div>
        <div class="adm-card-body space-y-4">
            <!-- Add Category Form (WORKING) -->
            <form id="addCatForm" class="flex gap-2">
                <div class="flex-1">
                    <input id="newCatName" type="text" placeholder="e.g. Activewear, Denim" class="form-input" required/>
                </div>
                <button type="submit" id="btnAddCat" class="btn btn-primary btn-sm">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    <span>Add Category</span>
                </button>
            </form>

            <!-- Category List -->
            <div class="space-y-2 max-h-[30rem] overflow-y-auto pr-1">
                <?php if (empty($categories)): ?>
                    <div class="text-center py-8 text-muted-foreground text-sm">No categories registered yet.</div>
                <?php else:
                    foreach ($categories as $c):
                        $cName = $c['name'];
                        $count = (int)$c['product_count'];
                        $ico = $c['icon'] ?? ($catIcons[$cName] ?? '📦');
                        $pct = $totalCatProducts > 0 ? round(($count / $totalCatProducts) * 100) : 0;
                ?>
                    <div class="p-3 rounded-xl border border-border bg-white hover:border-primary/40 hover:bg-slate-50 transition group">
                        <div class="flex items-center justify-between gap-3">
                            <div class="flex items-center gap-3 flex-1 min-w-0">
                                <div class="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 text-lg flex items-center justify-center flex-shrink-0">
                                    <?= $ico ?>
                                </div>
                                <div class="flex-1 min-w-0">
                                    <p class="font-bold text-sm text-main m-0 truncate"><?= e($cName) ?></p>
                                    <div class="flex items-center gap-2 mt-1">
                                        <div class="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden max-w-[100px]">
                                            <div class="h-full bg-primary rounded-full" style="width: <?= $pct ?>%;"></div>
                                        </div>
                                        <span class="text-[11px] text-muted-foreground whitespace-nowrap"><?= $count ?> item<?= $count !== 1 ? 's' : '' ?> (<?= $pct ?>%)</span>
                                    </div>
                                </div>
                            </div>
                            <div class="flex items-center gap-1 opacity-70 group-hover:opacity-100 transition">
                                <button type="button" class="btn btn-ghost btn-icon btn-sm editCatBtn" data-name="<?= e($cName) ?>" title="Rename Category">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                </button>
                                <button type="button" class="btn btn-ghost btn-icon btn-sm text-destructive delCatBtn" data-name="<?= e($cName) ?>" title="Delete Category">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; endif ?>
            </div>
        </div>
    </div>

    <!-- Brands Column -->
    <div class="adm-card">
        <div class="adm-card-header flex items-center justify-between">
            <div>
                <h2 class="adm-card-title">Brands Carried (<?= count($brands) ?>)</h2>
                <p class="adm-card-description">Partner manufacturers and in-house labels</p>
            </div>
            <span class="badge badge-secondary"><?= $totalBrandProducts ?> Products</span>
        </div>
        <div class="adm-card-body space-y-4">
            <!-- Add Brand Form (WORKING) -->
            <form id="addBrandForm" class="flex gap-2">
                <div class="flex-1">
                    <input id="newBrandName" type="text" placeholder="e.g. Adidas, Puma, Zara" class="form-input" required/>
                </div>
                <button type="submit" id="btnAddBrand" class="btn btn-primary btn-sm">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    <span>Add Brand</span>
                </button>
            </form>

            <!-- Brand List -->
            <div class="space-y-2 max-h-[30rem] overflow-y-auto pr-1">
                <?php if (empty($brands)): ?>
                    <div class="text-center py-8 text-muted-foreground text-sm">No brands registered yet.</div>
                <?php else:
                    foreach ($brands as $b):
                        $bName = $b['name'];
                        $bCount = (int)$b['product_count'];
                        $bInitials = strtoupper(substr(preg_replace('/[^A-Za-z0-9]/', '', $bName), 0, 2));
                        $bPct = $totalBrandProducts > 0 ? round(($bCount / $totalBrandProducts) * 100) : 0;
                ?>
                    <div class="p-3 rounded-xl border border-border bg-white hover:border-primary/40 hover:bg-slate-50 transition group">
                        <div class="flex items-center justify-between gap-3">
                            <div class="flex items-center gap-3 flex-1 min-w-0">
                                <div class="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 text-xs font-bold text-main flex items-center justify-center flex-shrink-0">
                                    <?= $bInitials ?>
                                </div>
                                <div class="flex-1 min-w-0">
                                    <p class="font-bold text-sm text-main m-0 truncate"><?= e($bName) ?></p>
                                    <div class="flex items-center gap-2 mt-1">
                                        <div class="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden max-w-[100px]">
                                            <div class="h-full bg-slate-700 rounded-full" style="width: <?= $bPct ?>%;"></div>
                                        </div>
                                        <span class="text-[11px] text-muted-foreground whitespace-nowrap"><?= $bCount ?> item<?= $bCount !== 1 ? 's' : '' ?> (<?= $bPct ?>%)</span>
                                    </div>
                                </div>
                            </div>
                            <div class="flex items-center gap-1 opacity-70 group-hover:opacity-100 transition">
                                <button type="button" class="btn btn-ghost btn-icon btn-sm editBrandBtn" data-name="<?= e($bName) ?>" title="Rename Brand">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                </button>
                                <button type="button" class="btn btn-ghost btn-icon btn-sm text-destructive delBrandBtn" data-name="<?= e($bName) ?>" title="Delete Brand">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; endif ?>
            </div>
        </div>
    </div>
</div>

<div id="renameDialog" class="dialog-overlay hidden" data-closable="true">
    <div class="dialog" style="max-width: 28rem;">
        <div class="dialog-header">
            <div>
                <h3 class="dialog-title" id="renameTitle">Rename</h3>
                <p class="dialog-description" id="renameHint">This updates every product that uses the current name.</p>
            </div>
            <button type="button" id="renameClose" class="btn btn-ghost btn-icon btn-sm">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>
        </div>
        <form id="renameForm" class="dialog-content adm-form">
            <input type="hidden" id="renameKind"/>
            <input type="hidden" id="renameOld"/>
            <div>
                <label class="label" id="renameLabel">New name</label>
                <input type="text" id="renameNew" class="form-input" required/>
            </div>
        </form>
        <div class="dialog-footer">
            <button type="button" id="renameCancel" class="btn btn-outline btn-sm">Cancel</button>
            <button type="submit" form="renameForm" id="renameSave" class="btn btn-primary btn-sm">Update</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const renameDlg = document.getElementById('renameDialog');
    const renameForm = document.getElementById('renameForm');
    function closeRename() { renameDlg.classList.add('hidden'); }
    document.getElementById('renameClose').onclick = closeRename;
    document.getElementById('renameCancel').onclick = closeRename;

    function openRename(kind, oldName) {
        document.getElementById('renameKind').value = kind;
        document.getElementById('renameOld').value = oldName;
        document.getElementById('renameNew').value = oldName;
        document.getElementById('renameTitle').textContent = kind === 'brand' ? 'Rename Brand' : 'Rename Category';
        document.getElementById('renameLabel').textContent = kind === 'brand' ? 'Brand name' : 'Category name';
        renameDlg.classList.remove('hidden');
        document.getElementById('renameNew').focus();
    }

    renameForm.onsubmit = async (e) => {
        e.preventDefault();
        const kind = document.getElementById('renameKind').value;
        const oldName = document.getElementById('renameOld').value;
        const newName = document.getElementById('renameNew').value.trim();
        if (!newName || newName === oldName) {
            closeRename();
            return;
        }
        const saveBtn = document.getElementById('renameSave');
        setButtonLoading(saveBtn, true, 'Updating...');
        try {
            const path = kind === 'brand' ? '/admin/brands' : '/admin/categories';
            await api(path, { method: 'PUT', body: { oldName, newName } });
            toast('Updated', `${kind === 'brand' ? 'Brand' : 'Category'} renamed to "${newName}"`, 'success');
            closeRename();
            setTimeout(() => location.reload(), 400);
        } catch (err) {
            setButtonLoading(saveBtn, false);
        }
    };
    // Add Category Handler (WORKING)
    const addCatForm = document.getElementById('addCatForm');
    const btnAddCat = document.getElementById('btnAddCat');
    addCatForm.onsubmit = async (e) => {
        e.preventDefault();
        const name = document.getElementById('newCatName').value.trim();
        if (!name) return;
        setButtonLoading(btnAddCat, true, 'Adding...');
        try {
            await api('/admin/categories', { method: 'POST', body: { name } });
            toast('Success', `Category "${name}" added`, 'success');
            setTimeout(() => location.reload(), 400);
        } catch(err) {
            setButtonLoading(btnAddCat, false);
        }
    };

    // Rename Category Handler (WORKING)
    document.querySelectorAll('.editCatBtn').forEach(b => {
        b.onclick = () => openRename('category', b.dataset.name);
    });

    // Delete Category Handler (WORKING)
    document.querySelectorAll('.delCatBtn').forEach(b => {
        b.onclick = () => {
            const name = b.dataset.name;
            showConfirmModal({
                title: 'Delete Category',
                message: `Delete category "<strong>${name}</strong>"? Products under this category will be marked as "Uncategorized".`,
                confirmText: 'Delete',
                isDanger: true,
                onConfirm: async () => {
                    try {
                        await api('/admin/categories', { method: 'DELETE', body: { name } });
                        toast('Deleted', `Category "${name}" removed`, 'success');
                        setTimeout(() => location.reload(), 400);
                    } catch(err) {}
                }
            });
        };
    });

    // Add Brand Handler (WORKING)
    const addBrandForm = document.getElementById('addBrandForm');
    const btnAddBrand = document.getElementById('btnAddBrand');
    addBrandForm.onsubmit = async (e) => {
        e.preventDefault();
        const name = document.getElementById('newBrandName').value.trim();
        if (!name) return;
        setButtonLoading(btnAddBrand, true, 'Adding...');
        try {
            await api('/admin/brands', { method: 'POST', body: { name } });
            toast('Success', `Brand "${name}" added`, 'success');
            setTimeout(() => location.reload(), 400);
        } catch(err) {
            setButtonLoading(btnAddBrand, false);
        }
    };

    // Rename Brand Handler (WORKING)
    document.querySelectorAll('.editBrandBtn').forEach(b => {
        b.onclick = () => openRename('brand', b.dataset.name);
    });

    // Delete Brand Handler (WORKING)
    document.querySelectorAll('.delBrandBtn').forEach(b => {
        b.onclick = () => {
            const name = b.dataset.name;
            showConfirmModal({
                title: 'Delete Brand',
                message: `Delete brand "<strong>${name}</strong>"? Products under this brand will be marked as "Generic".`,
                confirmText: 'Delete',
                isDanger: true,
                onConfirm: async () => {
                    try {
                        await api('/admin/brands', { method: 'DELETE', body: { name } });
                        toast('Deleted', `Brand "${name}" removed`, 'success');
                        setTimeout(() => location.reload(), 400);
                    } catch(err) {}
                }
            });
        };
    });
});
</script>

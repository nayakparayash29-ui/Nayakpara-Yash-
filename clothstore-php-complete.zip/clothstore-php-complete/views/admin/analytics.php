<?php
/**
 * Modern Admin Analytics & Reports Page
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'analytics';

require_once __DIR__ . '/../../models/Order.php';
require_once __DIR__ . '/../../models/Product.php';
require_once __DIR__ . '/../../models/User.php';

$om = new OrderModel();
$pm = new ProductModel();
$um = new UserModel();

$totalRevenue = $om->totalRevenue();
$totalOrders  = count($om->findAll());
$confirmed    = $om->countByStatus('confirmed');
$delivered    = $om->countByStatus('delivered');
$pending      = $om->countByStatus('pending');
$avgOrderVal  = $totalOrders > 0 ? $totalRevenue / $totalOrders : 0;
$customers    = count($um->getAll('user'));
$products     = $pm->countAll();
$conversion   = $customers > 0 ? round(($totalOrders / $customers) * 100, 1) : 0;
$sales30      = $om->salesByDate(30);
$topProducts  = $om->topSelling(10);
$lowStock     = $pm->getLowStock(15);
$outOfStock   = $pm->getOutOfStock();
?>

<!-- Page Header -->
<div class="adm-page-header">
    <div class="adm-page-title-wrap">
        <h1 class="adm-page-title">Analytics & Performance</h1>
        <p class="adm-page-subtitle">Deep dive into sales trends, average basket size, customer conversion, and catalog momentum</p>
    </div>
    <div class="adm-page-actions">
        <button type="button" class="btn btn-outline btn-sm" onclick="exportAnalyticsReport()">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            <span>Export Report (CSV)</span>
        </button>
        <a href="<?= base_url('/admin/orders') ?>" class="btn btn-primary btn-sm">
            <span>View All Orders</span>
        </a>
    </div>
</div>

<!-- Primary KPIs -->
<div class="adm-stat-grid">
    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Total Store Revenue</span>
            <div class="adm-stat-icon primary">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= formatCurrency($totalRevenue) ?></div>
        <div class="adm-stat-trend up">
            <span>Cumulative gross merchandise volume</span>
        </div>
    </div>

    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Average Order Value (AOV)</span>
            <div class="adm-stat-icon success">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= formatCurrency($avgOrderVal) ?></div>
        <div class="adm-stat-trend">
            <span>Per completed transaction</span>
        </div>
    </div>

    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Order Conversion Rate</span>
            <div class="adm-stat-icon info">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= $conversion ?>%</div>
        <div class="adm-stat-trend">
            <span>Orders / Registered Customer ratio</span>
        </div>
    </div>

    <div class="adm-stat-card">
        <div class="adm-stat-top">
            <span class="adm-stat-label">Delivered Successfully</span>
            <div class="adm-stat-icon success">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
            </div>
        </div>
        <div class="adm-stat-value"><?= number_format($delivered) ?></div>
        <div class="adm-stat-trend up">
            <span><?= $confirmed ?> confirmed · <?= $pending ?> pending</span>
        </div>
    </div>
</div>

<!-- 30-Day Revenue Trend Chart -->
<div class="adm-card mb-6">
    <div class="adm-card-header flex items-center justify-between">
        <div>
            <h2 class="adm-card-title">30-Day Sales Volume Trend</h2>
            <p class="adm-card-description">Aggregated daily revenue in Indian Rupees (₹)</p>
        </div>
        <span class="badge badge-primary">Last 30 Days</span>
    </div>
    <div class="adm-card-body">
        <?php
        $maxRev30 = 1;
        foreach ($sales30 as $s) {
            if ((float)$s['revenue'] > $maxRev30) $maxRev30 = (float)$s['revenue'];
        }
        ?>
        <div class="adm-chart">
            <?php if (empty($sales30)): ?>
                <div class="flex items-center justify-center w-full h-full text-muted-foreground text-sm">
                    No sales data recorded in the last 30 days.
                </div>
            <?php else:
                foreach ($sales30 as $day):
                    $rev = (float)$day['revenue'];
                    $heightPct = max(5, round(($rev / $maxRev30) * 100));
                    $isPeak = ($rev === $maxRev30 && $rev > 0);
            ?>
                <div class="adm-chart-col">
                    <div class="adm-chart-tip"><?= date('d M', strtotime($day['date'])) ?>: <?= formatCurrency($rev) ?></div>
                    <div class="adm-chart-track"><div class="adm-chart-bar<?= $isPeak ? ' is-peak' : '' ?>" style="height: <?= $heightPct ?>%;"></div></div>
                    <?php if (date('j', strtotime($day['date'])) % 5 === 0 || $day === end($sales30)): ?>
                        <span class="adm-chart-label"><?= date('d M', strtotime($day['date'])) ?></span>
                    <?php else: ?>
                        <span class="adm-chart-label" style="visibility:hidden;">.</span>
                    <?php endif ?>
                </div>
            <?php endforeach; endif ?>
        </div>
        <div class="flex items-center justify-between mt-3 text-xs text-muted-foreground">
            <span>Peak 30-Day Day: <strong class="text-emerald-600 font-bold"><?= formatCurrency($maxRev30) ?></strong></span>
            <span>Hover on bars to inspect daily revenue figures</span>
        </div>
    </div>
</div>

<!-- Product Performance & Inventory Health -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    <!-- Top 10 Selling Products -->
    <div class="adm-card">
        <div class="adm-card-header flex items-center justify-between">
            <div>
                <h2 class="adm-card-title">Top 10 Performing Products</h2>
                <p class="adm-card-description">Sorted by cumulative revenue</p>
            </div>
            <a href="<?= base_url('/admin/products') ?>" class="text-xs font-semibold text-primary hover:underline">Manage Catalog →</a>
        </div>
        <div class="adm-card-body p-0">
            <div class="adm-table-wrap">
                <table class="adm-table" id="topProductsTable">
                    <thead>
                        <tr>
                            <th style="width: 40px;">#</th>
                            <th>Product</th>
                            <th>Units Sold</th>
                            <th>Revenue</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($topProducts)): ?>
                        <tr><td colspan="4" class="text-center py-8 text-muted-foreground text-sm">No sales data recorded yet.</td></tr>
                    <?php else: $rank = 1; foreach ($topProducts as $tp): ?>
                        <tr>
                            <td class="font-bold text-muted-foreground text-xs"><?= $rank++ ?></td>
                            <td>
                                <div class="flex items-center gap-2.5">
                                    <div class="w-9 h-9 rounded bg-slate-100 border border-border overflow-hidden flex-shrink-0">
                                        <?php if (!empty($tp['image'])): ?>
                                            <img src="<?= e(product_image_url($tp['image'])) ?>" alt="" class="w-full h-full object-cover"/>
                                        <?php endif ?>
                                    </div>
                                    <span class="text-xs font-bold text-main truncate max-w-[200px]"><?= e($tp['title']) ?></span>
                                </div>
                            </td>
                            <td class="font-mono text-xs"><?= (int)$tp['qty'] ?> units</td>
                            <td class="font-bold text-emerald-600"><?= formatCurrency($tp['revenue']) ?></td>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Inventory Health Status -->
    <div class="adm-card">
        <div class="adm-card-header">
            <div>
                <h2 class="adm-card-title">Inventory Health Breakdown</h2>
                <p class="adm-card-description">Stock level status across catalog SKUs</p>
            </div>
            <a href="<?= base_url('/admin/inventory') ?>" class="btn btn-outline btn-xs">Full Inventory</a>
        </div>
        <div class="adm-card-body space-y-5">
            <?php
            $inStockCount = max(0, $products - count($lowStock) - count($outOfStock));
            $inStockPct   = $products > 0 ? round(($inStockCount / $products) * 100) : 0;
            $lowStockPct  = $products > 0 ? round((count($lowStock) / $products) * 100) : 0;
            $oosPct       = $products > 0 ? round((count($outOfStock) / $products) * 100) : 0;
            ?>
            <div class="grid grid-cols-3 gap-3 text-center">
                <div class="p-3 rounded-xl border border-emerald-200 bg-emerald-50/60">
                    <span class="text-xs font-semibold text-emerald-700">Healthy Stock</span>
                    <p class="text-2xl font-extrabold text-emerald-800 m-0 mt-1"><?= $inStockCount ?></p>
                    <span class="text-[11px] text-emerald-600"><?= $inStockPct ?>%</span>
                </div>
                <div class="p-3 rounded-xl border border-amber-200 bg-amber-50/60">
                    <span class="text-xs font-semibold text-amber-700">Low Stock</span>
                    <p class="text-2xl font-extrabold text-amber-800 m-0 mt-1"><?= count($lowStock) ?></p>
                    <span class="text-[11px] text-amber-600"><?= $lowStockPct ?>%</span>
                </div>
                <div class="p-3 rounded-xl border border-red-200 bg-red-50/60">
                    <span class="text-xs font-semibold text-red-700">Out of Stock</span>
                    <p class="text-2xl font-extrabold text-red-800 m-0 mt-1"><?= count($outOfStock) ?></p>
                    <span class="text-[11px] text-red-600"><?= $oosPct ?>%</span>
                </div>
            </div>

            <div class="space-y-2">
                <div class="flex justify-between text-xs font-semibold text-main">
                    <span>Stock Distribution Ratio</span>
                    <span><?= $products ?> Total SKUs</span>
                </div>
                <div class="h-2.5 w-full bg-slate-100 rounded-full overflow-hidden flex">
                    <div style="width: <?= $inStockPct ?>%; background: #10b981;" title="In Stock (<?= $inStockPct ?>%)"></div>
                    <div style="width: <?= $lowStockPct ?>%; background: #f59e0b;" title="Low Stock (<?= $lowStockPct ?>%)"></div>
                    <div style="width: <?= $oosPct ?>%; background: #ef4444;" title="Out of Stock (<?= $oosPct ?>%)"></div>
                </div>
            </div>

            <div>
                <h3 class="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2">Priority Restock Queue</h3>
                <div class="space-y-2 max-h-48 overflow-y-auto">
                    <?php if (empty($lowStock)): ?>
                        <p class="text-xs text-muted-foreground py-2">✨ All items are well-stocked.</p>
                    <?php else: foreach (array_slice($lowStock, 0, 4) as $p): ?>
                        <div class="flex items-center justify-between p-2 rounded-lg border border-border hover:bg-slate-50 transition text-xs">
                            <span class="font-semibold text-main truncate max-w-[240px]"><?= e($p['title']) ?></span>
                            <span class="badge badge-warning text-[10px]"><?= (int)$p['totalStock'] ?> left</span>
                        </div>
                    <?php endforeach; endif ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function exportAnalyticsReport() {
    window.exportTableToCSV('topProductsTable', 'top_selling_products.csv');
    toast('Exported', 'Top products CSV downloaded successfully', 'success');
}
</script>

<?php
/**
 * Modern Admin Products Catalog (CRUD & Inventory Management)
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'products';

require_once __DIR__ . '/../../models/Product.php';
$pm = new ProductModel();
$products = $pm->findAll();
$categories = $pm->getDistinctCategories();
$brands = $pm->getDistinctBrands();
?>

<!-- Page Header -->
<div class="adm-page-header">
    <div class="adm-page-title-wrap">
        <h1 class="adm-page-title">Products Catalog (<?= count($products) ?>)</h1>
        <p class="adm-page-subtitle">Create, organize, price, and maintain your store's clothing inventory</p>
    </div>
    <div class="adm-page-actions">
        <button type="button" id="addProductBtn" class="btn btn-primary btn-sm">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            <span>Add New Product</span>
        </button>
    </div>
</div>

<!-- Table & Filter Card -->
<div class="adm-card">
    <!-- Toolbar -->
    <div class="adm-toolbar">
        <div class="adm-toolbar-group flex-1">
            <input id="prodSearch" type="search" placeholder="Search by title, brand, or category..." class="form-input" style="max-width: 280px;"/>
            
            <select id="prodCategoryFilter" class="form-select" style="max-width: 170px;">
                <option value="all">All Categories</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= e($cat) ?>"><?= e($cat) ?></option>
                <?php endforeach ?>
            </select>

            <select id="prodBrandFilter" class="form-select" style="max-width: 160px;">
                <option value="all">All Brands</option>
                <?php foreach ($brands as $brand): ?>
                    <option value="<?= e($brand) ?>"><?= e($brand) ?></option>
                <?php endforeach ?>
            </select>

            <select id="prodStockFilter" class="form-select" style="max-width: 150px;">
                <option value="all">All Stock</option>
                <option value="instock">In Stock</option>
                <option value="low">Low Stock (≤10)</option>
                <option value="oos">Out of Stock</option>
            </select>
        </div>

        <div class="adm-toolbar-group">
            <button type="button" id="resetProdFilters" class="btn btn-outline btn-sm">Reset</button>
            <select id="prodPageSize" class="form-select" style="width: auto;">
                <option value="10">10 / page</option>
                <option value="25">25 / page</option>
                <option value="50">50 / page</option>
            </select>
        </div>
    </div>

    <!-- Catalog Table -->
    <div class="adm-card-body p-0">
        <div class="adm-table-wrap">
            <table class="adm-table" id="productsTable">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Category</th>
                        <th>Brand</th>
                        <th>Price</th>
                        <th>Sale Price</th>
                        <th>Stock Status</th>
                        <th>Rating</th>
                        <th style="text-align: right;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($products as $p):
                    $stock = (int)($p['totalStock'] ?? 0);
                    $stockClass = $stock === 0 ? 'oos' : ($stock <= 10 ? 'low' : 'instock');
                    $badgeCls = $stock === 0 ? 'badge-danger' : ($stock <= 10 ? 'badge-warning' : 'badge-success');
                    $badgeLabel = $stock === 0 ? 'Out of Stock' : ($stock <= 10 ? 'Low Stock' : 'In Stock');
                    $searchTerms = strtolower($p['title'] . ' ' . $p['category'] . ' ' . $p['brand'] . ' ' . $p['id']);
                ?>
                    <tr class="<?= $stockClass ?>" 
                        data-id="<?= (int)$p['id'] ?>"
                        data-category="<?= e($p['category']) ?>"
                        data-brand="<?= e($p['brand']) ?>"
                        data-status="<?= $stockClass ?>"
                        data-search="<?= e($searchTerms) ?>">
                        <td>
                            <div class="flex items-center gap-3">
                                <div class="w-12 h-12 bg-slate-100 rounded-lg border border-border overflow-hidden flex-shrink-0">
                                    <?php if (!empty($p['image'])): ?>
                                        <img src="<?= e(product_image_url($p['image'])) ?>" alt="<?= e($p['title']) ?>" class="w-full h-full object-cover"/>
                                    <?php else: ?>
                                        <div class="w-full h-full flex items-center justify-center text-muted-foreground text-xs">No Img</div>
                                    <?php endif ?>
                                </div>
                                <div class="min-w-0">
                                    <p class="font-bold text-main m-0 leading-tight truncate max-w-[220px]"><?= e($p['title']) ?></p>
                                    <span class="text-[11px] text-muted-foreground font-mono">SKU #<?= str_pad((int)$p['id'], 5, '0', STR_PAD_LEFT) ?></span>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge badge-primary text-[11px]"><?= e($p['category']) ?></span>
                        </td>
                        <td class="text-xs font-semibold text-muted-foreground"><?= e($p['brand']) ?></td>
                        <td class="font-bold text-main text-xs"><?= formatCurrency($p['price']) ?></td>
                        <td>
                            <?php if ((float)$p['salePrice'] > 0): ?>
                                <span class="font-bold text-emerald-600 text-xs"><?= formatCurrency($p['salePrice']) ?></span>
                            <?php else: ?>
                                <span class="text-xs text-muted-foreground">-</span>
                            <?php endif ?>
                        </td>
                        <td>
                            <div class="flex items-center gap-2">
                                <span class="badge <?= $badgeCls ?> text-[10px]"><?= $badgeLabel ?></span>
                                <span class="text-xs font-mono font-bold text-main"><?= $stock ?></span>
                            </div>
                        </td>
                        <td>
                            <span class="flex items-center gap-1 text-xs font-bold text-amber-600">
                                ⭐ <?= number_format((float)($p['averageReview'] ?? 0), 1) ?>
                            </span>
                        </td>
                        <td style="text-align: right;">
                            <div class="flex items-center justify-end gap-1">
                                <button type="button" class="btn btn-ghost btn-icon btn-sm editProdBtn" data-id="<?= (int)$p['id'] ?>" title="Edit Product">
                                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                </button>
                                <button type="button" class="btn btn-ghost btn-icon btn-sm text-destructive delProdBtn" data-id="<?= (int)$p['id'] ?>" title="Delete Product">
                                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination Footer -->
    <div id="prodPagination" class="adm-pagination-bar"></div>
</div>

<!-- Add / Edit Product Modal -->
<div id="productDialog" class="dialog-overlay hidden" data-closable="true">
    <div class="dialog" style="max-width: 44rem;">
        <div class="dialog-header">
            <div>
                <h3 class="dialog-title" id="productDlgTitle">Add New Product</h3>
                <p class="dialog-description">Configure product identity, pricing, and stock levels</p>
            </div>
            <button type="button" id="productDlgClose" class="btn btn-ghost btn-icon btn-sm" title="Close dialog">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>
        </div>
        <form id="productForm" class="dialog-content adm-form">
            <input type="hidden" id="f_id"/>
            
            <!-- Image Uploader -->
            <div>
                <label class="label">Product Media</label>
                <div id="imagePreviewBox" class="adm-upload">
                    <div class="text-center text-muted-foreground" id="imagePreviewPlaceholder">
                        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="mx-auto mb-1"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                        <p class="text-xs font-semibold m-0">Click or Drag & Drop image file</p>
                        <p class="text-[11px] m-0 text-subtle mt-0.5">JPEG, WebP, PNG up to 10MB</p>
                    </div>
                </div>
                <input type="hidden" id="f_image"/>
                <input type="file" id="imageFileInput" accept="image/*" class="hidden"/>
            </div>

            <div class="adm-form-grid">
                <div class="span-2">
                    <label class="label">Product Title *</label>
                    <input id="f_title" type="text" required class="form-input" placeholder="e.g. Classic Oxford Cotton Shirt"/>
                </div>
                <div>
                    <label class="label">Brand *</label>
                    <input id="f_brand" required list="brandList" class="form-input" placeholder="e.g. Nike, Highlander"/>
                    <datalist id="brandList">
                        <?php foreach ($brands as $b): ?><option value="<?= e($b) ?>"/><?php endforeach ?>
                    </datalist>
                </div>
                <div>
                    <label class="label">Category *</label>
                    <input id="f_category" required list="catList" class="form-input" placeholder="e.g. Men, Women, Footwear"/>
                    <datalist id="catList">
                        <?php foreach ($categories as $c): ?><option value="<?= e($c) ?>"/><?php endforeach ?>
                    </datalist>
                </div>
                <div>
                    <label class="label">Regular Price (₹) *</label>
                    <input type="number" id="f_price" min="0" step="0.01" required class="form-input" placeholder="999.00"/>
                </div>
                <div>
                    <label class="label">Sale / Discounted Price (₹)</label>
                    <input type="number" id="f_salePrice" min="0" step="0.01" class="form-input" placeholder="Leave blank if no sale"/>
                </div>
                <div>
                    <label class="label">Total Stock Quantity *</label>
                    <input type="number" id="f_totalStock" min="0" required class="form-input" placeholder="50"/>
                </div>
                <div>
                    <label class="label">Average Rating</label>
                    <input type="number" id="f_avg" min="0" max="5" step="0.1" class="form-input" placeholder="4.5"/>
                </div>
                <div class="span-2">
                    <label class="label">Description *</label>
                    <textarea id="f_description" required rows="3" class="form-textarea" placeholder="Detailed product specifications, materials, and sizing..."></textarea>
                </div>
            </div>

        </form>
        <div class="dialog-footer">
            <button type="button" id="productDlgCancel" class="btn btn-outline btn-sm">Cancel</button>
            <button type="submit" form="productForm" id="productDlgSubmit" class="btn btn-primary btn-sm">Save Product</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Initialize Table Controller with Search, Multi-Filter, and Pagination
    const tableCtrl = window.initAdminTable('productsTable', {
        searchId: 'prodSearch',
        paginationId: 'prodPagination',
        pageSizeId: 'prodPageSize',
        defaultPageSize: 10,
        extraFilters: [
            { id: 'prodCategoryFilter', attr: 'data-category' },
            { id: 'prodBrandFilter', attr: 'data-brand' },
            { id: 'prodStockFilter', attr: 'data-status' },
        ],
    });

    const catFilter = document.getElementById('prodCategoryFilter');
    const brandFilter = document.getElementById('prodBrandFilter');
    const stockFilter = document.getElementById('prodStockFilter');

    document.getElementById('resetProdFilters').addEventListener('click', () => {
        document.getElementById('prodSearch').value = '';
        catFilter.value = 'all';
        brandFilter.value = 'all';
        stockFilter.value = 'all';
        tableCtrl.refresh();
    });

    // Dialog References
    const dlg = document.getElementById('productDialog');
    const form = document.getElementById('productForm');
    const submitBtn = document.getElementById('productDlgSubmit');
    const previewBox = document.getElementById('imagePreviewBox');
    const fileInput = document.getElementById('imageFileInput');

    function closeDlg() { dlg.classList.add('hidden'); }
    document.getElementById('productDlgClose').onclick = closeDlg;
    document.getElementById('productDlgCancel').onclick = closeDlg;

    // Reset Form for New Product
    document.getElementById('addProductBtn').onclick = () => {
        form.reset();
        document.getElementById('f_id').value = '';
        document.getElementById('f_image').value = '';
        document.getElementById('productDlgTitle').textContent = 'Add New Product';
        previewBox.innerHTML = `
            <div class="text-center text-muted-foreground" id="imagePreviewPlaceholder">
                <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="mx-auto mb-1"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                <p class="text-xs font-semibold m-0">Click or Drag & Drop image file</p>
                <p class="text-[11px] m-0 text-subtle mt-0.5">JPEG, WebP, PNG up to 10MB</p>
            </div>`;
        dlg.classList.remove('hidden');
    };

    // File Upload Handler (Uses relative API_BASE)
    previewBox.onclick = () => fileInput.click();
    fileInput.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const fd = new FormData();
        fd.append('image', file);

        previewBox.innerHTML = `<span class="adm-spinner" style="border-color:#4f46e5;border-top-color:transparent;width:28px;height:28px;"></span>`;

        try {
            const uploadUrl = (window.APP_BASE || '') + '/api/admin/products/upload';
            const res = await fetch(uploadUrl, { method: 'POST', body: fd, credentials: 'include' });
            const data = await res.json();
            if (data.success && data.data && data.data.url) {
                document.getElementById('f_image').value = data.data.url;
                previewBox.innerHTML = `<img src="${productImageUrl(data.data.url)}" class="w-full h-full object-contain"/>`;
                toast('Uploaded', 'Product image uploaded successfully', 'success');
            } else {
                toast('Upload Failed', data.message || 'Error uploading file', 'error');
                previewBox.innerHTML = `<p class="text-xs text-red-500 m-0">Upload failed. Click to retry.</p>`;
            }
        } catch (err) {
            toast('Upload Error', 'Failed to connect to server', 'error');
            previewBox.innerHTML = `<p class="text-xs text-red-500 m-0">Upload failed. Click to retry.</p>`;
        }
    };

    // Edit Product Trigger
    document.querySelectorAll('.editProdBtn').forEach(b => {
        b.onclick = async () => {
            document.getElementById('productDlgTitle').textContent = 'Edit Product';
            setButtonLoading(b, true);
            try {
                const res = await api('/admin/products');
                const p = (res.data || []).find(x => x.id == b.dataset.id || x._id == b.dataset.id);
                setButtonLoading(b, false);
                if (!p) { toast('Error', 'Product record not found', 'error'); return; }

                document.getElementById('f_id').value = p.id || p._id;
                document.getElementById('f_title').value = p.title || '';
                document.getElementById('f_brand').value = p.brand || '';
                document.getElementById('f_category').value = p.category || '';
                document.getElementById('f_price').value = p.price ?? '';
                document.getElementById('f_salePrice').value = p.salePrice ?? '';
                document.getElementById('f_totalStock').value = p.totalStock ?? 0;
                document.getElementById('f_avg').value = p.averageReview ?? 0;
                document.getElementById('f_description').value = p.description || '';
                document.getElementById('f_image').value = p.image || '';

                if (p.image) {
                    previewBox.innerHTML = `<img src="${productImageUrl(p.image)}" class="w-full h-full object-contain"/>`;
                } else {
                    previewBox.innerHTML = `<p class="text-xs text-muted-foreground m-0">No image attached. Click to upload.</p>`;
                }
                dlg.classList.remove('hidden');
            } catch (err) {
                setButtonLoading(b, false);
            }
        };
    });

    // Delete Product Trigger
    document.querySelectorAll('.delProdBtn').forEach(b => {
        b.onclick = () => {
            showConfirmModal({
                title: 'Delete Product',
                message: 'Are you sure you want to permanently delete this product? All catalog references will be removed.',
                confirmText: 'Delete',
                isDanger: true,
                onConfirm: async () => {
                    try {
                        await api(`/admin/products/${b.dataset.id}`, { method: 'DELETE' });
                        toast('Deleted', 'Product was successfully removed', 'success');
                        setTimeout(() => location.reload(), 400);
                    } catch (e) {}
                }
            });
        };
    });

    // Form Submission
    form.onsubmit = async (e) => {
        e.preventDefault();
        const id = document.getElementById('f_id').value;
        const payload = {
            image: document.getElementById('f_image').value,
            title: document.getElementById('f_title').value.trim(),
            brand: document.getElementById('f_brand').value.trim(),
            category: document.getElementById('f_category').value.trim(),
            description: document.getElementById('f_description').value.trim(),
            price: parseFloat(document.getElementById('f_price').value || 0),
            salePrice: parseFloat(document.getElementById('f_salePrice').value || 0),
            totalStock: parseInt(document.getElementById('f_totalStock').value || 0),
            averageReview: parseFloat(document.getElementById('f_avg').value || 0),
        };

        setButtonLoading(submitBtn, true, 'Saving...');
        try {
            if (id) {
                await api(`/admin/products/${id}`, { method: 'PUT', body: payload });
                toast('Success', 'Product updated successfully', 'success');
            } else {
                await api('/admin/products', { method: 'POST', body: payload });
                toast('Success', 'Product created successfully', 'success');
            }
            closeDlg();
            setTimeout(() => location.reload(), 450);
        } catch (err) {
            setButtonLoading(submitBtn, false);
        }
    };
});
</script>

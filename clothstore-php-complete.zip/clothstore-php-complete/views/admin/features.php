<?php
/**
 * Modern Admin Banners / Features Management
 * Homepage carousel promos, marketing creatives, and image hosting
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'features';

require_once __DIR__ . '/../../models/Feature.php';
$fm = new FeatureModel();
$banners = $fm->findAll();
?>

<!-- Page Header -->
<div class="adm-page-header">
    <div class="adm-page-title-wrap">
        <h1 class="adm-page-title">Homepage Banners & Features (<?= count($banners) ?>)</h1>
        <p class="adm-page-subtitle">Curate high-impact hero carousel images and promotional announcements on the storefront</p>
    </div>
    <div class="adm-page-actions">
        <button type="button" id="addBannerBtn" class="btn btn-primary btn-sm">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            <span>Upload New Banner</span>
        </button>
    </div>
</div>

<!-- Banner Gallery Card -->
<div class="adm-card mb-6">
    <div class="adm-card-header flex items-center justify-between">
        <div>
            <h2 class="adm-card-title">Live Homepage Carousel</h2>
            <p class="adm-card-description">Displayed sequentially to visitors on the shop homepage</p>
        </div>
        <span class="badge badge-primary"><?= count($banners) ?> Active Slides</span>
    </div>
    <div class="adm-card-body">
        <?php if (empty($banners)): ?>
            <div class="text-center py-12 text-muted-foreground">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="mx-auto mb-3 opacity-40"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                <p class="m-0 text-sm font-semibold text-main">No banners uploaded yet.</p>
                <p class="m-0 text-xs text-muted-foreground mt-1">Upload wide images (1600 × 700 px) to showcase seasonal promotions.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5" id="bannerGrid">
                <?php foreach ($banners as $idx => $b): ?>
                    <div class="adm-banner-card" data-id="<?= (int)$b['id'] ?>">
                        <?php if (!empty($b['image'])): ?>
                            <img src="<?= e(product_image_url($b['image'])) ?>" alt="Banner <?= $idx + 1 ?>"/>
                        <?php else: ?>
                            <div class="w-full h-full flex items-center justify-center text-muted-foreground text-xs">No Image</div>
                        <?php endif ?>
                        <div class="absolute top-2.5 left-2.5 pointer-events-none">
                            <span class="badge badge-secondary">Slide #<?= $idx + 1 ?></span>
                        </div>
                        <div class="adm-banner-actions">
                            <button type="button" class="btn btn-sm btn-outline editBannerBtn"
                                data-id="<?= (int)$b['id'] ?>"
                                data-image="<?= e($b['image'] ?? '') ?>"
                                title="Replace image">
                                Replace
                            </button>
                            <button type="button" class="btn btn-sm btn-destructive deleteBannerBtn"
                                data-id="<?= (int)$b['id'] ?>"
                                title="Delete banner">
                                Delete
                            </button>
                        </div>
                    </div>
                <?php endforeach ?>
            </div>
        <?php endif ?>
    </div>
</div>

<!-- Recommendations Card -->
<div class="adm-card">
    <div class="adm-card-header">
        <h3 class="adm-card-title">Banner Dimensions & Best Practices</h3>
    </div>
    <div class="adm-card-body">
        <ul class="text-xs text-muted-foreground space-y-1.5 m-0 pl-5">
            <li>Optimal dimensions: <strong>1600 × 700 px</strong> (or roughly 21:9 wide aspect ratio) for crisp display on high-DPI displays.</li>
            <li>Supported formats: WebP, JPEG, PNG (WebP offers the best compression-to-quality ratio).</li>
            <li>Max file size: 10MB per uploaded asset.</li>
            <li>Recommended quantity: 3 to 5 banners ensures optimal engagement without degrading mobile network load times.</li>
        </ul>
    </div>
</div>

<!-- Add / Replace Banner Modal -->
<div id="bannerDialog" class="dialog-overlay hidden" data-closable="true">
    <div class="dialog" style="max-width: 36rem;">
        <div class="dialog-header">
            <div>
                <h3 class="dialog-title" id="bannerDlgTitle">Add New Banner</h3>
                <p class="dialog-description">Upload high-resolution image for hero carousel</p>
            </div>
            <button type="button" id="bannerDlgClose" class="btn btn-ghost btn-icon btn-sm">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>
        </div>
        <form id="bannerForm" class="dialog-content adm-form">
            <input type="hidden" id="b_id"/>
            <div>
                <label class="label">Banner Image *</label>
                <div id="bannerPreviewBox" class="adm-upload">
                    <div class="text-center text-muted-foreground" id="bannerPlaceholder">
                        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="mx-auto mb-1"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                        <p class="text-xs font-semibold m-0">Click or Drag & Drop banner image</p>
                        <p class="text-[11px] m-0 text-subtle mt-0.5">Recommended: 1600 × 700 px</p>
                    </div>
                </div>
                <input type="hidden" id="b_image"/>
                <input type="file" id="bannerFileInput" accept="image/*" class="hidden"/>
            </div>

        </form>
        <div class="dialog-footer">
            <button type="button" id="bannerDlgCancel" class="btn btn-outline btn-sm">Cancel</button>
            <button type="submit" form="bannerForm" id="bannerDlgSubmit" class="btn btn-primary btn-sm">Save Banner</button>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const dlg = document.getElementById('bannerDialog');
    const form = document.getElementById('bannerForm');
    const submitBtn = document.getElementById('bannerDlgSubmit');
    const previewBox = document.getElementById('bannerPreviewBox');
    const fileInput = document.getElementById('bannerFileInput');

    function closeDlg() { dlg.classList.add('hidden'); }
    document.getElementById('bannerDlgClose').onclick = closeDlg;
    document.getElementById('bannerDlgCancel').onclick = closeDlg;

    function resetBannerForm() {
        form.reset();
        document.getElementById('b_id').value = '';
        document.getElementById('b_image').value = '';
        document.getElementById('bannerDlgTitle').textContent = 'Add New Banner';
        previewBox.innerHTML = `
            <div class="text-center text-muted-foreground" id="bannerPlaceholder">
                <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="mx-auto mb-1"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                <p class="text-xs font-semibold m-0">Click or Drag & Drop banner image</p>
                <p class="text-[11px] m-0 text-subtle mt-0.5">Recommended: 1600 × 700 px</p>
            </div>`;
    }

    document.getElementById('addBannerBtn').onclick = () => {
        resetBannerForm();
        dlg.classList.remove('hidden');
    };

    // Replace Banner Trigger
    document.querySelectorAll('.editBannerBtn').forEach(b => {
        b.onclick = () => {
            resetBannerForm();
            document.getElementById('bannerDlgTitle').textContent = 'Replace Banner Image';
            document.getElementById('b_id').value = b.dataset.id;
            if (b.dataset.image) {
                document.getElementById('b_image').value = b.dataset.image;
                previewBox.innerHTML = `<img src="${productImageUrl(b.dataset.image)}" class="w-full h-full object-cover"/>`;
            }
            dlg.classList.remove('hidden');
        };
    });

    // Image Upload Handling (Works with BASE_PATH dynamically)
    previewBox.onclick = () => fileInput.click();
    fileInput.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const fd = new FormData();
        fd.append('image', file);

        previewBox.innerHTML = `<span class="adm-spinner" style="border-color:#4f46e5;border-top-color:transparent;width:28px;height:28px;"></span>`;

        try {
            const uploadUrl = (window.APP_BASE || '') + '/api/admin/features/upload';
            const res = await fetch(uploadUrl, { method: 'POST', body: fd, credentials: 'include' });
            const data = await res.json();
            if (data.success && data.data && data.data.url) {
                document.getElementById('b_image').value = data.data.url;
                previewBox.innerHTML = `<img src="${productImageUrl(data.data.url)}" class="w-full h-full object-cover"/>`;
                toast('Uploaded', 'Banner media uploaded successfully', 'success');
            } else {
                toast('Upload Failed', data.message || 'Error uploading file', 'error');
                previewBox.innerHTML = `<p class="text-xs text-red-500 m-0">Upload failed. Click to retry.</p>`;
            }
        } catch(err) {
            toast('Upload Error', 'Failed to connect to server', 'error');
            previewBox.innerHTML = `<p class="text-xs text-red-500 m-0">Upload failed. Click to retry.</p>`;
        }
    };

    // Form Submission
    form.onsubmit = async (e) => {
        e.preventDefault();
        const id = document.getElementById('b_id').value;
        const image = document.getElementById('b_image').value;
        if (!image) {
            toast('Validation', 'Please upload an image for the banner', 'error');
            return;
        }

        setButtonLoading(submitBtn, true, 'Saving...');
        try {
            if (id) {
                await api(`/admin/features/${id}`, { method: 'PUT', body: { image } });
                toast('Updated', 'Banner replaced successfully', 'success');
            } else {
                await api('/admin/features', { method: 'POST', body: { image } });
                toast('Saved', 'New banner slide created', 'success');
            }
            closeDlg();
            setTimeout(() => location.reload(), 450);
        } catch(err) {
            setButtonLoading(submitBtn, false);
        }
    };

    // Delete Banner Trigger
    document.querySelectorAll('.deleteBannerBtn').forEach(b => {
        b.onclick = () => {
            showConfirmModal({
                title: 'Delete Banner Slide',
                message: 'Are you sure you want to remove this banner from the homepage carousel?',
                confirmText: 'Delete Banner',
                isDanger: true,
                onConfirm: async () => {
                    try {
                        await api(`/admin/features/${b.dataset.id}`, { method: 'DELETE' });
                        toast('Deleted', 'Banner removed from carousel', 'success');
                        setTimeout(() => location.reload(), 400);
                    } catch(e) {}
                }
            });
        };
    });
});
</script>

<?php
/**
 * Unauthorised Access Page
 * Luxury access denied screen with clearance level warning.
 */
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/functions.php';
http_response_code(403);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>403 — Restricted Atelier Clearance | <?= e(APP_NAME) ?></title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;0,700;1,400;1,600&family=Inter:wght@300;400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Syne:wght@600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?= base_url('/css/style.css') ?>"/>
    <link rel="stylesheet" href="<?= base_url('/css/shop.css') ?>"/>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🛡️</text></svg>">
</head>
<body class="auth-wrapper-lux">
    <div class="auth-card-lux p-8 sm:p-12 text-center space-y-5 animate-fade-in-scale">
        <div class="brand-logo-emblem mx-auto mb-2 bg-rose-900" style="width:48px;height:48px;">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
        </div>

        <span class="inline-block text-[10px] uppercase font-extrabold tracking-widest px-3 py-1 rounded-full bg-rose-100 text-rose-800">
            Error Code 403 • Restricted Area
        </span>

        <h1 class="font-display text-4xl sm:text-5xl font-black text-foreground m-0 tracking-tight">
            Restricted Clearance
        </h1>

        <div class="space-y-1">
            <h2 class="font-display text-base font-bold text-foreground m-0">Administrator Access Required</h2>
            <p class="text-xs text-muted-foreground max-w-xs mx-auto leading-relaxed m-0">
                You do not possess the necessary clearance credentials to inspect this administrative console.
            </p>
        </div>

        <div class="pt-3 flex flex-wrap justify-center gap-3">
            <?php if (isLoggedIn()): ?>
                <a href="<?= base_url('/shop/home') ?>" class="btn-lux btn-lux-primary btn-lux-sm">Return to Store &rarr;</a>
                <button onclick="handleLogout()" class="btn-lux btn-lux-outline btn-lux-sm">Sign Out</button>
            <?php else: ?>
                <a href="<?= base_url('/auth/login') ?>" class="btn-lux btn-lux-primary btn-lux-sm">Sign In with Admin &rarr;</a>
                <a href="<?= base_url('/shop/home') ?>" class="btn-lux btn-lux-outline btn-lux-sm">Back to Store</a>
            <?php endif ?>
        </div>
    </div>

    <script>window.APP_BASE = '<?= BASE_PATH ?>';</script>
    <script src="<?= asset_url('/js/app.js') ?>"></script>
    <script>
    async function handleLogout(){
        try{ await Auth.logout(); }catch(e){}
        location.href='<?= base_url('/auth/login') ?>';
    }
    </script>
</body>
</html>

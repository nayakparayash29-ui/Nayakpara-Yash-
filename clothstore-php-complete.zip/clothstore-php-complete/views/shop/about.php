<?php
/**
 * About The Atelier Page
 * Editorial luxury brand story, philosophy, ethical craftsmanship, and bespoke ateliers.
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'about';
$pageTitle = 'The Atelier Story & Craftsmanship';
?>
<div class="space-y-16 pb-12">
    <!-- Hero Story Banner -->
    <section class="container pt-4">
        <div class="story-hero-lux relative overflow-hidden shadow-2xl">
            <div class="relative z-10 max-w-2xl space-y-4">
                <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs uppercase font-extrabold tracking-widest text-amber-300">
                    Est. 2020 • Haute Prêt-à-Porter
                </span>
                <h1 class="font-display text-3xl sm:text-5xl font-extrabold tracking-tight m-0 text-white leading-tight">
                    Where Architectural Form Meets <span class="font-serif italic font-normal text-amber-300">Timeless Tailoring</span>.
                </h1>
                <p class="text-sm sm:text-base text-slate-300 leading-relaxed m-0 max-w-xl">
                    <?= e(APP_NAME) ?> was conceived with a singular devotion: creating garments that balance quiet luxury, sculptural elegance, and unparalleled everyday ease.
                </p>
                <div class="pt-2 flex flex-wrap gap-3">
                    <a href="<?= base_url('/shop/listing') ?>" class="btn-lux btn-lux-white btn-lux-sm">
                        Explore The Collections &rarr;
                    </a>
                    <a href="<?= base_url('/shop/contact') ?>" class="btn-lux btn-lux-outline btn-lux-sm text-white border-white/30 hover:bg-white/10">
                        Visit Concierge
                    </a>
                </div>
            </div>
            <!-- Background Image with Scrim -->
            <div class="absolute inset-0 z-0">
                <img src="https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=1600&q=80"
                     alt="Atelier Workshop" class="w-full h-full object-cover opacity-35 scale-105"/>
                <div class="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/80 to-transparent"></div>
            </div>
        </div>
    </section>

    <!-- Atelier Philosophy & Principles -->
    <section class="container">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div class="space-y-5">
                <span class="text-xs uppercase tracking-widest font-extrabold text-amber-800 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
                    Our Design Philosophy
                </span>
                <h2 class="font-display text-2xl sm:text-4xl font-extrabold text-foreground tracking-tight m-0">
                    Crafting Wardrobes For Generations, Not Seasons.
                </h2>
                <p class="text-xs sm:text-sm text-muted-foreground leading-relaxed m-0">
                    In an era dominated by transient fast fashion, our atelier chooses deliberate permanence. We collaborate exclusively with master tailors and historic weaving mills across Gujarat and international heritage hubs to develop garments that endure.
                </p>
                <p class="text-xs sm:text-sm text-muted-foreground leading-relaxed m-0">
                    Every stitch is calibrated to compliment the natural movement of the body. From French-seamed silk blouses to structural virgin wool coats and hand-spun Supima cotton staples, our wardrobe adapts seamlessly from private boardrooms to evening galas.
                </p>

                <div class="pt-2 grid grid-cols-2 gap-4">
                    <div class="p-4 rounded-2xl bg-white border border-border space-y-1">
                        <strong class="text-foreground text-sm font-bold block">100% Traceable</strong>
                        <span class="text-xs text-muted-foreground">Certified organic yarns and cruelty-free silks</span>
                    </div>
                    <div class="p-4 rounded-2xl bg-white border border-border space-y-1">
                        <strong class="text-foreground text-sm font-bold block">Zero Compromise</strong>
                        <span class="text-xs text-muted-foreground">Precision tailored patterns with double reinforcement</span>
                    </div>
                </div>
            </div>

            <!-- Visual Feature Mosaic -->
            <div class="grid grid-cols-2 gap-4 relative">
                <div class="aspect-[3/4] rounded-3xl overflow-hidden bg-slate-200 shadow-md">
                    <img src="https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=800&q=80"
                         alt="Tailoring Fabric Precision" class="w-full h-full object-cover hover:scale-105 transition duration-500"/>
                </div>
                <div class="aspect-[3/4] rounded-3xl overflow-hidden bg-slate-200 shadow-md mt-8">
                    <img src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800&q=80"
                         alt="Haute Silhouette" class="w-full h-full object-cover hover:scale-105 transition duration-500"/>
                </div>
            </div>
        </div>
    </section>

    <!-- Key Atelier Metrics -->
    <section class="container">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div class="stat-box-lux">
                <div class="stat-number-lux">50K+</div>
                <h4 class="font-bold text-xs uppercase tracking-wider text-muted-foreground mt-2 m-0">Discerning Patrons</h4>
                <p class="text-[11px] text-muted-foreground mt-1 m-0">Across 28 Indian states and global destinations</p>
            </div>
            <div class="stat-box-lux">
                <div class="stat-number-lux">100%</div>
                <h4 class="font-bold text-xs uppercase tracking-wider text-muted-foreground mt-2 m-0">Certified Mills</h4>
                <p class="text-[11px] text-muted-foreground mt-1 m-0">OEKO-TEX & GOTS certified sustainable fabrics</p>
            </div>
            <div class="stat-box-lux">
                <div class="stat-number-lux">7-Day</div>
                <h4 class="font-bold text-xs uppercase tracking-wider text-muted-foreground mt-2 m-0">Concierge Exchange</h4>
                <p class="text-[11px] text-muted-foreground mt-1 m-0">Doorstep pickups with zero hassle</p>
            </div>
            <div class="stat-box-lux">
                <div class="stat-number-lux">4.9★</div>
                <h4 class="font-bold text-xs uppercase tracking-wider text-muted-foreground mt-2 m-0">Client Acclaim</h4>
                <p class="text-[11px] text-muted-foreground mt-1 m-0">Validated over 10,000+ verified customer reviews</p>
            </div>
        </div>
    </section>

    <!-- Sustainable Materials & Craftsmanship -->
    <section class="container">
        <div class="p-8 sm:p-12 rounded-3xl bg-slate-900 text-white shadow-xl space-y-8">
            <div class="max-w-xl space-y-2">
                <span class="text-xs uppercase font-extrabold tracking-widest text-amber-400">Archival Materials</span>
                <h3 class="font-display text-2xl sm:text-3xl font-extrabold m-0 tracking-tight text-white">
                    Uncompromising Standards in Raw Fabric
                </h3>
                <p class="text-xs sm:text-sm text-slate-300 leading-relaxed m-0">
                    A garment is only as sublime as the fibers woven into its foundation. We curate only exceptional textiles:
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                    <span class="text-2xl">🌱</span>
                    <h4 class="text-sm font-bold text-white m-0">Organic Supima Cotton</h4>
                    <p class="text-xs text-slate-400 leading-relaxed m-0">
                        Extra-long staple fibers yielding extraordinary silkiness, vibrant color retention, and breathability that softens with every wash.
                    </p>
                </div>
                <div class="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                    <span class="text-2xl">🧵</span>
                    <h4 class="text-sm font-bold text-white m-0">Italian Virgin Merino</h4>
                    <p class="text-xs text-slate-400 leading-relaxed m-0">
                        Spun in Northern Italian biella mills, our wool balances thermal responsiveness, featherlight drape, and natural crease resistance.
                    </p>
                </div>
                <div class="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
                    <span class="text-2xl">✨</span>
                    <h4 class="text-sm font-bold text-white m-0">Mulberry Silk & Linen</h4>
                    <p class="text-xs text-slate-400 leading-relaxed m-0">
                        Fluid luxury silk charmeuse and raw textured Belgian linen woven to provide effortless poise in warm Mediterranean and tropical climates.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Visit Atelier CTA -->
    <section class="container text-center space-y-4 max-w-2xl mx-auto">
        <h3 class="font-display text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight m-0">
            Experience Haute Couture In Person
        </h3>
        <p class="text-xs sm:text-sm text-muted-foreground leading-relaxed m-0">
            Book a private styling consultation or visit our flagship atelier showroom in Ahmedabad to explore made-to-measure tailoring and archival collections.
        </p>
        <div class="pt-2 flex justify-center gap-3">
            <a href="<?= base_url('/shop/contact') ?>" class="btn-lux btn-lux-primary btn-lux-sm">
                Connect With Concierge &rarr;
            </a>
            <a href="<?= base_url('/shop/listing') ?>" class="btn-lux btn-lux-outline btn-lux-sm">
                Browse Online Catalog
            </a>
        </div>
    </section>
</div>

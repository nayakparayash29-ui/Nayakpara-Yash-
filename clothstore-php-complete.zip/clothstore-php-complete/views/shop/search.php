<?php
/**
 * Search Results Page
 * Displays matching atelier products for customer search queries
 * with live counters, luxury product cards, and instant actions.
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'listing';
$q = trim($_GET['q'] ?? '');
$pageTitle = 'Search: ' . ($q ? $q : 'All Products');
?>
<div class="container py-8 space-y-8">
    <!-- Header & Search Refinement -->
    <div class="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-border">
        <div>
            <nav class="flex items-center gap-1.5 text-xs text-muted-foreground mb-2">
                <a href="<?= base_url('/shop/home') ?>" class="hover:text-foreground transition">Home</a>
                <span>/</span>
                <a href="<?= base_url('/shop/listing') ?>" class="hover:text-foreground transition">Catalog</a>
                <span>/</span>
                <span class="text-foreground font-bold">Search</span>
            </nav>
            <h1 class="font-display text-3xl sm:text-4xl font-extrabold text-foreground m-0 tracking-tight">
                Search Results for &ldquo;<?= e($q) ?>&rdquo;
            </h1>
            <p class="text-xs text-muted-foreground m-0 mt-1" id="searchCountText">
                Searching atelier inventory...
            </p>
        </div>

        <form data-search-form class="search-capsule w-full md:w-80">
            <input type="search" name="q" value="<?= e($q) ?>" placeholder="Search garments, fabrics, styles..."
                   class="search-capsule-input" autocomplete="off"/>
            <button type="submit" class="search-capsule-btn" aria-label="Search">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            </button>
        </form>
    </div>

    <!-- Results Stage -->
    <div id="searchResults">
        <!-- Skeleton placeholders -->
        <div class="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            <?php for ($i = 0; $i < 4; $i++): ?>
                <div class="card-product-lux p-4 space-y-3">
                    <div class="aspect-[3/4] bg-slate-200/60 animate-pulse rounded-xl"></div>
                    <div class="h-4 bg-slate-200/60 animate-pulse rounded w-3/4"></div>
                    <div class="h-4 bg-slate-200/60 animate-pulse rounded w-1/2"></div>
                </div>
            <?php endfor ?>
        </div>
    </div>
</div>

<script>
window.__onAppReady = async () => {
    const q = '<?= addslashes($q) ?>';
    const container = document.getElementById('searchResults');
    const countText = document.getElementById('searchCountText');

    try {
        const res = await ProductApi.search(q);
        const items = res.data.items || [];

        if (!items.length) {
            countText.textContent = '0 matching items found';
            container.innerHTML = `
                <div class="card p-16 text-center rounded-3xl max-w-lg mx-auto border border-dashed border-border bg-white shadow-sm space-y-3">
                    <div class="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-2xl">
                        🔍
                    </div>
                    <h3 class="font-display text-xl font-bold text-foreground m-0">No Pieces Found</h3>
                    <p class="text-xs text-muted-foreground max-w-xs mx-auto leading-relaxed">
                        We couldn't find matches for "${_esc(q)}". Try searching by department (Men, Women, Kids, Footwear) or fabric.
                    </p>
                    <div class="pt-2">
                        <a href="${(window.APP_BASE || '') + '/shop/listing'}" class="btn-lux btn-lux-primary btn-lux-sm">
                            Browse Entire Catalog &rarr;
                        </a>
                    </div>
                </div>
            `;
            return;
        }

        countText.innerHTML = `Displaying <strong>${items.length}</strong> matching handcrafted garments`;
        const _base = window.APP_BASE || '';

        container.innerHTML = `
            <div class="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
                ${items.map(p => {
                    const price = Number(p.salePrice || 0) > 0 ? Number(p.salePrice) : Number(p.price || 0);
                    const origPrice = Number(p.price || 0);
                    const discount = origPrice > price ? Math.round((1 - price / origPrice) * 100) : 0;
                    return `
                        <div class="card-product-lux group">
                            <div class="product-media-wrap" onclick="location.href='${_base}/shop/product/${p.id}'">
                                <img src="${formatImageUrl(p.image)}" alt="${_esc(p.title)}"
                                     onerror="this.onerror=null;this.src=formatImageUrl('');"
                                     class="product-media-img" loading="lazy"/>

                                <div class="badge-floating-corner">
                                    ${discount > 0 ? `<span class="badge-lux-sale">-${discount}%</span>` : ''}
                                    ${p.brand ? `<span class="badge-lux-new">${_esc(p.brand)}</span>` : ''}
                                </div>

                                <button type="button" class="btn-wishlist-float"
                                        data-wishlist-toggle="${p.id}" title="Save" aria-label="Wishlist"
                                        onclick="event.stopPropagation()">
                                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                                    </svg>
                                </button>
                            </div>

                            <div class="product-info-wrap">
                                <div>
                                    <p class="product-brand-tag">${_esc(p.category || 'Atelier')}</p>
                                    <h4 class="product-title-lux">
                                        <a href="${_base}/shop/product/${p.id}">${_esc(p.title)}</a>
                                    </h4>
                                    <div class="product-meta-row">
                                        ${renderStars(p.averageReview, 12)}
                                        <span class="product-reviews-count">(${Number(p.averageReview || 0).toFixed(1)})</span>
                                    </div>
                                </div>

                                <div class="product-price-row">
                                    <div>
                                        <span class="price-current-lux">${formatCurrency(price)}</span>
                                        ${origPrice > price ? `<span class="price-original-lux">${formatCurrency(origPrice)}</span>` : ''}
                                    </div>
                                    <span class="text-[11px] font-bold text-emerald-700">In Stock</span>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        `;
    } catch(e) {
        countText.textContent = 'Error loading search results';
    }
};
if (window.api) window.__onAppReady();
</script>

<?php
/**
 * Checkout Page
 * Multi-step visual checkout with saved addresses, modal address creation,
 * promo code deduction, order summary, and real payment capture.
 */
if (!isset($viewContent)) $viewContent = __FILE__;
requireLogin();
$active = 'checkout';
$pageTitle = 'Secure Checkout';

$user = currentUser();
require_once __DIR__ . '/../../models/Cart.php';
require_once __DIR__ . '/../../models/Address.php';
require_once __DIR__ . '/../../models/Setting.php';
$cm = new CartModel();
$am = new AddressModel();
$storeSettings = (new SettingModel())->getAll();
$stripeEnabled = ($storeSettings['stripe_enabled'] ?? '1') === '1';

$cart = $cm->getPopulatedCart($user['id']);
$items = $cart['items'] ?? [];
$addresses = $am->findByUserId($user['id']);

if (empty($items)) {
    setFlash('info', 'Your cart is empty. Add items before checkout.');
    redirect('/shop/listing');
    exit;
}

$subtotal = 0;
foreach ($items as $it) {
    $p = (float)($it['salePrice'] ?: $it['price']);
    $subtotal += $p * (int)$it['quantity'];
}
$shipping = $subtotal >= 1000 ? 0 : 99;
$tax = round($subtotal * 0.05, 2);
$total = $subtotal + $shipping + $tax;
?>
<div class="container py-8 space-y-8">
    <div class="flex items-center justify-between pb-4 border-b border-border">
        <a href="<?= base_url('/shop/cart') ?>" class="text-xs font-bold text-foreground hover:underline inline-flex items-center gap-1.5">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
            <span>Return to Shopping Bag</span>
        </a>
        <div class="flex items-center gap-2 text-xs font-semibold text-muted-foreground">
            <span>🔒 Bank-Grade 256-Bit SSL Encrypted</span>
        </div>
    </div>

    <!-- Architectural Step Tracker -->
    <div class="flex items-center justify-between max-w-xl mx-auto py-2">
        <div class="checkout-step-pill active">
            <span class="checkout-step-num">1</span>
            <span>Delivery Destination</span>
        </div>
        <div class="flex-1 h-[2px] bg-slate-900 mx-3"></div>
        <div class="checkout-step-pill active">
            <span class="checkout-step-num">2</span>
            <span>Review Items</span>
        </div>
        <div class="flex-1 h-[2px] bg-slate-900 mx-3"></div>
        <div class="checkout-step-pill active">
            <span class="checkout-step-num">3</span>
            <span>Payment Method</span>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        <!-- Left: Delivery Address & Payment Method -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Delivery Address Card -->
            <div class="card-lux overflow-hidden">
                <div class="p-5 sm:p-6 border-b border-border flex items-center justify-between bg-slate-50/50">
                    <div>
                        <h3 class="font-display text-base font-extrabold text-foreground m-0">1. Destination Delivery Address</h3>
                        <p class="text-xs text-muted-foreground m-0 mt-0.5">Select a destination or register a new doorstep location</p>
                    </div>
                    <button type="button" id="addAddrBtn" class="btn-lux btn-lux-primary btn-lux-sm">
                        + Add New Address
                    </button>
                </div>
                <div class="p-5 sm:p-6">
                    <?php if (empty($addresses)): ?>
                        <div class="p-8 text-center border border-dashed border-border rounded-2xl space-y-3">
                            <span class="text-2xl">📍</span>
                            <p class="text-xs text-muted-foreground m-0">No saved delivery addresses found for your account.</p>
                            <button type="button" onclick="document.getElementById('addAddrBtn').click()" class="btn-lux btn-lux-primary btn-lux-sm">
                                Register Delivery Address
                            </button>
                        </div>
                    <?php else: ?>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5" id="addrList">
                            <?php foreach ($addresses as $idx => $a): ?>
                                <label class="address-card-lux <?= $idx === 0 ? 'selected' : '' ?>">
                                    <div class="flex items-start justify-between">
                                        <div class="flex items-center gap-2">
                                            <input type="radio" name="addrSel" value="<?= (int)$a['id'] ?>" class="w-4 h-4 text-slate-900" <?= $idx === 0 ? 'checked' : '' ?>/>
                                            <span class="font-bold text-xs text-foreground"><?= e($user['userName']) ?></span>
                                        </div>
                                        <span class="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">Doorstep</span>
                                    </div>
                                    <div class="mt-2 text-xs text-slate-600 space-y-0.5 pl-6">
                                        <p class="m-0 font-medium text-foreground"><?= e($a['address']) ?></p>
                                        <p class="m-0"><?= e($a['city']) ?>, PIN: <?= e($a['pincode']) ?></p>
                                        <p class="m-0 pt-1 font-semibold">📞 <?= e($a['phone']) ?></p>
                                        <?php if (!empty($a['notes'])): ?>
                                            <p class="m-0 italic text-slate-400 text-[11px]">Note: <?= e($a['notes']) ?></p>
                                        <?php endif ?>
                                    </div>
                                </label>
                            <?php endforeach ?>
                        </div>
                    <?php endif ?>
                </div>
            </div>

            <!-- Payment Method Card -->
            <div class="card-lux overflow-hidden">
                <div class="p-5 sm:p-6 border-b border-border bg-slate-50/50">
                    <h3 class="font-display text-base font-extrabold text-foreground m-0">2. Select Payment Method</h3>
                    <p class="text-xs text-muted-foreground m-0 mt-0.5">Encrypted transaction verified via bank gateway</p>
                </div>
                <div class="p-5 sm:p-6 space-y-3">
                    <?php if ($stripeEnabled): ?>
                    <label class="flex items-center gap-4 p-4 border rounded-2xl cursor-pointer transition border-slate-900 bg-slate-50 payment-option">
                        <input type="radio" name="pay" value="stripe" class="w-4 h-4 text-slate-900" checked/>
                        <div class="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-bold text-sm shadow-sm">
                            💳
                        </div>
                        <div class="flex-1">
                            <p class="font-bold text-xs sm:text-sm text-foreground m-0">Credit / Debit Card (Stripe)</p>
                            <p class="text-[11px] text-muted-foreground m-0">Visa, Mastercard, RuPay, and American Express</p>
                        </div>
                        <span class="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">Card</span>
                    </label>
                    <?php endif ?>

                    <label class="flex items-center gap-4 p-4 border <?= $stripeEnabled ? 'border-border bg-white' : 'border-slate-900 bg-slate-50' ?> rounded-2xl cursor-pointer transition hover:border-slate-400 payment-option">
                        <input type="radio" name="pay" value="cod" class="w-4 h-4 text-slate-900" <?= $stripeEnabled ? '' : 'checked' ?>/>
                        <div class="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-bold text-sm shadow-sm">
                            💵
                        </div>
                        <div class="flex-1">
                            <p class="font-bold text-xs sm:text-sm text-foreground m-0">Cash on Delivery (Doorstep Cash/UPI)</p>
                            <p class="text-[11px] text-muted-foreground m-0">Pay upon physical inspection at your address</p>
                        </div>
                    </label>

                    <label class="flex items-center gap-4 p-4 border border-border rounded-2xl cursor-pointer transition hover:border-slate-400 bg-white payment-option">
                        <input type="radio" name="pay" value="upi" class="w-4 h-4 text-slate-900"/>
                        <div class="w-10 h-10 rounded-xl bg-sky-700 text-white flex items-center justify-center font-bold text-sm shadow-sm">
                            📱
                        </div>
                        <div class="flex-1">
                            <p class="font-bold text-xs sm:text-sm text-foreground m-0">Instant UPI / QR Code</p>
                            <p class="text-[11px] text-muted-foreground m-0">Google Pay, PhonePe, Paytm & BHIM UPI</p>
                        </div>
                    </label>
                </div>
            </div>
        </div>

        <!-- Right: Order Summary Sidebar -->
        <div class="lg:col-span-1 space-y-4 sticky top-28">
            <div class="card-lux p-6 space-y-4">
                <div class="flex items-center justify-between pb-3 border-b border-border">
                    <h3 class="font-display text-base font-extrabold text-foreground m-0">Review Shipment</h3>
                    <span class="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700"><?= count($items) ?> items</span>
                </div>

                <!-- Mini Items List -->
                <div class="max-h-56 overflow-y-auto divide-y divide-border/60 pr-1 space-y-2">
                    <?php foreach ($items as $it):
                        $p = (float)($it['salePrice'] ?: $it['price']);
                    ?>
                        <div class="flex gap-3 pt-2 first:pt-0 items-center">
                            <div class="w-12 h-14 rounded-lg bg-slate-100 flex-shrink-0 overflow-hidden border border-border/80">
                                <img src="<?= e(product_image_url($it['image'] ?? '')) ?>" alt=""
                                     onerror="this.onerror=null;this.src='<?= e(product_image_url('')) ?>';"
                                     class="w-full h-full object-cover"/>
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="text-xs font-semibold text-foreground line-clamp-1 m-0"><?= e($it['title']) ?></p>
                                <p class="text-[11px] text-muted-foreground m-0 mt-0.5">Qty: <?= (int)$it['quantity'] ?> × <?= formatCurrency($p) ?></p>
                            </div>
                            <span class="text-xs font-bold text-foreground"><?= formatCurrency($p * (int)$it['quantity']) ?></span>
                        </div>
                    <?php endforeach ?>
                </div>

                <!-- Promo Coupon -->
                <div class="pt-3 border-t border-border">
                    <div class="flex gap-2">
                        <input type="text" id="checkoutCouponInput" placeholder="Privilege code"
                               class="form-input-lux text-xs uppercase font-bold flex-1" style="height:2.4rem;"/>
                        <button type="button" onclick="applyCheckoutCoupon()" class="btn-lux btn-lux-outline btn-lux-sm px-3">
                            Apply
                        </button>
                    </div>
                    <div id="checkoutCouponResult" class="text-xs font-semibold hidden mt-1"></div>
                </div>

                <!-- Pricing Rows -->
                <div class="space-y-2 text-xs text-muted-foreground pt-3 border-t border-border">
                    <div class="flex justify-between">
                        <span>Items Subtotal</span>
                        <span class="font-bold text-foreground"><?= formatCurrency($subtotal) ?></span>
                    </div>
                    <div id="checkoutDiscountRow" class="flex justify-between text-emerald-700 font-bold" style="display:none;">
                        <span>Coupon Savings</span>
                        <span id="checkoutDiscountVal">-₹0.00</span>
                    </div>
                    <div class="flex justify-between">
                        <span>Delivery Fee</span>
                        <span class="font-bold">
                            <?= $shipping === 0 ? '<span class="text-emerald-700 font-bold">FREE</span>' : formatCurrency($shipping) ?>
                        </span>
                    </div>
                    <div class="flex justify-between">
                        <span>Applicable GST (5%)</span>
                        <span class="font-bold text-foreground"><?= formatCurrency($tax) ?></span>
                    </div>
                </div>

                <!-- Grand Total -->
                <div class="pt-3 border-t border-border flex justify-between items-baseline">
                    <strong class="font-display text-sm font-extrabold text-foreground">Grand Total</strong>
                    <span class="font-display text-2xl font-black text-foreground" id="checkoutGrandTotal"><?= formatCurrency($total) ?></span>
                </div>

                <!-- Place Order Button -->
                <button type="button" id="placeOrderBtn" class="btn-lux btn-lux-primary w-full text-center text-sm py-3 mt-2 shadow-lg">
                    Confirm & Place Order &rarr;
                </button>

                <p class="text-[11px] text-center text-muted-foreground leading-normal m-0 pt-1">
                    By confirming, you agree to our <a href="<?= base_url('/shop/policies/terms') ?>" class="text-foreground font-bold hover:underline">Terms of Service</a> & <a href="<?= base_url('/shop/policies/privacy') ?>" class="text-foreground font-bold hover:underline">Privacy Policy</a>.
                </p>
            </div>
        </div>
    </div>
</div>

<!-- Add Address Dialog Modal -->
<div id="addrDialog" class="dialog-overlay hidden">
    <div class="dialog max-w-md w-full rounded-3xl bg-white border border-border shadow-2xl overflow-hidden animate-fade-in-scale">
        <div class="p-5 border-b border-border flex items-center justify-between bg-slate-50/50">
            <h3 class="font-display text-base font-extrabold text-foreground m-0">Add Delivery Destination</h3>
            <button type="button" id="addrClose" class="btn btn-ghost btn-icon rounded-full" aria-label="Close dialog">&times;</button>
        </div>
        <form id="addrForm" class="addr-form">
            <div class="addr-field">
                <label for="addr_field">Full street address <span>*</span></label>
                <textarea id="addr_field" required rows="2" placeholder="Flat, building, street, locality" class="form-textarea-lux"></textarea>
            </div>
            <div class="addr-row">
                <div class="addr-field">
                    <label for="city_field">City <span>*</span></label>
                    <input id="city_field" required placeholder="Ahmedabad" class="form-input-lux"/>
                </div>
                <div class="addr-field">
                    <label for="pin_field">Pincode <span>*</span></label>
                    <input id="pin_field" required pattern="[0-9]{4,10}" placeholder="380001" class="form-input-lux"/>
                </div>
            </div>
            <div class="addr-field">
                <label for="phone_field">Contact phone <span>*</span></label>
                <input id="phone_field" required pattern="[0-9 +-]{7,15}" placeholder="+91 98765 43210" class="form-input-lux"/>
            </div>
            <div class="addr-field">
                <label for="notes_field">Landmark or notes <em>Optional</em></label>
                <input id="notes_field" placeholder="Near Apollo Hospital, Ring Road" class="form-input-lux"/>
            </div>
            <div class="addr-actions">
                <button type="button" id="addrCancel" class="btn-lux btn-lux-outline btn-lux-sm">Cancel</button>
                <button type="submit" class="btn-lux btn-lux-primary btn-lux-sm">Save address</button>
            </div>
        </form>
    </div>
</div>

<script>
const UID = <?= (int)$user['id'] ?>;
const CART_ITEMS = <?= json_encode($items, JSON_UNESCAPED_SLASHES) ?>;
const CART_ID = '<?= $cart['id'] ?? '' ?>';
let CURRENT_TOTAL = <?= $total ?>;
const BASE_SUBTOTAL = <?= $subtotal ?>;
let CURRENT_DISCOUNT = 0;

// Address Selection Radio styling
document.querySelectorAll('input[name="addrSel"]').forEach(rad => {
    rad.addEventListener('change', () => {
        document.querySelectorAll('.address-card-lux').forEach(c => c.classList.remove('selected'));
        const card = rad.closest('.address-card-lux');
        if (card) card.classList.add('selected');
    });
});

// Payment method selection styling
document.querySelectorAll('input[name="pay"]').forEach(rad => {
    rad.addEventListener('change', () => {
        document.querySelectorAll('.payment-option').forEach(c => {
            c.classList.remove('border-slate-900', 'bg-slate-50');
            c.classList.add('border-border', 'bg-white');
        });
        const card = rad.closest('.payment-option');
        if (card) {
            card.classList.add('border-slate-900', 'bg-slate-50');
            card.classList.remove('border-border', 'bg-white');
        }
    });
});

// Address Modal controls
document.getElementById('addAddrBtn')?.addEventListener('click', () => {
    document.getElementById('addrDialog')?.classList.remove('hidden');
});
document.getElementById('addrClose')?.addEventListener('click', () => {
    document.getElementById('addrDialog')?.classList.add('hidden');
});
document.getElementById('addrCancel')?.addEventListener('click', () => {
    document.getElementById('addrDialog')?.classList.add('hidden');
});

// Save Address form submit
document.getElementById('addrForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
        await AddressApi.add({
            address: document.getElementById('addr_field').value.trim(),
            city:    document.getElementById('city_field').value.trim(),
            pincode: document.getElementById('pin_field').value.trim(),
            phone:   document.getElementById('phone_field').value.trim(),
            notes:   document.getElementById('notes_field').value.trim(),
        });
        toast('Success', 'Address saved successfully!', 'success');
        setTimeout(() => location.reload(), 400);
    } catch(e) {}
});

// Check if coupon saved in sessionStorage
try {
    const saved = JSON.parse(sessionStorage.getItem('applied_coupon') || 'null');
    if (saved && saved.discountAmount) {
        CURRENT_DISCOUNT = saved.discountAmount;
        document.getElementById('checkoutDiscountRow').style.display = 'flex';
        document.getElementById('checkoutDiscountVal').textContent = `-₹${CURRENT_DISCOUNT.toFixed(2)}`;
        CURRENT_TOTAL = Math.max(0, CURRENT_TOTAL - CURRENT_DISCOUNT);
        document.getElementById('checkoutGrandTotal').textContent = formatCurrency(CURRENT_TOTAL);
        document.getElementById('checkoutCouponInput').value = saved.code || '';
    }
} catch(e) {}

// Apply Checkout Coupon
async function applyCheckoutCoupon() {
    const inp = document.getElementById('checkoutCouponInput');
    const resBox = document.getElementById('checkoutCouponResult');
    const code = inp ? inp.value.trim().toUpperCase() : '';
    if (!code) return;
    try {
        const res = await CouponApi.apply(code, BASE_SUBTOTAL);
        const disc = res.data.discountAmount || 0;
        CURRENT_DISCOUNT = disc;
        resBox.className = 'text-xs font-semibold text-emerald-700 block mt-1';
        resBox.textContent = `Applied! Saved ₹${disc.toFixed(2)}`;

        document.getElementById('checkoutDiscountRow').style.display = 'flex';
        document.getElementById('checkoutDiscountVal').textContent = `-₹${disc.toFixed(2)}`;

        const shipping = BASE_SUBTOTAL >= 1000 ? 0 : 99;
        const tax = Math.round(BASE_SUBTOTAL * 0.05 * 100) / 100;
        CURRENT_TOTAL = Math.max(0, BASE_SUBTOTAL + shipping + tax - disc);
        document.getElementById('checkoutGrandTotal').textContent = formatCurrency(CURRENT_TOTAL);

        sessionStorage.setItem('applied_coupon', JSON.stringify(res.data));
        toast('Privilege Code Applied', res.message, 'success');
    } catch(e) {
        resBox.className = 'text-xs font-semibold text-rose-600 block mt-1';
        resBox.textContent = e.message || 'Invalid code';
    }
}

// Place Order
document.getElementById('placeOrderBtn')?.addEventListener('click', async () => {
    const addrId = (document.querySelector('input[name="addrSel"]:checked') || {}).value;
    if (!addrId) {
        toast('Address Required', 'Please select or add a delivery address', 'error');
        return;
    }
    const pay = (document.querySelector('input[name="pay"]:checked') || {}).value || 'cod';

    const btn = document.getElementById('placeOrderBtn');
    btn.disabled = true;
    btn.innerHTML = `<span class="inline-block animate-spin mr-2">⏳</span> Processing Order...`;

    try {
        const addrList = await AddressApi.get(UID);
        const addrObj = addrList.data.find(a => a.id == addrId || a._id == addrId);
        if (!addrObj) {
            toast('Error', 'Selected address details could not be loaded', 'error');
            btn.disabled = false;
            btn.innerHTML = `Confirm & Place Order &rarr;`;
            return;
        }

        const payload = {
            userId: UID,
            cartId: CART_ID,
            cartItems: CART_ITEMS.map(i => ({
                productId: i.productId,
                title: i.title,
                image: i.image,
                price: Number(i.salePrice || i.price),
                quantity: Number(i.quantity)
            })),
            addressInfo: {
                addressId: addrObj.id || addrObj._id,
                address: addrObj.address,
                city: addrObj.city,
                pincode: addrObj.pincode,
                phone: addrObj.phone,
                notes: addrObj.notes || '',
            },
            orderStatus: (pay === 'cod' || pay === 'upi') ? 'confirmed' : 'pending',
            paymentMethod: pay,
            paymentStatus: (pay === 'cod' || pay === 'upi') ? 'paid' : 'pending',
            totalAmount: CURRENT_TOTAL,
            orderDate: new Date().toISOString(),
            orderUpdateDate: new Date().toISOString(),
        };

        const _base = window.APP_BASE || '';
        sessionStorage.removeItem('applied_coupon');

        if (pay === 'stripe') {
            const s = await OrderApi.stripeCheckout(payload);
            if (!s.data || !s.data.url) {
                throw new Error('Stripe did not return a payment link');
            }
            toast('Redirecting', 'Opening secure card payment...', 'info');
            window.location.href = s.data.url;
            return;
        }

        const res = await OrderApi.create(payload);
        await OrderApi.capture(res.data.orderId);
        toast('Order Confirmed', 'Your order has been placed successfully!', 'success');
        setTimeout(() => {
            window.location.href = _base + '/shop/payment-success?order_id=' + res.data.orderId;
        }, 600);
    } catch (e) {
        btn.disabled = false;
        btn.innerHTML = `Confirm & Place Order &rarr;`;
    }
});
</script>

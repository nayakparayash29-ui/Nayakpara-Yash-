<?php
/**
 * User Account Portal
 * Architectural luxury customer dashboard for Profile & Security, Order History,
 * and Saved Delivery Addresses.
 */
if (!isset($viewContent)) $viewContent = __FILE__;
requireLogin();
$active = 'account';
$user = currentUser();

$tab = $_GET['tab'] ?? 'profile';
$allowedTabs = ['profile', 'orders', 'addresses'];
if (!in_array($tab, $allowedTabs)) $tab = 'profile';

$pageTitle = 'My Account — ' . ucfirst($tab);

require_once __DIR__ . '/../../models/Order.php';
require_once __DIR__ . '/../../models/Address.php';
require_once __DIR__ . '/../../models/Wishlist.php';

$om = new OrderModel();
$am = new AddressModel();
$wm = new WishlistModel();

$orders = $om->findByUserId($user['id']);
$addresses = $am->findByUserId($user['id']);
$wishlistCount = $wm->countByUser($user['id']);
?>
<div class="container py-8 space-y-8">
    <!-- Header & Breadcrumbs -->
    <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-border">
        <div>
            <nav class="flex items-center gap-1.5 text-xs text-muted-foreground mb-2">
                <a href="<?= base_url('/shop/home') ?>" class="hover:text-foreground transition">Home</a>
                <span>/</span>
                <span class="text-foreground font-bold">Client Account</span>
            </nav>
            <h1 class="font-display text-3xl sm:text-4xl font-extrabold text-foreground m-0 tracking-tight">
                Patron Portal
            </h1>
            <p class="text-xs text-muted-foreground m-0 mt-1">
                Manage your personal profile, review order fulfillments, and edit delivery destinations
            </p>
        </div>
        <button type="button" class="btn-lux btn-lux-outline btn-lux-sm text-rose-700 hover:bg-rose-50 self-start sm:self-auto" onclick="handleLogout()">
            Sign Out
        </button>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-[16rem_1fr] lg:grid-cols-[18rem_1fr] gap-8 items-start">
        <!-- Sidebar Navigation -->
        <aside class="space-y-4 sticky top-28">
            <!-- User Monogram Summary -->
            <div class="card-lux p-5 bg-white space-y-3">
                <div class="flex items-center gap-3.5">
                    <div class="w-12 h-12 rounded-2xl bg-slate-950 text-white flex items-center justify-center font-display font-black text-lg shadow-md">
                        <?= strtoupper(substr($user['userName'], 0, 1)) ?>
                    </div>
                    <div class="min-w-0">
                        <p class="font-display font-bold text-sm text-foreground m-0 truncate"><?= e($user['userName']) ?></p>
                        <p class="text-[11px] text-muted-foreground m-0 truncate mt-0.5"><?= e($user['email']) ?></p>
                        <?php if ($user['role'] === 'admin'): ?>
                            <span class="text-[9px] uppercase font-bold px-2 py-0.5 rounded-full bg-slate-900 text-white inline-block mt-1">ADMINISTRATOR</span>
                        <?php endif ?>
                    </div>
                </div>
            </div>

            <!-- Tab Navigation Links -->
            <nav class="card-lux p-2 bg-white space-y-1">
                <a href="<?= base_url('/shop/account?tab=profile') ?>"
                   class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold transition <?= $tab === 'profile' ? 'bg-slate-900 text-white shadow-sm' : 'text-slate-600 hover:text-foreground hover:bg-slate-100' ?>">
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    <span>Profile & Security</span>
                </a>
                <a href="<?= base_url('/shop/account?tab=orders') ?>"
                   class="flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition <?= $tab === 'orders' ? 'bg-slate-900 text-white shadow-sm' : 'text-slate-600 hover:text-foreground hover:bg-slate-100' ?>">
                    <div class="flex items-center gap-3">
                        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/></svg>
                        <span>My Orders</span>
                    </div>
                    <span class="text-[10px] font-bold px-2 py-0.5 rounded-full <?= $tab === 'orders' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-700' ?>"><?= count($orders) ?></span>
                </a>
                <a href="<?= base_url('/shop/account?tab=addresses') ?>"
                   class="flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition <?= $tab === 'addresses' ? 'bg-slate-900 text-white shadow-sm' : 'text-slate-600 hover:text-foreground hover:bg-slate-100' ?>">
                    <div class="flex items-center gap-3">
                        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        <span>Saved Addresses</span>
                    </div>
                    <span class="text-[10px] font-bold px-2 py-0.5 rounded-full <?= $tab === 'addresses' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-700' ?>"><?= count($addresses) ?></span>
                </a>
                <a href="<?= base_url('/shop/wishlist') ?>"
                   class="flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:text-foreground hover:bg-slate-100 transition">
                    <div class="flex items-center gap-3">
                        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                        <span>Saved Wishlist</span>
                    </div>
                    <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-700"><?= $wishlistCount ?></span>
                </a>

                <?php if ($user['role'] === 'admin'): ?>
                    <div class="border-t border-border my-1.5 pt-1.5"></div>
                    <a href="<?= base_url('/admin/dashboard') ?>" class="flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-extrabold text-amber-800 hover:bg-amber-50 transition">
                        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                        <span>Switch to Admin Panel</span>
                    </a>
                <?php endif ?>
            </nav>
        </aside>

        <!-- Main Tab Content Area -->
        <section class="space-y-6">
            <?php if ($tab === 'profile'): ?>
                <!-- Profile Information Card -->
                <div class="card-lux p-6 sm:p-8 space-y-6">
                    <div>
                        <h3 class="font-display text-xl font-bold text-foreground m-0">Personal Profile</h3>
                        <p class="text-xs text-muted-foreground m-0 mt-0.5">Update your basic name and contact email credentials</p>
                    </div>

                    <form id="profileUpdateForm" class="space-y-4 max-w-lg" onsubmit="handleProfileUpdate(event)">
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label class="text-xs font-bold text-foreground block mb-1">Username <span class="text-rose-500">*</span></label>
                                <input type="text" id="profUserName" value="<?= e($user['userName']) ?>" required class="form-input-lux text-xs"/>
                            </div>
                            <div>
                                <label class="text-xs font-bold text-foreground block mb-1">Email Address <span class="text-rose-500">*</span></label>
                                <input type="email" id="profEmail" value="<?= e($user['email']) ?>" required class="form-input-lux text-xs"/>
                            </div>
                        </div>
                        <button type="submit" id="profSaveBtn" class="btn-lux btn-lux-primary btn-lux-sm">
                            Save Profile Changes
                        </button>
                    </form>

                    <div class="border-t border-border pt-6 space-y-4">
                        <div>
                            <h3 class="font-display text-xl font-bold text-foreground m-0">Security & Password</h3>
                            <p class="text-xs text-muted-foreground m-0 mt-0.5">Ensure your account is protected with a secure password</p>
                        </div>

                        <form id="passwordUpdateForm" class="space-y-4 max-w-lg" onsubmit="handlePasswordUpdate(event)">
                            <div>
                                <label class="text-xs font-bold text-foreground block mb-1">Current Password <span class="text-rose-500">*</span></label>
                                <div class="input-password-wrap">
                                    <input type="password" id="curPwd" required placeholder="••••••••" class="form-input-lux text-xs"/>
                                    <button type="button" class="input-password-toggle" data-toggle-password="curPwd" aria-label="Toggle password">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                                    </button>
                                </div>
                            </div>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="text-xs font-bold text-foreground block mb-1">New Password <span class="text-rose-500">*</span></label>
                                    <div class="input-password-wrap">
                                        <input type="password" id="newPwd" required minlength="4" placeholder="••••••••" class="form-input-lux text-xs"/>
                                        <button type="button" class="input-password-toggle" data-toggle-password="newPwd" aria-label="Toggle password">
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                                        </button>
                                    </div>
                                </div>
                                <div>
                                    <label class="text-xs font-bold text-foreground block mb-1">Confirm New Password <span class="text-rose-500">*</span></label>
                                    <div class="input-password-wrap">
                                        <input type="password" id="cnfPwd" required minlength="4" placeholder="••••••••" class="form-input-lux text-xs"/>
                                        <button type="button" class="input-password-toggle" data-toggle-password="cnfPwd" aria-label="Toggle password">
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" id="pwdSaveBtn" class="btn-lux btn-lux-primary btn-lux-sm">
                                Update Password
                            </button>
                        </form>
                    </div>
                </div>

            <?php elseif ($tab === 'orders'): ?>
                <!-- Orders Tab -->
                <div class="card-lux p-6 sm:p-8 space-y-6">
                    <div class="flex items-center justify-between pb-3 border-b border-border">
                        <div>
                            <h3 class="font-display text-xl font-bold text-foreground m-0">Order Fulfillments</h3>
                            <p class="text-xs text-muted-foreground m-0 mt-0.5">Track packages, view digital receipts, and inspect garments</p>
                        </div>
                        <a href="<?= base_url('/shop/listing') ?>" class="btn-lux btn-lux-outline btn-lux-sm">
                            Shop More
                        </a>
                    </div>

                    <?php if (empty($orders)): ?>
                        <div class="p-12 text-center rounded-3xl border border-dashed border-border bg-slate-50 space-y-3">
                            <span class="text-3xl">📦</span>
                            <h4 class="font-display font-bold text-base text-foreground m-0">No Orders Placed Yet</h4>
                            <p class="text-xs text-muted-foreground max-w-xs mx-auto">Your confirmed purchases will appear here for easy real-time fulfillment tracking.</p>
                            <div class="pt-2">
                                <a href="<?= base_url('/shop/listing') ?>" class="btn-lux btn-lux-primary btn-lux-sm">
                                    Browse Catalog &rarr;
                                </a>
                            </div>
                        </div>
                    <?php else: ?>
                        <!-- Orders List -->
                        <div class="space-y-4">
                            <?php foreach ($orders as $o):
                                $statusMap = [
                                    'pending'   => ['bg-amber-100 text-amber-800 border-amber-200', 'Pending'],
                                    'confirmed' => ['bg-sky-100 text-sky-800 border-sky-200', 'Confirmed'],
                                    'shipped'   => ['bg-indigo-100 text-indigo-800 border-indigo-200', 'Shipped'],
                                    'delivered' => ['bg-emerald-100 text-emerald-800 border-emerald-200', 'Delivered'],
                                    'cancelled' => ['bg-rose-100 text-rose-800 border-rose-200', 'Cancelled'],
                                ];
                                $st = $statusMap[$o['orderStatus']] ?? ['bg-slate-100 text-slate-800 border-slate-200', ucfirst($o['orderStatus'])];
                                $isExpanded = isset($_GET['order']) && (int)$_GET['order'] === (int)$o['id'];
                            ?>
                                <div class="border border-border rounded-2xl overflow-hidden bg-white hover:border-slate-300 transition shadow-sm">
                                    <div class="p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4 bg-slate-50/50">
                                        <div class="space-y-1">
                                            <div class="flex items-center gap-2">
                                                <span class="font-display font-extrabold text-sm text-foreground">#<?= str_pad($o['id'], 6, '0', STR_PAD_LEFT) ?></span>
                                                <span class="text-[10px] font-bold px-2 py-0.5 rounded-full border <?= $st[0] ?>"><?= $st[1] ?></span>
                                                <span class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-100 text-slate-700"><?= e($o['paymentMethod']) ?></span>
                                            </div>
                                            <p class="text-xs text-muted-foreground m-0">
                                                Placed on <?= $o['orderDate'] ? date('d M Y, h:i A', strtotime($o['orderDate'])) : '-' ?>
                                            </p>
                                        </div>

                                        <div class="flex items-center gap-4">
                                            <div class="text-right">
                                                <span class="text-[11px] text-muted-foreground block">Order Total</span>
                                                <strong class="font-display text-base font-extrabold text-foreground"><?= formatCurrency($o['totalAmount']) ?></strong>
                                            </div>
                                            <a href="<?= base_url('/shop/account?tab=orders' . ($isExpanded ? '' : '&order=' . (int)$o['id'])) ?>"
                                               class="btn-lux btn-lux-outline btn-lux-sm">
                                                <?= $isExpanded ? 'Hide Details' : 'View Details' ?>
                                            </a>
                                        </div>
                                    </div>

                                    <!-- Expanded Order Details -->
                                    <?php if ($isExpanded): ?>
                                        <div class="p-5 border-t border-border space-y-5 bg-white">
                                            <div>
                                                <h5 class="text-xs font-extrabold uppercase tracking-widest text-muted-foreground mb-3">Shipment Items (<?= count($o['cartItems']) ?>)</h5>
                                                <div class="divide-y divide-border border border-border rounded-2xl overflow-hidden">
                                                    <?php foreach ($o['cartItems'] as $ci):
                                                        $p = (float)($ci['salePrice'] ?? $ci['price']);
                                                    ?>
                                                        <div class="p-3.5 flex items-center gap-3">
                                                            <div class="w-12 h-14 rounded-xl bg-slate-100 flex-shrink-0 overflow-hidden border border-border/60">
                                                                <img src="<?= e(product_image_url($ci['image'] ?? '')) ?>" alt=""
                                                                     onerror="this.onerror=null;this.src='<?= e(product_image_url('')) ?>';"
                                                                     class="w-full h-full object-cover"/>
                                                            </div>
                                                            <div class="flex-1 min-w-0">
                                                                <h6 class="text-xs font-bold text-foreground line-clamp-1 m-0"><?= e($ci['title']) ?></h6>
                                                                <span class="text-[11px] text-muted-foreground">Qty: <?= (int)$ci['quantity'] ?> × <?= formatCurrency($p) ?></span>
                                                            </div>
                                                            <span class="font-display text-xs font-bold text-foreground"><?= formatCurrency($p * (int)$ci['quantity']) ?></span>
                                                        </div>
                                                    <?php endforeach ?>
                                                </div>
                                            </div>

                                            <!-- Delivery Address & Payment Summary -->
                                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                                                <?php if (!empty($o['addressInfo'])): ?>
                                                    <div class="p-4 rounded-2xl bg-slate-50 border border-border space-y-1">
                                                        <span class="font-extrabold text-foreground block uppercase tracking-wider text-[10px]">Delivery Address:</span>
                                                        <p class="m-0 font-bold"><?= e($user['userName']) ?></p>
                                                        <p class="m-0 text-muted-foreground"><?= e($o['addressInfo']['address']) ?></p>
                                                        <p class="m-0 text-muted-foreground"><?= e($o['addressInfo']['city']) ?> - <?= e($o['addressInfo']['pincode']) ?></p>
                                                        <p class="m-0 text-muted-foreground font-semibold">📞 <?= e($o['addressInfo']['phone']) ?></p>
                                                    </div>
                                                <?php endif ?>

                                                <div class="p-4 rounded-2xl bg-slate-50 border border-border space-y-2">
                                                    <span class="font-extrabold text-foreground block uppercase tracking-wider text-[10px]">Payment Summary:</span>
                                                    <div class="flex justify-between">
                                                        <span class="text-muted-foreground">Mode:</span>
                                                        <span class="font-bold uppercase"><?= e($o['paymentMethod']) ?></span>
                                                    </div>
                                                    <div class="flex justify-between">
                                                        <span class="text-muted-foreground">Status:</span>
                                                        <span class="font-bold text-emerald-700"><?= ucfirst(e($o['paymentStatus'])) ?></span>
                                                    </div>
                                                    <div class="flex justify-between pt-1 border-t border-border">
                                                        <span class="font-bold">Total Paid:</span>
                                                        <span class="font-display font-black text-foreground text-sm"><?= formatCurrency($o['totalAmount']) ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif ?>
                                </div>
                            <?php endforeach ?>
                        </div>
                    <?php endif ?>
                </div>

            <?php elseif ($tab === 'addresses'): ?>
                <!-- Addresses Tab -->
                <div class="card-lux p-6 sm:p-8 space-y-6">
                    <div class="flex items-center justify-between pb-3 border-b border-border">
                        <div>
                            <h3 class="font-display text-xl font-bold text-foreground m-0">Saved Delivery Addresses</h3>
                            <p class="text-xs text-muted-foreground m-0 mt-0.5">Manage and organize your doorstep delivery locations</p>
                        </div>
                        <button type="button" id="addNewAddrBtn" class="btn-lux btn-lux-primary btn-lux-sm">
                            + Add New Address
                        </button>
                    </div>

                    <?php if (empty($addresses)): ?>
                        <div class="p-12 text-center rounded-3xl border border-dashed border-border bg-slate-50 space-y-3">
                            <span class="text-3xl">📍</span>
                            <h4 class="font-display font-bold text-base text-foreground m-0">No Saved Addresses</h4>
                            <p class="text-xs text-muted-foreground max-w-xs mx-auto">Save your addresses for instant one-click checkout.</p>
                            <div class="pt-2">
                                <button type="button" onclick="document.getElementById('addNewAddrBtn').click()" class="btn-lux btn-lux-primary btn-lux-sm">
                                    Register First Address
                                </button>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <?php foreach ($addresses as $a): ?>
                                <div class="address-card-lux space-y-3 flex flex-col justify-between">
                                    <div>
                                        <div class="flex items-center justify-between mb-2">
                                            <span class="font-bold text-xs text-foreground"><?= e($user['userName']) ?></span>
                                            <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">Verified</span>
                                        </div>
                                        <div class="text-xs text-muted-foreground space-y-0.5">
                                            <p class="m-0 font-medium text-foreground"><?= e($a['address']) ?></p>
                                            <p class="m-0"><?= e($a['city']) ?>, PIN: <?= e($a['pincode']) ?></p>
                                            <p class="m-0 pt-1 font-semibold text-foreground">📞 <?= e($a['phone']) ?></p>
                                            <?php if (!empty($a['notes'])): ?>
                                                <p class="m-0 italic pt-0.5 text-slate-400 text-[11px]">Note: <?= e($a['notes']) ?></p>
                                            <?php endif ?>
                                        </div>
                                    </div>

                                    <div class="pt-3 border-t border-border flex items-center justify-end gap-2">
                                        <button type="button" class="btn-lux btn-lux-outline btn-lux-sm text-xs addr-edit-btn"
                                                data-id="<?= (int)$a['id'] ?>"
                                                data-address="<?= e($a['address']) ?>"
                                                data-city="<?= e($a['city']) ?>"
                                                data-pincode="<?= e($a['pincode']) ?>"
                                                data-phone="<?= e($a['phone']) ?>"
                                                data-notes="<?= e($a['notes'] ?? '') ?>">
                                            Edit
                                        </button>
                                        <button type="button" class="btn-lux btn-lux-outline btn-lux-sm text-xs text-rose-700 hover:bg-rose-50 addr-del-btn" data-id="<?= (int)$a['id'] ?>">
                                            Delete
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach ?>
                        </div>
                    <?php endif ?>
                </div>

                <!-- Add / Edit Address Dialog Modal -->
                <div id="accountAddrModal" class="dialog-overlay hidden">
                    <div class="dialog max-w-md w-full rounded-3xl bg-white border border-border shadow-2xl overflow-hidden animate-fade-in-scale">
                        <div class="p-5 border-b border-border flex items-center justify-between bg-slate-50/50">
                            <h3 id="addrModalTitle" class="font-display text-base font-extrabold text-foreground m-0">Add Delivery Destination</h3>
                            <button type="button" id="closeAddrModal" class="btn btn-ghost btn-icon rounded-full" aria-label="Close dialog">&times;</button>
                        </div>
                        <form id="accountAddrForm" class="addr-form" onsubmit="handleAddressSubmit(event)">
                            <input type="hidden" id="editAddrId"/>
                            <div class="addr-field">
                                <label for="in_addr">Street address <span>*</span></label>
                                <textarea id="in_addr" required rows="2" placeholder="Flat, building, street, locality" class="form-textarea-lux"></textarea>
                            </div>
                            <div class="addr-row">
                                <div class="addr-field">
                                    <label for="in_city">City <span>*</span></label>
                                    <input id="in_city" required placeholder="City" class="form-input-lux"/>
                                </div>
                                <div class="addr-field">
                                    <label for="in_pin">Pincode <span>*</span></label>
                                    <input id="in_pin" required pattern="[0-9]{4,10}" placeholder="380001" class="form-input-lux"/>
                                </div>
                            </div>
                            <div class="addr-field">
                                <label for="in_phone">Phone number <span>*</span></label>
                                <input id="in_phone" required pattern="[0-9 +-]{7,15}" placeholder="+91 98765 43210" class="form-input-lux"/>
                            </div>
                            <div class="addr-field">
                                <label for="in_notes">Delivery notes <em>Optional</em></label>
                                <input id="in_notes" placeholder="Leave with building security" class="form-input-lux"/>
                            </div>
                            <div class="addr-actions">
                                <button type="button" id="cancelAddrModal" class="btn-lux btn-lux-outline btn-lux-sm">Cancel</button>
                                <button type="submit" class="btn-lux btn-lux-primary btn-lux-sm">Save address</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif ?>
        </section>
    </div>
</div>

<script>
const __UID = <?= (int)$user['id'] ?>;

// Profile Update Handler
async function handleProfileUpdate(e) {
    e.preventDefault();
    const btn = document.getElementById('profSaveBtn');
    btn.disabled = true;
    btn.textContent = 'Saving...';
    try {
        await Auth.updateProfile(
            document.getElementById('profUserName').value.trim(),
            document.getElementById('profEmail').value.trim()
        );
        toast('Success', 'Profile updated successfully!', 'success');
        setTimeout(() => location.reload(), 400);
    } catch(err) {
        btn.disabled = false;
        btn.textContent = 'Save Profile Changes';
    }
}

// Password Update Handler
async function handlePasswordUpdate(e) {
    e.preventDefault();
    const cur = document.getElementById('curPwd').value;
    const newP = document.getElementById('newPwd').value;
    const cnf = document.getElementById('cnfPwd').value;

    if (newP !== cnf) {
        toast('Validation Error', 'New passwords do not match', 'error');
        return;
    }
    const btn = document.getElementById('pwdSaveBtn');
    btn.disabled = true;
    btn.textContent = 'Updating...';
    try {
        await Auth.updatePassword(cur, newP, cnf);
        toast('Success', 'Password has been changed successfully!', 'success');
        document.getElementById('passwordUpdateForm').reset();
    } catch(err) {}
    finally {
        btn.disabled = false;
        btn.textContent = 'Update Password';
    }
}

// Address Modal controls & submissions
const addrModal = document.getElementById('accountAddrModal');
document.getElementById('addNewAddrBtn')?.addEventListener('click', () => {
    document.getElementById('addrModalTitle').textContent = 'Add Delivery Address';
    document.getElementById('accountAddrForm').reset();
    document.getElementById('editAddrId').value = '';
    addrModal?.classList.remove('hidden');
});
document.getElementById('closeAddrModal')?.addEventListener('click', () => addrModal?.classList.add('hidden'));
document.getElementById('cancelAddrModal')?.addEventListener('click', () => addrModal?.classList.add('hidden'));

document.querySelectorAll('.addr-edit-btn').forEach(b => {
    b.addEventListener('click', () => {
        document.getElementById('addrModalTitle').textContent = 'Edit Delivery Address';
        document.getElementById('editAddrId').value = b.dataset.id || '';
        document.getElementById('in_addr').value = b.dataset.address || '';
        document.getElementById('in_city').value = b.dataset.city || '';
        document.getElementById('in_pin').value = b.dataset.pincode || '';
        document.getElementById('in_phone').value = b.dataset.phone || '';
        document.getElementById('in_notes').value = b.dataset.notes || '';
        addrModal?.classList.remove('hidden');
    });
});

document.querySelectorAll('.addr-del-btn').forEach(b => {
    b.addEventListener('click', async () => {
        if (!confirm('Are you sure you want to delete this address?')) return;
        try {
            await AddressApi.remove(b.dataset.id);
            toast('Deleted', 'Address removed from your profile', 'info');
            setTimeout(() => location.reload(), 400);
        } catch(e) {}
    });
});

async function handleAddressSubmit(e) {
    e.preventDefault();
    const editId = document.getElementById('editAddrId').value;
    const payload = {
        address: document.getElementById('in_addr').value.trim(),
        city:    document.getElementById('in_city').value.trim(),
        pincode: document.getElementById('in_pin').value.trim(),
        phone:   document.getElementById('in_phone').value.trim(),
        notes:   document.getElementById('in_notes').value.trim(),
    };
    try {
        if (editId) {
            await AddressApi.update(editId, payload);
            toast('Success', 'Address updated successfully!', 'success');
        } else {
            await AddressApi.add(payload);
            toast('Success', 'Address added to your profile!', 'success');
        }
        setTimeout(() => location.reload(), 400);
    } catch(e) {}
}
</script>

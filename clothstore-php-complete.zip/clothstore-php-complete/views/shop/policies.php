<?php
/**
 * Customer Care & Store Policies
 * Tabbed viewer for Shipping, Returns, Privacy, and Terms of Service.
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'policies';

$section = $_GET['section'] ?? '';
if (!$section) {
    $uriPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $section = basename($uriPath);
}
$allowedSections = ['shipping', 'returns', 'privacy', 'terms'];
if (!in_array($section, $allowedSections)) $section = 'shipping';

$policyData = [
    'shipping' => [
        'title' => 'Shipping & Delivery Policy',
        'icon'  => '🚚',
        'items' => [
            ['Free Express Delivery on all orders above ₹1,000 across India.', 'A nominal logistics contribution of ₹99 applies on orders below ₹1,000.'],
            ['Estimated delivery timeline: 3 to 5 business days for major Tier-1 Metros, and 5 to 7 days for regional destinations.'],
            ['Our logistics consortium includes premier couriers: BlueDart, Delhivery Air, and XpressBees with door-to-door tracking.'],
            ['Live shipment dispatch link is communicated via SMS & Email immediately upon package departure from our atelier.'],
            ['Cash on Delivery (COD) is available on orders up to ₹10,000 across all serviceable postal codes.'],
        ],
    ],
    'returns' => [
        'title' => 'Returns & Exchange Policy',
        'icon'  => '🔄',
        'items' => [
            ['Complimentary 7-day doorstep exchange and return window from the day of recorded physical delivery.'],
            ['Garments must be unworn, undamaged, unwashed, and retained with all original silk tags & protective garment bags intact.'],
            ['Initiation process: Navigate to Patron Portal → My Orders → Select Consignment → Click Request Concierge Return.'],
            ['Complimentary doorstep reverse pickup scheduled within 24 to 48 hours without packaging hassle.'],
            ['Full refunds are credited within 3-5 business days back to your initial payment mode or direct UPI account.'],
        ],
    ],
    'privacy' => [
        'title' => 'Privacy & Data Protection Policy',
        'icon'  => '🔒',
        'items' => [
            ['We are dedicated to safeguarding patron privacy, personal confidentiality, and transactional integrity.'],
            ['Information captured: Name, email address, contact telephone, delivery address, and encrypted transactional records.'],
            ['Usage scope: Order fulfillment, dispatch communications, fraud prevention, and personalized bespoke styling recommendations.'],
            ['Strict Policy: We NEVER monetize, lease, or distribute patron contact information to third-party marketing brokers.'],
            ['All digital checkout transactions are secured using bank-standard 256-Bit SSL encryption algorithms.'],
        ],
    ],
    'terms' => [
        'title' => 'Terms of Commercial Service',
        'icon'  => '📋',
        'items' => [
            ['By placing an order with ' . e(APP_NAME) . ', patrons agree to abide by our established retail and service standards.'],
            ['All garment pricing is denoted in Indian National Rupees (₹) and is fully inclusive of applicable GST goods & services taxes.'],
            ['We strive for faithful color accuracy; subtle variations in hue may arise based on individual screen calibration.'],
            ['We reserve the right to decline suspicious or automated transactions and rectify unintended clerical pricing errors.'],
            ['Legal jurisdiction: All disputes subject exclusively to the competent judicial courts of Ahmedabad, Gujarat.'],
        ],
    ],
];
$policy = $policyData[$section] ?? reset($policyData);
$pageTitle = $policy['title'];
?>
<div class="container py-10 max-w-4xl space-y-8">
    <!-- Header -->
    <div class="text-center space-y-3 max-w-xl mx-auto">
        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-slate-800 text-[10px] uppercase font-extrabold tracking-widest">
            Patron Transparency
        </span>
        <h1 class="font-display text-3xl sm:text-5xl font-extrabold text-foreground tracking-tight m-0">
            Client Care & Policies
        </h1>
        <p class="text-xs sm:text-sm text-muted-foreground leading-relaxed m-0">
            Clear guidelines regarding our logistics, return courtesies, data confidentiality, and service terms.
        </p>
    </div>

    <!-- Navigation Tabs -->
    <div class="flex flex-wrap items-center justify-center gap-2 p-1.5 bg-slate-100 rounded-full border border-border">
        <?php foreach ($policyData as $k => $p): ?>
            <a href="<?= base_url('/shop/policies/' . $k) ?>"
               class="px-5 py-2 rounded-full text-xs font-bold transition <?= $k === $section ? 'bg-slate-900 text-white shadow-sm' : 'text-slate-600 hover:text-foreground hover:bg-white/50' ?>">
                <span class="mr-1.5"><?= $p['icon'] ?></span> <?= $p['title'] ?>
            </a>
        <?php endforeach ?>
    </div>

    <!-- Policy Card -->
    <div class="card-lux overflow-hidden">
        <div class="p-6 sm:p-8 border-b border-border bg-slate-50/50 flex flex-wrap items-center justify-between gap-4">
            <div class="flex items-center gap-3.5">
                <div class="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-xl shadow-sm">
                    <?= $policy['icon'] ?>
                </div>
                <div>
                    <h2 class="font-display text-xl font-bold text-foreground m-0"><?= $policy['title'] ?></h2>
                    <span class="text-[11px] text-muted-foreground font-semibold">Current Revision: <?= date('F Y') ?></span>
                </div>
            </div>
            <a href="<?= base_url('/shop/contact') ?>" class="btn-lux btn-lux-outline btn-lux-sm">
                Inquire With Concierge &rarr;
            </a>
        </div>

        <div class="p-6 sm:p-8 space-y-6">
            <ol class="space-y-4 p-0 m-0 list-none">
                <?php foreach ($policy['items'] as $idx => $item):
                    $texts = is_array($item) ? $item : [$item];
                ?>
                    <li class="flex items-start gap-4">
                        <div class="w-7 h-7 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5 shadow-sm">
                            <?= $idx + 1 ?>
                        </div>
                        <div class="space-y-1 text-xs sm:text-sm text-slate-600 leading-relaxed">
                            <?php foreach ($texts as $t): ?>
                                <p class="m-0 text-foreground"><?= $t ?></p>
                            <?php endforeach ?>
                        </div>
                    </li>
                <?php endforeach ?>
            </ol>

            <div class="pt-6 border-t border-border flex flex-wrap items-center justify-between gap-4 text-xs">
                <span class="text-muted-foreground">Have additional questions regarding <?= strtolower($policy['title']) ?>?</span>
                <div class="flex items-center gap-3">
                    <a href="mailto:concierge@clothstore.com" class="text-foreground font-bold hover:underline">✉️ concierge@clothstore.com</a>
                    <span>•</span>
                    <a href="tel:+919876543210" class="text-foreground font-bold hover:underline">📞 +91 98765 43210</a>
                </div>
            </div>
        </div>
    </div>
</div>

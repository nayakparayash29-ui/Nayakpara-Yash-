<?php
/**
 * Dedicated Customer Wishlist Page
 * High-fashion saved curation with instant move to shopping bag,
 * price indicators, and empty state guidance.
 */
if (!isset($viewContent)) $viewContent = __FILE__;
requireLogin();
$active = 'wishlist';
$pageTitle = 'My Saved Wishlist';

$user = currentUser();
require_once __DIR__ . '/../../models/Wishlist.php';
$wm = new WishlistModel();

$items = $wm->getByUserId($user['id']);
?>
<div class="container py-8 space-y-8">
    <!-- Breadcrumbs & Header -->
    <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-border">
        <div>
            <nav class="flex items-center gap-1.5 text-xs text-muted-foreground mb-2">
                <a href="<?= base_url('/shop/home') ?>" class="hover:text-foreground transition">Home</a>
                <span>/</span>
                <span class="text-foreground font-bold">Wishlist</span>
            </nav>
            <h1 class="font-display text-3xl sm:text-4xl font-extrabold text-foreground m-0 tracking-tight">
                My Saved Wishlist
            </h1>
            <p class="text-xs text-muted-foreground m-0 mt-1">
                You have <strong><?= count($items) ?></strong> pieces saved in your personal atelier curation
            </p>
        </div>
        <a href="<?= base_url('/shop/listing') ?>" class="btn-lux btn-lux-outline btn-lux-sm self-start sm:self-auto">
            ← Explore Catalog
        </a>
    </div>

    <?php if (empty($items)): ?>
        <div class="card p-16 text-center rounded-3xl max-w-lg mx-auto border border-dashed border-border bg-white shadow-sm space-y-4">
            <div class="w-20 h-20 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto text-3xl shadow-sm">
                ❤️
            </div>
            <h3 class="font-display text-xl font-bold text-foreground m-0">Your Wishlist is Empty</h3>
            <p class="text-xs text-muted-foreground max-w-xs mx-auto leading-relaxed">
                Explore our curated catalog and tap the heart icon on any silhouette to curate your dream wardrobe here.
            </p>
            <div class="pt-2">
                <a href="<?= base_url('/shop/listing') ?>" class="btn-lux btn-lux-primary btn-lux-sm">
                    Discover Collections &rarr;
                </a>
            </div>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            <?php foreach ($items as $p):
                $price = getDisplayPrice($p);
                $origPrice = (float)$p['price'];
                $discount = $origPrice > 0 && $price < $origPrice ? round((1 - $price / $origPrice) * 100) : 0;
            ?>
                <div class="card-product-lux group">
                    <div class="product-media-wrap" onclick="location.href='<?= base_url('/shop/product/' . (int)$p['id']) ?>'">
                        <img src="<?= e(product_image_url($p['image'])) ?>" alt="<?= e($p['title']) ?>"
                             onerror="this.onerror=null;this.src='<?= e(product_image_url('')) ?>';"
                             class="product-media-img" loading="lazy"/>

                        <div class="badge-floating-corner">
                            <?php if ($discount > 0): ?>
                                <span class="badge-lux-sale">-<?= $discount ?>%</span>
                            <?php endif ?>
                            <?php if (!empty($p['brand'])): ?>
                                <span class="badge-lux-new"><?= e($p['brand']) ?></span>
                            <?php endif ?>
                        </div>

                        <!-- Remove Button -->
                        <button type="button" class="btn-wishlist-float wishlisted"
                                onclick="event.stopPropagation(); removeWishlistItem(<?= (int)$p['id'] ?>)"
                                title="Remove from wishlist" aria-label="Remove from wishlist">
                            <svg width="17" height="17" viewBox="0 0 24 24" fill="#be123c" stroke="#be123c" stroke-width="2">
                                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                            </svg>
                        </button>

                        <?php if (!$p['totalStock']): ?>
                            <div class="stock-scrim">
                                <span class="stock-scrim-pill">SOLD OUT</span>
                            </div>
                        <?php endif ?>
                    </div>

                    <div class="product-info-wrap">
                        <div>
                            <p class="product-brand-tag"><?= e($p['category'] ?? 'Atelier') ?></p>
                            <h4 class="product-title-lux">
                                <a href="<?= base_url('/shop/product/' . (int)$p['id']) ?>"><?= e($p['title']) ?></a>
                            </h4>
                            <div class="product-meta-row">
                                <?= renderStars($p['averageReview'], 12) ?>
                                <span class="product-reviews-count">(<?= round((float)$p['averageReview'], 1) ?>)</span>
                            </div>
                        </div>

                        <div class="product-price-row">
                            <div>
                                <span class="price-current-lux"><?= formatCurrency($price) ?></span>
                                <?php if ($origPrice > $price): ?>
                                    <span class="price-original-lux"><?= formatCurrency($origPrice) ?></span>
                                <?php endif ?>
                            </div>
                            <span class="text-[11px] font-bold <?= $p['totalStock'] > 0 ? 'text-emerald-700' : 'text-rose-600' ?>">
                                <?= $p['totalStock'] > 0 ? 'In Stock' : 'Sold Out' ?>
                            </span>
                        </div>

                        <div class="pt-3 border-t border-border mt-3">
                            <button type="button" class="btn-lux btn-lux-primary w-full text-xs"
                                    onclick="moveToCart(<?= (int)$p['id'] ?>)" <?= !$p['totalStock'] ? 'disabled' : '' ?>>
                                🛒 Move to Bag
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach ?>
        </div>
    <?php endif ?>
</div>

<script>
const __UID = '<?= (int)$user['id'] ?>';

async function removeWishlistItem(productId) {
    try {
        await WishlistApi.remove(productId);
        toast('Removed', 'Garment removed from your wishlist', 'info');
        setTimeout(() => location.reload(), 400);
    } catch(e) {}
}

async function moveToCart(productId) {
    try {
        await CartApi.add(__UID, productId, 1);
        await WishlistApi.remove(productId);
        toast('Moved to Bag', 'Item added to your shopping bag!', 'success');
        setTimeout(() => location.reload(), 400);
    } catch(e) {}
}
</script>

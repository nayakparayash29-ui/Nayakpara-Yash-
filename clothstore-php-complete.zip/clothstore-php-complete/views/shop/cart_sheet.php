<?php
/**
 * Cart Sheet Drawer Content
 * High-fashion real-time shopping bag with progress bar, quantity controls,
 * promo code redemption, and express checkout.
 */
$user = currentUser();
$items = [];
$total = 0;
$subtotal = 0;

if ($user) {
    require_once __DIR__ . '/../../models/Cart.php';
    $cm = new CartModel();
    $cart = $cm->getPopulatedCart($user['id']);
    if ($cart) $items = $cart['items'] ?? [];
    foreach ($items as $it) {
        $p = (float)($it['salePrice'] ?: $it['price']);
        $subtotal += $p * (int)$it['quantity'];
    }
    $shipping = $subtotal > 0 ? ($subtotal >= 1000 ? 0 : 99) : 0;
    $total = $subtotal + $shipping;
}
?>
<?php if (empty($items)): ?>
    <div class="text-center py-16 px-4">
        <div class="w-20 h-20 rounded-3xl bg-slate-100 flex items-center justify-center mx-auto mb-4 text-slate-400">
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
            </svg>
        </div>
        <h4 class="text-lg font-bold text-foreground m-0">Your Bag is Empty</h4>
        <p class="text-xs text-muted-foreground mt-2 mb-6 max-w-xs mx-auto">Explore our curated collections of modern apparel and footwear.</p>
        <a href="<?= base_url('/shop/listing') ?>" class="btn-lux btn-lux-primary btn-lux-sm" data-sheet-toggle="cartSheet">
            Discover Collections &rarr;
        </a>
    </div>
<?php else: ?>
    <!-- Free Delivery Milestone Bar -->
    <div class="free-delivery-milestone">
        <?php if ($subtotal >= 1000): ?>
            <div class="flex items-center gap-1.5 text-emerald-700 font-bold text-xs">
                <span>🎉</span> You've unlocked <strong>Complimentary Express Delivery!</strong>
            </div>
            <div class="progress-track">
                <div class="progress-bar-fill" style="width: 100%;"></div>
            </div>
        <?php else: ?>
            <?php $pct = min(100, round(($subtotal / 1000) * 100)); ?>
            <div class="flex items-center justify-between text-xs text-muted-foreground">
                <span>Add <strong><?= formatCurrency(1000 - $subtotal) ?></strong> more for Free Shipping</span>
                <span class="font-bold text-foreground"><?= $pct ?>%</span>
            </div>
            <div class="progress-track">
                <div class="progress-bar-fill" style="width: <?= $pct ?>%;"></div>
            </div>
        <?php endif ?>
    </div>

    <!-- Items List -->
    <div class="space-y-3 mb-4 max-h-[46vh] overflow-y-auto pr-1">
        <?php foreach ($items as $it):
            $p = (float)($it['salePrice'] ?: $it['price']);
            $lineTotal = $p * (int)$it['quantity'];
        ?>
            <div class="flex gap-3.5 p-3.5 border border-border rounded-2xl bg-white shadow-sm hover:border-slate-300 transition" data-cart-item="<?= (int)$it['productId'] ?>">
                <div class="w-18 h-22 sm:w-20 sm:h-24 bg-slate-100 rounded-xl flex-shrink-0 overflow-hidden border border-border/80" style="width:72px;height:90px;">
                    <img src="<?= e(product_image_url($it['image'] ?? '')) ?>" alt="<?= e($it['title']) ?>"
                         onerror="this.onerror=null;this.src='<?= e(product_image_url('')) ?>';"
                         class="w-full h-full object-cover"/>
                </div>

                <div class="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                        <div class="flex items-start justify-between gap-2">
                            <h5 class="text-xs font-bold text-foreground m-0 line-clamp-1 leading-snug"><?= e($it['title']) ?></h5>
                            <button type="button" class="cart-remove-btn"
                                    onclick="event.stopPropagation(); removeCartItem(<?= (int)$it['productId'] ?>)" title="Remove item" aria-label="Remove item">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
                            </button>
                        </div>
                        <p class="text-xs font-extrabold text-foreground mt-1 m-0"><?= formatCurrency($p) ?></p>
                    </div>

                    <div class="flex items-center justify-between pt-2">
                        <!-- Quantity Stepper -->
                        <div class="qty-stepper-lux" style="height:32px;">
                            <button type="button" class="qty-stepper-btn" style="width:28px;"
                                    onclick="event.stopPropagation(); updateCartItemQty(<?= (int)$it['productId'] ?>, <?= max(1, (int)$it['quantity'] - 1) ?>)">
                                -
                            </button>
                            <span class="qty-stepper-val text-xs" style="width:28px;"><?= (int)$it['quantity'] ?></span>
                            <button type="button" class="qty-stepper-btn" style="width:28px;"
                                    onclick="event.stopPropagation(); updateCartItemQty(<?= (int)$it['productId'] ?>, <?= (int)$it['quantity'] + 1 ?>)">
                                +
                            </button>
                        </div>

                        <span class="text-xs font-bold text-foreground"><?= formatCurrency($lineTotal) ?></span>
                    </div>
                </div>
            </div>
        <?php endforeach ?>
    </div>

    <!-- Promo Code Entry in Drawer -->
    <div class="p-3 bg-slate-50 border border-border rounded-xl mb-4">
        <div class="flex gap-2">
            <input type="text" id="drawerCouponInput" placeholder="Promo code (e.g. WELCOME20)"
                   class="form-input text-xs uppercase font-bold flex-1 rounded-lg" style="height:2.3rem;"/>
            <button type="button" id="drawerApplyCouponBtn" onclick="applyDrawerCoupon()" class="btn-lux btn-lux-outline btn-lux-sm px-3.5">
                Apply
            </button>
        </div>
        <div id="drawerCouponResult" class="text-[11px] font-semibold mt-1.5 hidden"></div>
    </div>

    <!-- Order Breakdown -->
    <div class="border-t border-border pt-3.5 space-y-2 text-xs">
        <div class="flex justify-between text-muted-foreground">
            <span>Subtotal</span>
            <span class="font-bold text-foreground" id="drawerSubtotal"><?= formatCurrency($subtotal) ?></span>
        </div>
        <div id="drawerDiscountRow" class="flex justify-between text-emerald-600 font-bold" style="display:none;">
            <span>Promo Savings</span>
            <span id="drawerDiscountVal">-₹0.00</span>
        </div>
        <div class="flex justify-between text-muted-foreground">
            <span>Estimated Shipping</span>
            <span class="font-bold" id="drawerShipping">
                <?= $shipping === 0 ? '<span class="text-emerald-600 font-bold">FREE</span>' : formatCurrency($shipping) ?>
            </span>
        </div>
        <div class="flex justify-between pt-2.5 border-t border-border text-sm font-extrabold text-foreground">
            <span>Grand Total</span>
            <span class="text-base font-black text-foreground" id="drawerTotal"><?= formatCurrency($total) ?></span>
        </div>
    </div>

    <!-- Action Buttons -->
    <div class="grid grid-cols-2 gap-2 mt-4 pt-2">
        <a href="<?= base_url('/shop/cart') ?>" class="btn-lux btn-lux-outline text-xs text-center">
            View Bag
        </a>
        <a href="<?= base_url('/shop/checkout') ?>" class="btn-lux btn-lux-primary text-xs text-center">
            Checkout &rarr;
        </a>
    </div>

    <script>
    const __CART_UID = '<?= (int)($user['id'] ?? 0) ?>';
    let __appliedDiscount = 0;

    function keepCartSheetOpen() {
        document.getElementById('cartSheet')?.classList.add('open');
        document.querySelector('[data-sheet-overlay="cartSheet"]')?.classList.add('open');
    }

    async function refreshCartSheet() {
        const res = await fetch(window.location.href, { credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch' } });
        const html = await res.text();
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const next = doc.getElementById('cartSheetContent');
        const current = document.getElementById('cartSheetContent');
        if (next && current) current.innerHTML = next.innerHTML;
        const nextCount = doc.getElementById('cartSheetCount');
        const liveCount = document.getElementById('cartSheetCount');
        if (nextCount && liveCount) liveCount.textContent = nextCount.textContent;
        const nextBadge = doc.getElementById('headerCartCount');
        const liveBadge = document.getElementById('headerCartCount');
        if (nextBadge && liveBadge) {
            liveBadge.textContent = nextBadge.textContent;
            liveBadge.style.display = nextBadge.style.display;
        }
        keepCartSheetOpen();
    }

    async function updateCartItemQty(productId, newQty) {
        if (!__CART_UID || newQty < 1) return;
        keepCartSheetOpen();
        try {
            await CartApi.updateQty(__CART_UID, productId, newQty);
            await refreshCartSheet();
        } catch (e) {
            keepCartSheetOpen();
        }
    }

    async function removeCartItem(productId) {
        if (!__CART_UID) return;
        keepCartSheetOpen();
        try {
            await CartApi.remove(__CART_UID, productId);
            await refreshCartSheet();
        } catch (e) {
            keepCartSheetOpen();
        }
    }

    async function applyDrawerCoupon() {
        const inp = document.getElementById('drawerCouponInput');
        const resBox = document.getElementById('drawerCouponResult');
        const code = inp ? inp.value.trim().toUpperCase() : '';
        if (!code) return;
        const subtotal = <?= $subtotal ?>;
        try {
            const res = await CouponApi.apply(code, subtotal);
            const disc = res.data.discountAmount || 0;
            __appliedDiscount = disc;
            resBox.className = 'text-[11px] font-bold mt-1.5 text-emerald-600';
            resBox.textContent = `Coupon Applied! Saved ₹${disc.toFixed(2)}`;
            resBox.style.display = 'block';

            // Update UI totals
            document.getElementById('drawerDiscountRow').style.display = 'flex';
            document.getElementById('drawerDiscountVal').textContent = `-₹${disc.toFixed(2)}`;
            const shipping = subtotal >= 1000 ? 0 : 99;
            const newTotal = Math.max(0, subtotal + shipping - disc);
            document.getElementById('drawerTotal').textContent = formatCurrency(newTotal);
            sessionStorage.setItem('applied_coupon', JSON.stringify(res.data));
            toast('Promo Code Applied', res.message, 'success');
        } catch(e) {
            resBox.className = 'text-[11px] font-bold mt-1.5 text-rose-500';
            resBox.textContent = e.message || 'Invalid coupon code';
            resBox.style.display = 'block';
        }
    }
    </script>
<?php endif ?>

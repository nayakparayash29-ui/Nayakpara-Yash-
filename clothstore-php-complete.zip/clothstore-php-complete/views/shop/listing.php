<?php
/**
 * Product Listing Page (The Catalog)
 * Architectural catalog view with sticky filter sidebar, responsive mobile filter drawer,
 * active filter pills, luxury product cards, quick view modal, and live cart/wishlist actions.
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'listing';

require_once __DIR__ . '/../../models/Product.php';
require_once __DIR__ . '/../../models/Review.php';
require_once __DIR__ . '/../../models/Wishlist.php';

$pm = new ProductModel();
$rm = new ReviewModel();
$wm = new WishlistModel();

$filters = [];
if (!empty($_GET['category'])) $filters['category'] = $_GET['category'];
if (!empty($_GET['brand']))    $filters['brand']    = $_GET['brand'];
$sortBy = $_GET['sortBy'] ?? 'price-lowtohigh';
$search = trim($_GET['q'] ?? $_GET['search'] ?? '');
if ($search) $filters['search'] = $search;

$products = $pm->findAll($filters, $sortBy);
$categories = $pm->getDistinctCategories();
$brands     = $pm->getDistinctBrands();

$highlight = $_GET['highlight'] ?? null;
$user = currentUser();
$userWishlistIds = $user ? $wm->getProductIdsByUser($user['id']) : [];

$activeCats = !empty($filters['category']) ? explode(',', $filters['category']) : [];
$activeBrands = !empty($filters['brand']) ? explode(',', $filters['brand']) : [];
?>
<div class="container py-8 space-y-8">
    <!-- Breadcrumbs & Catalog Header -->
    <div class="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-border">
        <div>
            <nav class="flex items-center gap-1.5 text-xs text-muted-foreground mb-2">
                <a href="<?= base_url('/shop/home') ?>" class="hover:text-foreground transition">Home</a>
                <span>/</span>
                <a href="<?= base_url('/shop/listing') ?>" class="hover:text-foreground transition font-medium">Catalog</a>
                <?php if (!empty($filters['category'])): ?>
                    <span>/</span>
                    <span class="text-foreground font-bold"><?= e($filters['category']) ?></span>
                <?php endif ?>
            </nav>
            <h1 class="text-3xl sm:text-4xl font-extrabold text-foreground m-0 tracking-tight font-display">
                <?php if (!empty($filters['category'])): ?>
                    The <?= e($filters['category']) ?> Edit
                <?php elseif ($search): ?>
                    Results for &ldquo;<?= e($search) ?>&rdquo;
                <?php else: ?>
                    The Atelier Catalog
                <?php endif ?>
            </h1>
            <p class="text-xs text-muted-foreground m-0 mt-1.5">
                Displaying <strong><?= count($products) ?></strong> handcrafted garments & accessories
            </p>
        </div>

        <!-- Sorting & Mobile Filter trigger -->
        <div class="flex items-center gap-3">
            <button type="button" id="openMobileFiltersBtn" class="btn-lux btn-lux-outline btn-lux-sm md:hidden flex items-center gap-2">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/></svg>
                <span>Filters</span>
                <?php if (!empty($activeCats) || !empty($activeBrands)): ?>
                    <span class="badge badge-default text-[10px] px-1.5 py-0"><?= count($activeCats) + count($activeBrands) ?></span>
                <?php endif ?>
            </button>

            <!-- Custom Sort Capsule -->
            <div class="flex items-center gap-2 bg-white px-3 py-1.5 rounded-full border border-border shadow-sm">
                <label for="sortSelect" class="text-xs text-muted-foreground font-semibold hidden sm:inline">Sort:</label>
                <select id="sortSelect" class="text-xs font-bold bg-transparent border-0 outline-none cursor-pointer text-foreground pr-2">
                    <option value="price-lowtohigh" <?= $sortBy==='price-lowtohigh' ? 'selected':''?>>Price: Low to High</option>
                    <option value="price-hightolow" <?= $sortBy==='price-hightolow' ? 'selected':''?>>Price: High to Low</option>
                    <option value="title-atoz"      <?= $sortBy==='title-atoz'      ? 'selected':''?>>Alphabetical: A to Z</option>
                    <option value="title-ztoa"      <?= $sortBy==='title-ztoa'      ? 'selected':''?>>Alphabetical: Z to A</option>
                </select>
            </div>
        </div>
    </div>

    <!-- Active Filter Tags (if any) -->
    <?php if (!empty($activeCats) || !empty($activeBrands) || !empty($search)): ?>
        <div class="flex flex-wrap items-center gap-2 p-3 bg-white rounded-2xl border border-border shadow-sm">
            <span class="text-xs font-bold text-muted-foreground uppercase tracking-wider pl-1">Filters:</span>
            <?php foreach ($activeCats as $c): ?>
                <span class="badge badge-outline bg-slate-50 flex items-center gap-1.5 text-xs py-1 px-3 rounded-full border-border">
                    <span>Category: <strong><?= e($c) ?></strong></span>
                    <button type="button" class="text-muted-foreground hover:text-destructive font-bold ml-1 cursor-pointer" onclick="removeFilter('category', '<?= e($c) ?>')">&times;</button>
                </span>
            <?php endforeach ?>
            <?php foreach ($activeBrands as $b): ?>
                <span class="badge badge-outline bg-slate-50 flex items-center gap-1.5 text-xs py-1 px-3 rounded-full border-border">
                    <span>Brand: <strong><?= e($b) ?></strong></span>
                    <button type="button" class="text-muted-foreground hover:text-destructive font-bold ml-1 cursor-pointer" onclick="removeFilter('brand', '<?= e($b) ?>')">&times;</button>
                </span>
            <?php endforeach ?>
            <?php if (!empty($search)): ?>
                <span class="badge badge-outline bg-slate-50 flex items-center gap-1.5 text-xs py-1 px-3 rounded-full border-border">
                    <span>Search: <strong><?= e($search) ?></strong></span>
                    <button type="button" class="text-muted-foreground hover:text-destructive font-bold ml-1 cursor-pointer" onclick="removeFilter('search', '')">&times;</button>
                </span>
            <?php endif ?>
            <button type="button" id="clearAllFiltersBtn" class="text-xs font-bold text-amber-800 hover:underline ml-2">
                Reset All
            </button>
        </div>
    <?php endif ?>

    <!-- Catalog Main 2-Column Layout -->
    <div class="grid grid-cols-1 md:grid-cols-[16rem_1fr] lg:grid-cols-[18rem_1fr] gap-8 items-start">
        <!-- Desktop Sticky Filter Sidebar -->
        <aside class="hidden md:block sticky top-28 space-y-6 bg-white border border-border p-6 rounded-3xl shadow-sm">
            <div class="flex items-center justify-between pb-3 border-b border-border">
                <h3 class="font-bold text-xs uppercase tracking-widest text-foreground m-0">Refine Catalog</h3>
                <button type="button" class="text-xs font-bold text-muted-foreground hover:text-foreground" onclick="clearFilters()">Reset</button>
            </div>

            <!-- Category Filter List -->
            <div class="space-y-3">
                <h4 class="text-xs font-extrabold text-foreground uppercase tracking-wider m-0">Department</h4>
                <div class="space-y-2 max-h-56 overflow-y-auto pr-1">
                    <?php foreach ($categories as $c): $checked = in_array($c, $activeCats, true); ?>
                        <label class="flex items-center justify-between text-xs font-semibold text-charcoal cursor-pointer hover:text-black py-0.5">
                            <span class="flex items-center gap-2.5">
                                <input type="checkbox" class="filter-cat w-4 h-4 rounded text-black focus:ring-0" value="<?= e($c) ?>" <?= $checked ? 'checked':'' ?>/>
                                <span><?= e($c) ?></span>
                            </span>
                        </label>
                    <?php endforeach ?>
                </div>
            </div>

            <!-- Brand Filter List -->
            <div class="pt-4 border-t border-border space-y-3">
                <h4 class="text-xs font-extrabold text-foreground uppercase tracking-wider m-0">Brand Atelier</h4>
                <div class="space-y-2 max-h-56 overflow-y-auto pr-1">
                    <?php foreach ($brands as $b): $checked = in_array($b, $activeBrands, true); ?>
                        <label class="flex items-center justify-between text-xs font-semibold text-charcoal cursor-pointer hover:text-black py-0.5">
                            <span class="flex items-center gap-2.5">
                                <input type="checkbox" class="filter-brand w-4 h-4 rounded text-black focus:ring-0" value="<?= e($b) ?>" <?= $checked ? 'checked':'' ?>/>
                                <span><?= e($b) ?></span>
                            </span>
                        </label>
                    <?php endforeach ?>
                </div>
            </div>

            <!-- Quick Service Perks Banner -->
            <div class="pt-4 border-t border-border">
                <div class="p-3.5 rounded-2xl bg-slate-50 border border-border/80 space-y-1.5 text-[11px] text-muted-foreground">
                    <p class="font-bold text-foreground m-0">✨ Atelier Assurance</p>
                    <p class="m-0 leading-relaxed">Free delivery on ₹1,000+ orders. Complimentary 7-day doorstep exchange.</p>
                </div>
            </div>
        </aside>

        <!-- Product Catalog Grid -->
        <section class="space-y-6">
            <?php if (empty($products)): ?>
                <div class="card p-16 text-center rounded-3xl border border-dashed border-border bg-white max-w-lg mx-auto">
                    <div class="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4 text-3xl">
                        🔍
                    </div>
                    <h3 class="text-xl font-bold text-foreground m-0">No Garments Found</h3>
                    <p class="text-xs text-muted-foreground mt-2 mb-6 leading-relaxed">
                        No products match your selected filters. Try loosening your department or brand criteria.
                    </p>
                    <button type="button" onclick="clearFilters()" class="btn-lux btn-lux-primary btn-lux-sm">
                        Clear Filters & View All
                    </button>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6" id="productsCatalogGrid">
                    <?php foreach ($products as $p):
                        $price = getDisplayPrice($p);
                        $origPrice = (float)$p['price'];
                        $discount = $origPrice > 0 && $price < $origPrice ? round((1 - $price / $origPrice) * 100) : 0;
                        $isWish = in_array((int)$p['id'], $userWishlistIds, true);
                    ?>
                        <div class="card-product-lux group">
                            <!-- Image Container -->
                            <div class="product-media-wrap" onclick="location.href='<?= base_url('/shop/product/' . (int)$p['id']) ?>'">
                                <img src="<?= e(product_image_url($p['image'])) ?>" alt="<?= e($p['title']) ?>"
                                     onerror="this.onerror=null;this.src='<?= e(product_image_url('')) ?>';"
                                     class="product-media-img" loading="lazy"/>

                                <!-- Badges -->
                                <div class="badge-floating-corner">
                                    <?php if ($discount > 0): ?>
                                        <span class="badge-lux-sale">-<?= $discount ?>%</span>
                                    <?php endif ?>
                                    <?php if (!empty($p['brand'])): ?>
                                        <span class="badge-lux-new"><?= e($p['brand']) ?></span>
                                    <?php endif ?>
                                </div>

                                <!-- Sold out scrim -->
                                <?php if (!$p['totalStock']): ?>
                                    <div class="stock-scrim">
                                        <span class="stock-scrim-pill">SOLD OUT</span>
                                    </div>
                                <?php endif ?>

                                <!-- Wishlist Button -->
                                <button type="button" class="btn-wishlist-float <?= $isWish ? 'wishlisted' : '' ?>"
                                        data-wishlist-toggle="<?= (int)$p['id'] ?>" title="Save to wishlist" aria-label="Wishlist"
                                        onclick="event.stopPropagation()">
                                    <svg width="17" height="17" viewBox="0 0 24 24" fill="<?= $isWish ? '#be123c' : 'none' ?>" stroke="<?= $isWish ? '#be123c' : 'currentColor' ?>" stroke-width="2">
                                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                                    </svg>
                                </button>

                                <!-- Slide-Up Quick Actions -->
                                <div class="product-quick-actions" onclick="event.stopPropagation()">
                                    <button type="button" class="btn-quick-view" onclick="openDetails(<?= (int)$p['id'] ?>)">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                                        <span>Quick Look</span>
                                    </button>
                                    <button type="button" class="btn-quick-add" onclick="addToCartFromTile(<?= (int)$p['id'] ?>)"
                                            <?= !$p['totalStock'] ? 'disabled' : '' ?> title="Add to bag" aria-label="Add to bag">
                                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
                                    </button>
                                </div>
                            </div>

                            <!-- Content -->
                            <div class="product-info-wrap">
                                <div>
                                    <p class="product-brand-tag"><?= e($p['category'] ?? 'Atelier') ?></p>
                                    <h3 class="product-title-lux">
                                        <a href="<?= base_url('/shop/product/' . (int)$p['id']) ?>"><?= e($p['title']) ?></a>
                                    </h3>
                                    <div class="product-meta-row">
                                        <?= renderStars($p['averageReview'], 12) ?>
                                        <span class="product-reviews-count">(<?= round((float)$p['averageReview'], 1) ?>)</span>
                                    </div>
                                </div>

                                <div class="product-price-row">
                                    <div>
                                        <span class="price-current-lux"><?= formatCurrency($price) ?></span>
                                        <?php if ($origPrice > $price): ?>
                                            <span class="price-original-lux"><?= formatCurrency($origPrice) ?></span>
                                        <?php endif ?>
                                    </div>
                                    <span class="text-[11px] font-bold <?= $p['totalStock'] > 0 ? 'text-emerald-700' : 'text-rose-600' ?>">
                                        <?= $p['totalStock'] > 0 ? 'In Stock' : 'Sold Out' ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach ?>
                </div>
            <?php endif ?>
        </section>
    </div>
</div>

<!-- Mobile Filter Drawer Modal -->
<div id="mobileFilterBackdrop" class="dialog-overlay hidden">
    <div class="dialog max-w-sm w-full rounded-3xl bg-white overflow-hidden shadow-2xl animate-fade-in-scale">
        <div class="p-5 border-b border-border flex items-center justify-between">
            <h3 class="font-bold text-sm uppercase tracking-wider m-0">Refine Catalog</h3>
            <button type="button" id="closeMobileFiltersBtn" class="btn btn-ghost btn-icon rounded-full">&times;</button>
        </div>
        <div class="p-5 space-y-6 max-h-[68vh] overflow-y-auto">
            <div>
                <h4 class="text-xs font-extrabold uppercase tracking-wider mb-2.5">Departments</h4>
                <div class="space-y-2">
                    <?php foreach ($categories as $c): $checked = in_array($c, $activeCats, true); ?>
                        <label class="flex items-center gap-2.5 text-xs font-semibold cursor-pointer">
                            <input type="checkbox" class="mob-filter-cat w-4 h-4 rounded text-black" value="<?= e($c) ?>" <?= $checked ? 'checked':'' ?>/>
                            <span><?= e($c) ?></span>
                        </label>
                    <?php endforeach ?>
                </div>
            </div>
            <div class="pt-4 border-t border-border">
                <h4 class="text-xs font-extrabold uppercase tracking-wider mb-2.5">Brands</h4>
                <div class="space-y-2">
                    <?php foreach ($brands as $b): $checked = in_array($b, $activeBrands, true); ?>
                        <label class="flex items-center gap-2.5 text-xs font-semibold cursor-pointer">
                            <input type="checkbox" class="mob-filter-brand w-4 h-4 rounded text-black" value="<?= e($b) ?>" <?= $checked ? 'checked':'' ?>/>
                            <span><?= e($b) ?></span>
                        </label>
                    <?php endforeach ?>
                </div>
            </div>
        </div>
        <div class="p-4 border-t border-border bg-slate-50 flex gap-2">
            <button type="button" onclick="clearFilters()" class="btn-lux btn-lux-outline flex-1 text-xs">Reset</button>
            <button type="button" onclick="applyMobileFilters()" class="btn-lux btn-lux-primary flex-1 text-xs">Apply</button>
        </div>
    </div>
</div>

<script>
const __userId = '<?= $user ? (int)$user['id'] : '' ?>';

function applyFilters() {
    const params = new URLSearchParams();
    const cats = Array.from(document.querySelectorAll('.filter-cat:checked')).map(c => c.value);
    const brs  = Array.from(document.querySelectorAll('.filter-brand:checked')).map(b => b.value);
    if (cats.length) params.set('category', cats.join(','));
    if (brs.length)  params.set('brand', brs.join(','));
    params.set('sortBy', document.getElementById('sortSelect').value);
    if ('<?= e($search) ?>') params.set('q', '<?= e($search) ?>');
    window.location.search = params.toString();
}

function applyMobileFilters() {
    const params = new URLSearchParams();
    const cats = Array.from(document.querySelectorAll('.mob-filter-cat:checked')).map(c => c.value);
    const brs  = Array.from(document.querySelectorAll('.mob-filter-brand:checked')).map(b => b.value);
    if (cats.length) params.set('category', cats.join(','));
    if (brs.length)  params.set('brand', brs.join(','));
    params.set('sortBy', document.getElementById('sortSelect').value);
    if ('<?= e($search) ?>') params.set('q', '<?= e($search) ?>');
    window.location.search = params.toString();
}

function clearFilters() {
    window.location.href = (window.APP_BASE || '') + '/shop/listing';
}

function removeFilter(type, value) {
    const params = new URLSearchParams(window.location.search);
    if (type === 'category') {
        const cats = (params.get('category') || '').split(',').filter(x => x && x !== value);
        if (cats.length) params.set('category', cats.join(','));
        else params.delete('category');
    } else if (type === 'brand') {
        const brs = (params.get('brand') || '').split(',').filter(x => x && x !== value);
        if (brs.length) params.set('brand', brs.join(','));
        else params.delete('brand');
    } else if (type === 'search') {
        params.delete('q');
        params.delete('search');
    }
    window.location.search = params.toString();
}

document.getElementById('sortSelect')?.addEventListener('change', applyFilters);
document.querySelectorAll('.filter-cat, .filter-brand').forEach(el => el.addEventListener('change', applyFilters));
document.getElementById('clearAllFiltersBtn')?.addEventListener('click', clearFilters);

document.getElementById('openMobileFiltersBtn')?.addEventListener('click', () => {
    document.getElementById('mobileFilterBackdrop')?.classList.remove('hidden');
});
document.getElementById('closeMobileFiltersBtn')?.addEventListener('click', () => {
    document.getElementById('mobileFilterBackdrop')?.classList.add('hidden');
});

async function addToCartFromTile(productId) {
    if (!__userId) {
        toast('Sign In Required', 'Please sign in to add items to your shopping bag', 'info');
        setTimeout(() => window.location.href = (window.APP_BASE || '') + '/auth/login', 1200);
        return;
    }
    try {
        await CartApi.add(__userId, productId, 1);
        toast('Added to Bag', 'Item added to your shopping bag!', 'success');
    } catch(e) {}
}

function openDetails(id) {
    const params = new URLSearchParams(location.search);
    params.set('highlight', id);
    history.replaceState(null, '', location.pathname + '?' + params.toString());
    fetchProductDetails(id);
}

function closeDetails() {
    document.getElementById('productDialog').classList.add('hidden');
    const params = new URLSearchParams(location.search);
    params.delete('highlight');
    const s = params.toString();
    history.replaceState(null, '', location.pathname + (s ? '?' + s : ''));
}
document.getElementById('pdClose')?.addEventListener('click', closeDetails);

async function fetchProductDetails(id) {
    try {
        const [p, reviews] = await Promise.all([ProductApi.one(id), ReviewApi.get(id)]);
        renderDetails(p.data, reviews.data || []);
        document.getElementById('productDialog').classList.remove('hidden');
    } catch(e) {}
}

function renderDetails(p, reviews) {
    const price = Number(p.salePrice || 0) > 0 ? Number(p.salePrice) : Number(p.price || 0);
    const origPrice = Number(p.price || 0);
    const discount = origPrice > price ? Math.round((1 - price / origPrice) * 100) : 0;
    const isWish = <?= json_encode($userWishlistIds) ?>.includes(Number(p.id));
    const _base = window.APP_BASE || '';

    document.getElementById('pdTitle').textContent = p.title || 'Product Details';
    document.getElementById('pdBody').innerHTML = `
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
            <div class="aspect-[4/5] bg-slate-100 rounded-3xl overflow-hidden border border-border">
                <img src="${formatImageUrl(p.image)}" alt="${_esc(p.title)}" onerror="this.onerror=null;this.src=formatImageUrl('');" class="w-full h-full object-cover"/>
            </div>
            <div class="space-y-4">
                <div>
                    <span class="text-[10px] uppercase font-bold tracking-widest text-muted-foreground">${_esc(p.brand || 'ClothShop Atelier')}</span>
                    <h2 class="text-xl sm:text-2xl font-bold text-foreground leading-snug m-0 mt-1">${_esc(p.title || '')}</h2>

                    <div class="flex items-center gap-2 mt-2">
                        ${renderStars(p.averageReview, 14)}
                        <span class="text-xs text-muted-foreground font-semibold">(${Number(p.averageReview || 0).toFixed(1)} / 5.0 • ${reviews.length} reviews)</span>
                    </div>
                </div>

                <div class="p-3.5 bg-slate-50 rounded-2xl border border-border flex items-baseline gap-3">
                    <span class="text-2xl font-black text-foreground">${formatCurrency(price)}</span>
                    ${origPrice > price ? `
                        <span class="text-sm text-muted-foreground line-through">${formatCurrency(origPrice)}</span>
                        <span class="badge badge-destructive font-bold text-xs">-${discount}% OFF</span>
                    ` : ''}
                </div>

                <p class="text-xs text-muted-foreground leading-relaxed m-0">
                    ${_esc(p.description || 'Crafted with premium materials engineered for longevity, breathability, and everyday elegance.')}
                </p>

                <!-- Sizes -->
                <div>
                    <label class="text-xs font-bold text-foreground uppercase tracking-wider block mb-2">Select Size</label>
                    <div class="flex gap-2">
                        ${['S', 'M', 'L', 'XL', 'XXL'].map((sz, idx) => `
                            <button type="button" class="size-pill-lux ${idx === 1 ? 'active' : ''}" onclick="this.parentElement.querySelectorAll('.size-pill-lux').forEach(b => b.classList.remove('active')); this.classList.add('active');">
                                ${sz}
                            </button>
                        `).join('')}
                    </div>
                </div>

                <!-- Quantity & Add To Bag -->
                <div class="pt-2 flex items-center gap-3">
                    <div class="qty-stepper-lux">
                        <button type="button" class="qty-stepper-btn" onclick="adjustPdQty(-1)">-</button>
                        <input id="pdQty" type="number" min="1" max="${p.totalStock || 1}" value="1" readonly class="qty-stepper-val bg-transparent border-0 outline-none text-xs font-bold" style="width:36px;"/>
                        <button type="button" class="qty-stepper-btn" onclick="adjustPdQty(1)">+</button>
                    </div>

                    <button id="pdAddBtn" type="button" class="btn-lux btn-lux-primary flex-1"
                            onclick="addPdToCart(${p.id})" ${!p.totalStock ? 'disabled' : ''}>
                        Add to Shopping Bag
                    </button>
                </div>

                <div class="grid grid-cols-2 gap-3 pt-2">
                    <button type="button" class="btn-lux btn-lux-outline text-xs font-bold" onclick="buyNowFromDialog(${p.id})" ${!p.totalStock ? 'disabled' : ''}>
                        ⚡ Instant Buy Now
                    </button>
                    <a href="${_base}/shop/product/${p.id}" class="btn-lux btn-lux-ghost text-xs font-bold text-center">
                        View Full Page &rarr;
                    </a>
                </div>
            </div>
        </div>
    `;
}

function adjustPdQty(delta) {
    const el = document.getElementById('pdQty');
    if (!el) return;
    const max = parseInt(el.max || '10');
    let val = parseInt(el.value || '1') + delta;
    if (val < 1) val = 1;
    if (val > max) val = max;
    el.value = val;
}

async function addPdToCart(productId) {
    if (!__userId) {
        toast('Sign In Required', 'Please sign in to add items to your shopping bag', 'info');
        setTimeout(() => window.location.href = (window.APP_BASE || '') + '/auth/login', 1200);
        return;
    }
    const qty = parseInt(document.getElementById('pdQty')?.value || '1');
    const btn = document.getElementById('pdAddBtn');
    if (btn) { btn.disabled = true; btn.textContent = 'Adding...'; }
    try {
        await CartApi.add(__userId, productId, qty);
        toast('Added to Bag', 'Item successfully added to your shopping bag!', 'success');
        closeDetails();
    } catch(e) {
        if (btn) { btn.disabled = false; btn.textContent = 'Add to Shopping Bag'; }
    }
}

async function buyNowFromDialog(productId) {
    if (!__userId) {
        toast('Sign In Required', 'Please sign in to proceed with checkout', 'info');
        setTimeout(() => window.location.href = (window.APP_BASE || '') + '/auth/login', 1200);
        return;
    }
    const qty = parseInt(document.getElementById('pdQty')?.value || '1');
    try {
        await CartApi.add(__userId, productId, qty, { silent: true });
        window.location.href = (window.APP_BASE || '') + '/shop/checkout';
    } catch(e) {}
}

<?php if ($highlight): ?>
document.addEventListener('DOMContentLoaded', () => fetchProductDetails(<?= (int)$highlight ?>));
<?php endif ?>
</script>

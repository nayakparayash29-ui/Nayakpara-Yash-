<?php
/**
 * Shop Home Page
 * Luxury fashion homepage with editorial hero carousel, curated category showcase,
 * trending spotlight, split lookbook banners, new arrivals, and instant cart/wishlist actions.
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'home';

require_once __DIR__ . '/../../models/Product.php';
require_once __DIR__ . '/../../models/Feature.php';
require_once __DIR__ . '/../../models/Wishlist.php';

$pm = new ProductModel();
$fm = new FeatureModel();
$wm = new WishlistModel();

$banners  = $fm->findAll();
$featured = $pm->findAll([], 'price-lowtohigh');
$trending = array_slice($featured, 0, 8);
$newArrivals = array_slice($featured, 0, 10);
$categories = $pm->getDistinctCategories();

$user = currentUser();
$userWishlistIds = $user ? $wm->getProductIdsByUser($user['id']) : [];
?>
<div class="space-y-16 pb-12">
    <!-- Hero Banner Carousel Section -->
    <section class="container pt-4">
        <div class="hero-stage-lux">
            <!-- Slide 1: Main Editorial Showcase -->
            <div class="hero-slide-lux active" data-slide-index="0">
                <div class="hero-content-lux">
                    <div class="hero-tagline-pill">
                        <span>✨ Autumn / Winter 2026 Collection</span>
                    </div>
                    <h1 class="hero-heading-lux">
                        The Art of <span class="highlight-serif">Modern Tailoring</span> & Form
                    </h1>
                    <p class="hero-description-lux">
                        Discover thoughtfully crafted silhouettes for Men, Women & Kids. Premium fabrics, architectural cuts, and timeless everyday elegance.
                    </p>
                    <div class="hero-actions-lux">
                        <a href="<?= base_url('/shop/listing') ?>" class="btn-lux btn-lux-white btn-lux-lg">
                            Explore The Collection &rarr;
                        </a>
                        <a href="<?= base_url('/shop/listing') ?>?category=Women" class="btn-lux btn-lux-outline btn-lux-lg text-white border-white/30 hover:bg-white/10">
                            Women's Studio
                        </a>
                    </div>
                </div>
                <div class="hero-slide-bg">
                    <?php 
                    $b1 = !empty($banners[0]['image']) ? product_image_url($banners[0]['image']) : 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1600&q=80';
                    ?>
                    <img src="<?= e($b1) ?>" alt="Editorial Fashion Collection" loading="eager"/>
                    <div class="hero-slide-scrim"></div>
                </div>
            </div>

            <!-- Slide 2: Seasonal Markdowns / Flash Sale -->
            <div class="hero-slide-lux" data-slide-index="1">
                <div class="hero-content-lux">
                    <div class="hero-tagline-pill" style="color: #67e8f9; background: rgba(6,182,212,0.15);">
                        <span>🔥 Seasonal Archive Drop</span>
                    </div>
                    <h2 class="hero-heading-lux">
                        Up to <span class="highlight-serif" style="color:#67e8f9;">50% Off</span> Curated Staples
                    </h2>
                    <p class="hero-description-lux">
                        Limited seasonal markdowns across tailored shirts, fluid dresses, selvedge denim, and contemporary streetwear sneakers.
                    </p>
                    <div class="hero-actions-lux">
                        <a href="<?= base_url('/shop/listing') ?>" class="btn-lux btn-lux-white btn-lux-lg">
                            Shop The Private Sale &rarr;
                        </a>
                        <a href="<?= base_url('/shop/listing') ?>?category=Men" class="btn-lux btn-lux-outline btn-lux-lg text-white border-white/30 hover:bg-white/10">
                            Men's Tailoring
                        </a>
                    </div>
                </div>
                <div class="hero-slide-bg">
                    <?php 
                    $b2 = !empty($banners[1]['image']) ? product_image_url($banners[1]['image']) : 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1600&q=80';
                    ?>
                    <img src="<?= e($b2) ?>" alt="Seasonal Fashion Sale" loading="lazy"/>
                    <div class="hero-slide-scrim"></div>
                </div>
            </div>

            <!-- Slide 3: Contemporary Footwear & Essentials -->
            <div class="hero-slide-lux" data-slide-index="2">
                <div class="hero-content-lux">
                    <div class="hero-tagline-pill" style="color: #fed7aa; background: rgba(249,115,22,0.15);">
                        <span>👟 Footwear & Essentials</span>
                    </div>
                    <h2 class="hero-heading-lux">
                        Urban Comfort Meets <span class="highlight-serif" style="color:#fed7aa;">Streetwear</span>
                    </h2>
                    <p class="hero-description-lux">
                        Engineered comfort sneakers, handcrafted leather loafers, and statement accessories for the discerning wardrobe.
                    </p>
                    <div class="hero-actions-lux">
                        <a href="<?= base_url('/shop/listing') ?>?category=Footwear" class="btn-lux btn-lux-white btn-lux-lg">
                            Shop Footwear &rarr;
                        </a>
                    </div>
                </div>
                <div class="hero-slide-bg">
                    <img src="https://images.unsplash.com/photo-1552346154-21d32810aba3?w=1600&q=80" alt="Contemporary Footwear" loading="lazy"/>
                    <div class="hero-slide-scrim"></div>
                </div>
            </div>

            <!-- Carousel Controls -->
            <div class="hero-nav-dots">
                <button type="button" class="hero-nav-arrow" id="prevHeroSlide" aria-label="Previous Slide">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
                </button>
                <div class="flex items-center gap-2 mx-1" id="heroDotsWrap">
                    <button type="button" class="hero-dot active" data-slide-target="0" aria-label="Slide 1"></button>
                    <button type="button" class="hero-dot" data-slide-target="1" aria-label="Slide 2"></button>
                    <button type="button" class="hero-dot" data-slide-target="2" aria-label="Slide 3"></button>
                </div>
                <button type="button" class="hero-nav-arrow" id="nextHeroSlide" aria-label="Next Slide">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
                </button>
            </div>
        </div>
    </section>

    <!-- Value Propositions Strip -->
    <section class="container">
        <div class="props-strip">
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-6">
                <div class="prop-item">
                    <div class="prop-icon-wrap">🚚</div>
                    <div>
                        <h4 class="prop-title">Express Pan-India Delivery</h4>
                        <p class="prop-sub">Complimentary over ₹1,000 orders</p>
                    </div>
                </div>
                <div class="prop-item">
                    <div class="prop-icon-wrap">🔄</div>
                    <div>
                        <h4 class="prop-title">7-Day Concierge Exchange</h4>
                        <p class="prop-sub">Hassle-free doorstep pickup</p>
                    </div>
                </div>
                <div class="prop-item">
                    <div class="prop-icon-wrap">✨</div>
                    <div>
                        <h4 class="prop-title">100% Guaranteed Quality</h4>
                        <p class="prop-sub">Hand-inspected archival materials</p>
                    </div>
                </div>
                <div class="prop-item">
                    <div class="prop-icon-wrap">🛡️</div>
                    <div>
                        <h4 class="prop-title">Bank-Grade Security</h4>
                        <p class="prop-sub">Card, UPI, and cash on delivery checkout</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Curated Categories Showcase -->
    <section class="container">
        <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-8">
            <div>
                <span class="text-xs uppercase tracking-widest font-extrabold text-amber-700 block mb-1">Curated Departments</span>
                <h2 class="text-2xl sm:text-3xl font-extrabold tracking-tight text-foreground m-0">Explore By Category</h2>
            </div>
            <a href="<?= base_url('/shop/listing') ?>" class="text-xs uppercase tracking-wider font-bold text-foreground hover:text-amber-700 transition flex items-center gap-1.5">
                <span>View Full Catalog</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
            </a>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            <?php
            $catCovers = [
                'Men' => ['title' => 'Men\'s Tailoring', 'img' => 'https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?w=600&q=80'],
                'Women' => ['title' => 'Women\'s Studio', 'img' => 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&q=80'],
                'Kids' => ['title' => 'Kids & Youth', 'img' => 'https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=600&q=80'],
                'Footwear' => ['title' => 'Footwear & Sneaker', 'img' => 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80'],
                'Accessories' => ['title' => 'Accessories Edit', 'img' => 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&q=80'],
                'Unisex' => ['title' => 'Casual Essentials', 'img' => 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=600&q=80'],
            ];
            $displayCats = !empty($categories) ? $categories : ['Men', 'Women', 'Kids', 'Footwear', 'Accessories', 'Unisex'];
            foreach ($displayCats as $cat):
                $meta = $catCovers[$cat] ?? ['title' => $cat, 'img' => 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=600&q=80'];
            ?>
                <a href="<?= base_url('/shop/listing?category=' . urlencode($cat)) ?>" class="card-category-lux group">
                    <div class="card-category-bg">
                        <img src="<?= e($meta['img']) ?>" alt="<?= e($cat) ?>" loading="lazy"/>
                    </div>
                    <div class="card-category-gradient"></div>
                    <div class="card-category-content">
                        <span class="text-[10px] uppercase font-bold tracking-widest text-amber-300 block mb-1">Collection</span>
                        <h3 class="category-title-lux text-base sm:text-lg"><?= e($cat) ?></h3>
                        <span class="category-action-link">
                            Explore &rarr;
                        </span>
                    </div>
                </a>
            <?php endforeach ?>
        </div>
    </section>

    <!-- Trending Products Spotlight -->
    <section class="container">
        <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-8">
            <div>
                <span class="text-xs uppercase tracking-widest font-extrabold text-rose-600 block mb-1">Curated By Directors</span>
                <h2 class="text-2xl sm:text-3xl font-extrabold tracking-tight text-foreground m-0">Trending Spotlight</h2>
            </div>
            <a href="<?= base_url('/shop/listing') ?>" class="text-xs uppercase tracking-wider font-bold text-foreground hover:text-amber-700 transition flex items-center gap-1.5">
                <span>See All Trending</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
            </a>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6" id="trendingGrid">
            <?php foreach ($trending as $p):
                $price = getDisplayPrice($p);
                $origPrice = (float)$p['price'];
                $discount = $origPrice > 0 && $price < $origPrice ? round((1 - $price / $origPrice) * 100) : 0;
                $isWish = in_array((int)$p['id'], $userWishlistIds, true);
            ?>
                <div class="card-product-lux group">
                    <!-- Media Area -->
                    <div class="product-media-wrap" onclick="location.href='<?= base_url('/shop/product/' . (int)$p['id']) ?>'">
                        <img src="<?= e(product_image_url($p['image'])) ?>" alt="<?= e($p['title']) ?>"
                             onerror="this.onerror=null;this.src='<?= e(product_image_url('')) ?>';"
                             class="product-media-img" loading="lazy"/>

                        <!-- Floating Badges -->
                        <div class="badge-floating-corner">
                            <?php if ($discount > 0): ?>
                                <span class="badge-lux-sale">-<?= $discount ?>%</span>
                            <?php endif ?>
                            <?php if (!empty($p['brand'])): ?>
                                <span class="badge-lux-new"><?= e($p['brand']) ?></span>
                            <?php endif ?>
                        </div>

                        <!-- Out of Stock Scrim -->
                        <?php if (!$p['totalStock']): ?>
                            <div class="stock-scrim">
                                <span class="stock-scrim-pill">SOLD OUT</span>
                            </div>
                        <?php endif ?>

                        <!-- Wishlist Toggle -->
                        <button type="button" class="btn-wishlist-float <?= $isWish ? 'wishlisted' : '' ?>"
                                data-wishlist-toggle="<?= (int)$p['id'] ?>" title="Save to wishlist" aria-label="Wishlist"
                                onclick="event.stopPropagation()">
                            <svg width="17" height="17" viewBox="0 0 24 24" fill="<?= $isWish ? '#be123c' : 'none' ?>" stroke="<?= $isWish ? '#be123c' : 'currentColor' ?>" stroke-width="2">
                                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                            </svg>
                        </button>

                        <!-- Slide-Up Quick Action Overlay -->
                        <div class="product-quick-actions" onclick="event.stopPropagation()">
                            <button type="button" class="btn-quick-view" onclick="openGlobalQuickView(<?= (int)$p['id'] ?>)">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                                <span>Quick Look</span>
                            </button>
                            <button type="button" class="btn-quick-add" onclick="quickAddToCart(<?= (int)$p['id'] ?>)"
                                    <?= !$p['totalStock'] ? 'disabled' : '' ?> title="Add to bag" aria-label="Add to bag">
                                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
                            </button>
                        </div>
                    </div>

                    <!-- Details Area -->
                    <div class="product-info-wrap">
                        <div>
                            <p class="product-brand-tag"><?= e($p['category'] ?? 'Atelier') ?></p>
                            <h3 class="product-title-lux">
                                <a href="<?= base_url('/shop/product/' . (int)$p['id']) ?>"><?= e($p['title']) ?></a>
                            </h3>
                            <div class="product-meta-row">
                                <?= renderStars($p['averageReview'], 12) ?>
                                <span class="product-reviews-count">(<?= round((float)$p['averageReview'], 1) ?>)</span>
                            </div>
                        </div>

                        <div class="product-price-row">
                            <div>
                                <span class="price-current-lux"><?= formatCurrency($price) ?></span>
                                <?php if ($origPrice > $price): ?>
                                    <span class="price-original-lux"><?= formatCurrency($origPrice) ?></span>
                                <?php endif ?>
                            </div>
                            <span class="text-[11px] font-bold <?= $p['totalStock'] > 0 ? 'text-emerald-700' : 'text-rose-600' ?>">
                                <?= $p['totalStock'] > 0 ? 'In Stock' : 'Sold Out' ?>
                            </span>
                        </div>
                    </div>
                </div>
            <?php endforeach ?>
        </div>
    </section>

    <!-- Split Editorial Lookbook Banners -->
    <section class="container">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Left Lookbook Banner: Men's Tailoring -->
            <div class="rounded-3xl p-8 sm:p-12 relative overflow-hidden text-white flex flex-col justify-between min-h-[320px] shadow-lg border border-slate-800"
                 style="background: linear-gradient(135deg, #0b0f19 0%, #1e1b4b 100%);">
                <div class="relative z-10 max-w-sm space-y-3">
                    <span class="inline-block px-3 py-1 rounded-full bg-amber-400 text-slate-950 font-bold text-[10px] uppercase tracking-widest">
                        The Men's Archive
                    </span>
                    <h3 class="font-display text-2xl sm:text-3xl font-extrabold m-0 leading-tight">
                        Crisp Tailoring & Everyday Silhouettes
                    </h3>
                    <p class="text-slate-300 text-xs sm:text-sm leading-relaxed m-0">
                        Cotton twill overshirts, structured blazers, relaxed chinos, and archival outerwear designed with precision.
                    </p>
                </div>
                <div class="relative z-10 pt-6">
                    <a href="<?= base_url('/shop/listing') ?>?category=Men" class="btn-lux btn-lux-white btn-lux-sm">
                        Shop Men's Edit &rarr;
                    </a>
                </div>
                <div class="absolute -right-8 -bottom-8 w-56 h-56 rounded-full bg-indigo-500/20 blur-3xl"></div>
            </div>

            <!-- Right Lookbook Banner: Women's Studio -->
            <div class="rounded-3xl p-8 sm:p-12 relative overflow-hidden text-white flex flex-col justify-between min-h-[320px] shadow-lg border border-rose-950"
                 style="background: linear-gradient(135deg, #2a0815 0%, #831843 100%);">
                <div class="relative z-10 max-w-sm space-y-3">
                    <span class="inline-block px-3 py-1 rounded-full bg-pink-300 text-slate-950 font-bold text-[10px] uppercase tracking-widest">
                        The Women's Studio
                    </span>
                    <h3 class="font-display text-2xl sm:text-3xl font-extrabold m-0 leading-tight">
                        Fluid Elegance & Statement Silhouettes
                    </h3>
                    <p class="text-pink-100 text-xs sm:text-sm leading-relaxed m-0">
                        Effortless dresses, breathable linen tops, artisanal ethnic wear, and modern layering essentials.
                    </p>
                </div>
                <div class="relative z-10 pt-6">
                    <a href="<?= base_url('/shop/listing') ?>?category=Women" class="btn-lux btn-lux-white btn-lux-sm">
                        Explore Women's Studio &rarr;
                    </a>
                </div>
                <div class="absolute -right-8 -bottom-8 w-56 h-56 rounded-full bg-pink-500/20 blur-3xl"></div>
            </div>
        </div>
    </section>

    <!-- Fresh Arrivals Showcase -->
    <section class="container">
        <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-8">
            <div>
                <span class="text-xs uppercase tracking-widest font-extrabold text-emerald-700 block mb-1">Just Dropped</span>
                <h2 class="text-2xl sm:text-3xl font-extrabold tracking-tight text-foreground m-0">Fresh New Arrivals</h2>
            </div>
            <a href="<?= base_url('/shop/listing') ?>" class="text-xs uppercase tracking-wider font-bold text-foreground hover:text-amber-700 transition flex items-center gap-1.5">
                <span>Browse All New Drops</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
            </a>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            <?php foreach ($newArrivals as $p):
                $price = getDisplayPrice($p);
                $isWish = in_array((int)$p['id'], $userWishlistIds, true);
            ?>
                <div class="card-product-lux group">
                    <div class="product-media-wrap aspect-square" onclick="location.href='<?= base_url('/shop/product/' . (int)$p['id']) ?>'">
                        <img src="<?= e(product_image_url($p['image'])) ?>" alt="<?= e($p['title']) ?>"
                             onerror="this.onerror=null;this.src='<?= e(product_image_url('')) ?>';"
                             class="product-media-img" loading="lazy"/>

                        <button type="button" class="btn-wishlist-float <?= $isWish ? 'wishlisted' : '' ?>"
                                data-wishlist-toggle="<?= (int)$p['id'] ?>" title="Save" aria-label="Wishlist"
                                onclick="event.stopPropagation()">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="<?= $isWish ? '#be123c' : 'none' ?>" stroke="<?= $isWish ? '#be123c' : 'currentColor' ?>" stroke-width="2">
                                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                            </svg>
                        </button>
                    </div>
                    <div class="p-3.5 flex flex-col justify-between flex-1">
                        <div>
                            <p class="text-[10px] uppercase font-bold tracking-widest text-muted-foreground m-0 mb-1"><?= e($p['brand'] ?? 'ClothShop') ?></p>
                            <h4 class="text-xs sm:text-sm font-semibold line-clamp-1 m-0">
                                <a href="<?= base_url('/shop/product/' . (int)$p['id']) ?>" class="hover:text-amber-700 transition"><?= e($p['title']) ?></a>
                            </h4>
                        </div>
                        <div class="mt-3 pt-2.5 border-t border-border/80 flex items-center justify-between">
                            <span class="font-bold text-xs sm:text-sm text-foreground"><?= formatCurrency($price) ?></span>
                            <button type="button" class="btn-lux btn-lux-primary btn-lux-sm px-2.5 py-1 text-xs"
                                    onclick="quickAddToCart(<?= (int)$p['id'] ?>)"
                                    <?= !$p['totalStock'] ? 'disabled' : '' ?>>
                                + Add
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach ?>
        </div>
    </section>

    <!-- VIP Newsletter Banner -->
    <section class="container">
        <div class="rounded-3xl p-8 sm:p-14 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white text-center max-w-4xl mx-auto shadow-xl border border-slate-700 relative overflow-hidden">
            <div class="max-w-lg mx-auto relative z-10 space-y-4">
                <span class="inline-block px-3 py-1 rounded-full bg-amber-400 text-slate-950 font-bold text-[10px] uppercase tracking-widest">
                    VIP Privileges
                </span>
                <h3 class="font-display text-2xl sm:text-4xl font-extrabold m-0 tracking-tight">
                    Receive 15% Off Your Next Wardrobe Update
                </h3>
                <p class="text-slate-300 text-xs sm:text-sm m-0">
                    Subscribe to receive private invitations to seasonal drops, styling insights, and concierge promotions.
                </p>
                <form data-newsletter-form class="flex flex-col sm:flex-row gap-2.5 pt-2 max-w-md mx-auto">
                    <input type="email" placeholder="Enter your email address" required
                           class="flex-1 px-4 py-3 rounded-full text-xs bg-white/10 border border-white/20 text-white placeholder-slate-400 outline-none focus:border-white focus:bg-white/15"/>
                    <button type="submit" class="btn-lux btn-lux-white btn-lux-sm">
                        Join Circle &rarr;
                    </button>
                </form>
            </div>
            <div class="absolute -top-12 -left-12 w-48 h-48 rounded-full bg-amber-400/10 blur-2xl"></div>
            <div class="absolute -bottom-12 -right-12 w-48 h-48 rounded-full bg-indigo-500/10 blur-2xl"></div>
        </div>
    </section>
</div>

<script>
const __UID = '<?= $user ? (int)$user['id'] : '' ?>';

// Quick Add to Cart
async function quickAddToCart(productId) {
    if (!__UID) {
        toast('Sign In Required', 'Please sign in to add items to your shopping bag', 'info');
        setTimeout(() => {
            window.location.href = (window.APP_BASE || '') + '/auth/login';
        }, 1200);
        return;
    }
    try {
        await CartApi.add(__UID, productId, 1);
        toast('Added to Bag', 'Item successfully added to your shopping bag!', 'success');
    } catch (e) {}
}

// Global Quick View dialog loader
async function openGlobalQuickView(productId) {
    const dialog = document.getElementById('productDialog');
    const body = document.getElementById('pdBody');
    const title = document.getElementById('pdTitle');
    if (!dialog || !body) return;

    dialog.classList.remove('hidden');
    body.innerHTML = `
        <div class="p-12 text-center text-muted-foreground">
            <span class="inline-block animate-spin text-2xl mr-2">⏳</span> Loading atelier garment...
        </div>
    `;

    try {
        const res = await ProductApi.one(productId);
        const p = res.data;
        if (!p) throw new Error('Product not found');
        title.textContent = p.title;

        const price = Number(p.salePrice || 0) > 0 ? Number(p.salePrice) : Number(p.price || 0);
        const origPrice = Number(p.price || 0);
        const discount = origPrice > price ? Math.round((1 - price / origPrice) * 100) : 0;
        const _base = window.APP_BASE || '';

        body.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                <div class="aspect-[4/5] rounded-2xl overflow-hidden bg-slate-100 border border-border">
                    <img src="${formatImageUrl(p.image)}" alt="${_esc(p.title)}" class="w-full h-full object-cover"/>
                </div>
                <div class="space-y-4">
                    <div>
                        <span class="text-[10px] uppercase font-bold tracking-widest text-muted-foreground">${_esc(p.brand || 'ClothShop')}</span>
                        <h2 class="text-xl font-bold text-foreground m-0 mt-1">${_esc(p.title)}</h2>
                        <div class="flex items-center gap-2 mt-2">
                            ${renderStars(p.averageReview, 13)}
                            <span class="text-xs text-muted-foreground font-semibold">(${Number(p.averageReview || 0).toFixed(1)})</span>
                        </div>
                    </div>

                    <div class="p-3 bg-slate-50 rounded-xl border border-border flex items-baseline gap-3">
                        <span class="text-2xl font-black text-foreground">${formatCurrency(price)}</span>
                        ${origPrice > price ? `<span class="text-sm line-through text-muted-foreground">${formatCurrency(origPrice)}</span>` : ''}
                        ${discount > 0 ? `<span class="badge badge-destructive text-xs font-bold">-${discount}% OFF</span>` : ''}
                    </div>

                    <p class="text-xs text-muted-foreground leading-relaxed m-0">${_esc(p.description || 'Crafted with premium materials for everyday comfort.')}</p>

                    <div>
                        <label class="text-xs font-bold uppercase tracking-wider block mb-1.5">Select Size</label>
                        <div class="flex gap-2">
                            ${['S', 'M', 'L', 'XL'].map((s, idx) => `
                                <button type="button" class="size-pill-lux ${idx === 1 ? 'active':''}" onclick="this.parentElement.querySelectorAll('.size-pill-lux').forEach(b => b.classList.remove('active')); this.classList.add('active');">
                                    ${s}
                                </button>
                            `).join('')}
                        </div>
                    </div>

                    <div class="pt-2 flex gap-3">
                        <button type="button" class="btn-lux btn-lux-primary flex-1" onclick="quickAddToCart(${p.id})">
                            Add to Shopping Bag
                        </button>
                        <a href="${_base}/shop/product/${p.id}" class="btn-lux btn-lux-outline px-4 text-xs font-bold">
                            Full Details &rarr;
                        </a>
                    </div>
                </div>
            </div>
        `;
    } catch(err) {
        body.innerHTML = `<div class="p-8 text-center text-rose-500 font-semibold">${_esc(err.message)}</div>`;
    }
}

// Hero banner carousel auto slide
(function() {
    const slides = document.querySelectorAll('.hero-slide-lux');
    const dots = document.querySelectorAll('.hero-dot');
    if (slides.length <= 1) return;
    let current = 0;

    function showSlide(index) {
        slides.forEach((s, idx) => {
            s.classList.toggle('active', idx === index);
        });
        dots.forEach((d, idx) => {
            d.classList.toggle('active', idx === index);
        });
    }

    document.getElementById('nextHeroSlide')?.addEventListener('click', () => {
        current = (current + 1) % slides.length;
        showSlide(current);
    });
    document.getElementById('prevHeroSlide')?.addEventListener('click', () => {
        current = (current - 1 + slides.length) % slides.length;
        showSlide(current);
    });
    dots.forEach((dot, idx) => {
        dot.addEventListener('click', () => {
            current = idx;
            showSlide(current);
        });
    });

    setInterval(() => {
        current = (current + 1) % slides.length;
        showSlide(current);
    }, 6000);
})();
</script>

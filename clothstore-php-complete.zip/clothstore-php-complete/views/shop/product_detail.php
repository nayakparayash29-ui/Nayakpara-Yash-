<?php
/**
 * Dedicated Product Details View
 * Comprehensive luxury garment landing page with editorial gallery, size pills,
 * precision quantity controls, atelier specifications, customer reviews, and related collections.
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'listing';

require_once __DIR__ . '/../../models/Product.php';
require_once __DIR__ . '/../../models/Review.php';
require_once __DIR__ . '/../../models/Wishlist.php';

$pm = new ProductModel();
$rm = new ReviewModel();
$wm = new WishlistModel();

$productId = (int)($_GET['id'] ?? 0);
$product = $pm->findById($productId);

if (!$product) {
    setFlash('error', 'Product not found or has been removed.');
    redirect('/shop/listing');
    exit;
}

$pageTitle = $product['title'];
$reviews = $rm->findByProduct($productId);
$user = currentUser();
$isWishlisted = $user ? $wm->isWishlisted($user['id'], $productId) : false;

$price = getDisplayPrice($product);
$origPrice = (float)$product['price'];
$discount = $origPrice > 0 && $price < $origPrice ? round((1 - $price / $origPrice) * 100) : 0;

// Related products in same category
$related = $pm->findAll(['category' => $product['category']], 'price-lowtohigh');
$related = array_filter($related, function($r) use ($productId) { return (int)$r['id'] !== $productId; });
$related = array_slice($related, 0, 4);

$userWishlistIds = $user ? $wm->getProductIdsByUser($user['id']) : [];
?>
<div class="container py-8 space-y-12">
    <!-- Breadcrumbs -->
    <nav class="flex items-center gap-2 text-xs text-muted-foreground pb-2 border-b border-border">
        <a href="<?= base_url('/shop/home') ?>" class="hover:text-foreground transition">Home</a>
        <span>/</span>
        <a href="<?= base_url('/shop/listing') ?>" class="hover:text-foreground transition">Catalog</a>
        <span>/</span>
        <a href="<?= base_url('/shop/listing?category=' . urlencode($product['category'])) ?>" class="hover:text-foreground transition"><?= e($product['category']) ?></a>
        <span>/</span>
        <span class="text-foreground font-bold truncate max-w-xs"><?= e($product['title']) ?></span>
    </nav>

    <!-- Main Product Stage -->
    <div class="pdp-stage grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-14 items-start">
        <!-- Left Column: Gallery Stage -->
        <div class="space-y-4 sticky top-28">
            <div class="pdp-gallery-main relative group">
                <img id="mainProductImg" src="<?= e(product_image_url($product['image'])) ?>" alt="<?= e($product['title']) ?>"
                     onerror="this.onerror=null;this.src='<?= e(product_image_url('')) ?>';"
                     class="pdp-gallery-img"/>

                <!-- Badges -->
                <div class="badge-floating-corner">
                    <?php if ($discount > 0): ?>
                        <span class="badge-lux-sale">-<?= $discount ?>% OFF</span>
                    <?php endif ?>
                    <?php if (!empty($product['brand'])): ?>
                        <span class="badge-lux-new"><?= e($product['brand']) ?></span>
                    <?php endif ?>
                </div>

                <!-- Floating Wishlist Button -->
                <button type="button" class="btn-wishlist-float <?= $isWishlisted ? 'wishlisted' : '' ?>"
                        data-wishlist-toggle="<?= (int)$product['id'] ?>" title="Save to wishlist" aria-label="Wishlist">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="<?= $isWishlisted ? '#be123c' : 'none' ?>" stroke="<?= $isWishlisted ? '#be123c' : 'currentColor' ?>" stroke-width="2">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                    </svg>
                </button>

                <!-- Sold Out Scrim -->
                <?php if (!$product['totalStock']): ?>
                    <div class="stock-scrim">
                        <span class="stock-scrim-pill">SOLD OUT</span>
                    </div>
                <?php endif ?>
            </div>
        </div>

        <!-- Right Column: Garment Information & Purchasing -->
        <div class="space-y-6">
            <div class="space-y-3">
                <div class="flex items-center justify-between">
                    <span class="text-xs uppercase tracking-widest font-extrabold text-amber-800 bg-amber-50 border border-amber-200 px-3 py-1 rounded-full">
                        <?= e($product['brand'] ?? 'Atelier Collection') ?>
                    </span>
                    <span class="text-xs font-bold px-3 py-1 rounded-full <?= $product['totalStock'] > 0 ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-rose-50 text-rose-700 border border-rose-200' ?>">
                        <?= $product['totalStock'] > 0 ? "In Stock ({$product['totalStock']} units)" : 'Currently Sold Out' ?>
                    </span>
                </div>

                <h1 class="font-display text-2xl sm:text-4xl font-extrabold text-foreground leading-tight tracking-tight m-0">
                    <?= e($product['title']) ?>
                </h1>

                <!-- Rating & Reviews Anchor -->
                <div class="flex items-center gap-3">
                    <div class="flex items-center gap-1">
                        <?= renderStars($product['averageReview'], 16) ?>
                    </div>
                    <span class="text-xs font-bold text-foreground"><?= round((float)$product['averageReview'], 1) ?> / 5.0</span>
                    <span class="text-muted-foreground">•</span>
                    <a href="#reviewsSection" class="text-xs font-semibold text-muted-foreground hover:text-foreground transition underline">
                        <?= count($reviews) ?> Verified Reviews
                    </a>
                </div>
            </div>

            <!-- Luxury Price Presentation -->
            <div class="p-5 rounded-2xl bg-white border border-border flex items-baseline justify-between shadow-sm">
                <div>
                    <span class="font-display text-3xl sm:text-4xl font-extrabold text-foreground"><?= formatCurrency($price) ?></span>
                    <?php if ($origPrice > $price): ?>
                        <span class="text-base text-muted-foreground line-through ml-3"><?= formatCurrency($origPrice) ?></span>
                    <?php endif ?>
                </div>
                <?php if ($origPrice > $price): ?>
                    <span class="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full">
                        Complimentary Savings: <?= formatCurrency($origPrice - $price) ?>
                    </span>
                <?php endif ?>
            </div>

            <!-- Editorial Description -->
            <div class="space-y-2">
                <h4 class="text-xs uppercase font-extrabold tracking-widest text-muted-foreground m-0">Garment Overview</h4>
                <p class="text-xs sm:text-sm text-slate-600 leading-relaxed m-0">
                    <?= nl2br(e($product['description'] ?: 'Crafted with premium materials and designed for supreme everyday comfort, modern silhouettes, and effortless versatility.')) ?>
                </p>
            </div>

            <!-- Size Selection -->
            <div class="space-y-3 pt-2">
                <div class="flex items-center justify-between">
                    <label class="text-xs font-extrabold text-foreground uppercase tracking-widest">Select Fit & Size</label>
                    <a href="<?= base_url('/shop/policies/shipping') ?>" class="text-xs text-muted-foreground hover:text-foreground font-semibold underline">
                        Atelier Sizing Guide
                    </a>
                </div>
                <div class="flex flex-wrap gap-2.5" id="sizeSelector">
                    <?php foreach (['XS', 'S', 'M', 'L', 'XL', 'XXL'] as $idx => $sz): ?>
                        <button type="button" class="size-pill-lux <?= $idx === 2 ? 'active' : '' ?>"
                                onclick="selectProductSize(this)">
                            <?= $sz ?>
                        </button>
                    <?php endforeach ?>
                </div>
            </div>

            <!-- Quantity & Bag Actions -->
            <div class="space-y-3 pt-2">
                <label class="text-xs font-extrabold text-foreground uppercase tracking-widest block">Quantity</label>
                <div class="flex items-center gap-3">
                    <!-- Qty Stepper -->
                    <div class="qty-stepper-lux">
                        <button type="button" class="qty-stepper-btn" onclick="changeQty(-1)">-</button>
                        <input id="productQuantity" type="number" min="1" max="<?= max(1, (int)$product['totalStock']) ?>" value="1" readonly class="qty-stepper-val text-xs font-bold border-0 bg-transparent outline-none"/>
                        <button type="button" class="qty-stepper-btn" onclick="changeQty(1)">+</button>
                    </div>

                    <!-- Add to Bag Button -->
                    <button type="button" id="addToCartBtn" class="btn-lux btn-lux-primary flex-1 text-sm"
                            onclick="handleAddToCart()" <?= !$product['totalStock'] ? 'disabled' : '' ?>>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
                            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                        </svg>
                        <span>Add to Shopping Bag</span>
                    </button>
                </div>

                <!-- Instant Buy Button -->
                <button type="button" id="buyNowBtn" class="btn-lux btn-lux-outline w-full text-xs font-bold"
                        onclick="handleBuyNow()" <?= !$product['totalStock'] ? 'disabled' : '' ?>>
                    Instant 1-Click Checkout &rarr;
                </button>
            </div>

            <!-- Atelier Garment Specs Block -->
            <div class="p-5 rounded-2xl bg-white border border-border shadow-sm space-y-3">
                <h4 class="text-xs uppercase font-extrabold tracking-widest text-foreground m-0">Specifications & Care</h4>
                <div class="grid grid-cols-2 gap-3 text-xs">
                    <div>
                        <span class="text-muted-foreground block text-[11px]">Department:</span>
                        <strong class="text-foreground"><?= e($product['category'] ?? 'Apparel') ?></strong>
                    </div>
                    <div>
                        <span class="text-muted-foreground block text-[11px]">Textile:</span>
                        <strong class="text-foreground">100% Organic Supima / Fine Knit</strong>
                    </div>
                    <div>
                        <span class="text-muted-foreground block text-[11px]">Care Instructions:</span>
                        <strong class="text-foreground">Gentle wash cold, hang dry</strong>
                    </div>
                    <div>
                        <span class="text-muted-foreground block text-[11px]">Craftsmanship:</span>
                        <strong class="text-foreground">Reinforced seams, precision finish</strong>
                    </div>
                </div>
            </div>

            <!-- Value Proposition Card -->
            <div class="p-4 rounded-2xl bg-white border border-border grid grid-cols-3 gap-3 text-center text-xs shadow-sm">
                <div>
                    <span class="text-lg block mb-1">🚚</span>
                    <strong class="text-foreground block text-[11px]">Express Delivery</strong>
                    <span class="text-muted-foreground text-[10px]">Free over ₹1,000</span>
                </div>
                <div>
                    <span class="text-lg block mb-1">🔄</span>
                    <strong class="text-foreground block text-[11px]">7-Day Concierge</strong>
                    <span class="text-muted-foreground text-[10px]">Doorstep exchange</span>
                </div>
                <div>
                    <span class="text-lg block mb-1">🛡️</span>
                    <strong class="text-foreground block text-[11px]">100% Authentic</strong>
                    <span class="text-muted-foreground text-[10px]">Certified atelier drop</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Customer Ratings & Reviews Section -->
    <section id="reviewsSection" class="border-t border-border pt-12 space-y-8">
        <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
                <span class="text-xs uppercase tracking-widest font-extrabold text-muted-foreground">Community Feedback</span>
                <h3 class="font-display text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight m-0 mt-1">
                    Customer Ratings & Reviews
                </h3>
            </div>
            <span class="text-xs text-muted-foreground">
                Showing <strong><?= count($reviews) ?></strong> verified purchaser reviews
            </span>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
            <!-- Review Summary & Submission Box -->
            <div class="p-6 bg-white border border-border rounded-3xl shadow-sm space-y-6">
                <div class="text-center space-y-1">
                    <span class="font-display text-5xl font-extrabold text-foreground block"><?= round((float)$product['averageReview'], 1) ?></span>
                    <div class="flex justify-center my-1"><?= renderStars($product['averageReview'], 20) ?></div>
                    <span class="text-xs text-muted-foreground">Overall rating based on <?= count($reviews) ?> reviews</span>
                </div>

                <?php if ($user): ?>
                    <div class="pt-4 border-t border-border space-y-3">
                        <h4 class="font-bold text-xs uppercase tracking-wider text-foreground m-0">Write a Review</h4>
                        <form id="writeReviewForm" class="space-y-3" onsubmit="handleReviewSubmit(event)">
                            <div class="review-field">
                                <label for="revVal">Your Rating</label>
                                <select id="revVal" class="form-select-lux text-xs">
                                    <option value="5">⭐⭐⭐⭐⭐ 5 Stars - Exceptional</option>
                                    <option value="4">⭐⭐⭐⭐ 4 Stars - Very Good</option>
                                    <option value="3">⭐⭐⭐ 3 Stars - Average</option>
                                    <option value="2">⭐⭐ 2 Stars - Needs Improvement</option>
                                    <option value="1">⭐ 1 Star - Poor</option>
                                </select>
                            </div>
                            <div class="review-field">
                                <label for="revMsg">Review Comments</label>
                                <textarea id="revMsg" placeholder="Share your experience regarding the fabric feel, sizing fit, and overall quality..." required class="form-textarea-lux"></textarea>
                            </div>
                            <button type="submit" id="submitReviewBtn" class="btn-lux btn-lux-primary w-full text-xs">
                                Post Verified Review
                            </button>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="p-4 rounded-2xl bg-slate-50 border border-border text-center text-xs space-y-2">
                        <p class="text-muted-foreground m-0">Please sign in to share your impressions with the community.</p>
                        <a href="<?= base_url('/auth/login') ?>" class="btn-lux btn-lux-primary btn-lux-sm w-full block">Sign In to Review</a>
                    </div>
                <?php endif ?>
            </div>

            <!-- Review Cards List -->
            <div class="lg:col-span-2 space-y-3.5">
                <?php if (empty($reviews)): ?>
                    <div class="p-12 text-center bg-white border border-dashed border-border rounded-3xl">
                        <span class="text-3xl block mb-2">✍️</span>
                        <h4 class="font-bold text-sm text-foreground m-0">No Reviews Yet</h4>
                        <p class="text-xs text-muted-foreground mt-1 max-w-sm mx-auto">
                            Be the first patron to share your thoughts on this garment's tailoring, comfort, and silhouette.
                        </p>
                    </div>
                <?php else: ?>
                    <?php foreach ($reviews as $rev): ?>
                        <div class="review-card-lux space-y-2">
                            <div class="flex items-center justify-between">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-xs shadow-sm">
                                        <?= strtoupper(substr($rev['userName'] ?? 'U', 0, 1)) ?>
                                    </div>
                                    <div>
                                        <h5 class="font-bold text-xs text-foreground m-0 leading-tight"><?= e($rev['userName']) ?></h5>
                                        <span class="text-[10px] text-muted-foreground"><?= !empty($rev['created_at']) ? date('d M Y', strtotime($rev['created_at'])) : 'Verified Patron' ?></span>
                                    </div>
                                </div>
                                <div class="flex items-center gap-1">
                                    <?= renderStars($rev['reviewValue'], 13) ?>
                                </div>
                            </div>
                            <p class="text-xs text-slate-600 leading-relaxed m-0 pt-1">
                                <?= nl2br(e($rev['reviewMessage'])) ?>
                            </p>
                        </div>
                    <?php endforeach ?>
                <?php endif ?>
            </div>
        </div>
    </section>

    <!-- Related Products Showcase -->
    <?php if (!empty($related)): ?>
    <section class="border-t border-border pt-12 space-y-6">
        <div class="flex items-center justify-between">
            <div>
                <span class="text-xs uppercase tracking-widest font-extrabold text-muted-foreground">Curated Edit</span>
                <h3 class="font-display text-2xl font-extrabold text-foreground m-0 mt-1">Complete The Look</h3>
            </div>
            <a href="<?= base_url('/shop/listing?category=' . urlencode($product['category'])) ?>" class="text-xs font-bold text-foreground hover:underline">
                View All in <?= e($product['category']) ?> &rarr;
            </a>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            <?php foreach ($related as $rel):
                $relPrice = getDisplayPrice($rel);
                $relOrig = (float)$rel['price'];
                $relDisc = $relOrig > $relPrice ? round((1 - $relPrice / $relOrig) * 100) : 0;
                $relIsWish = in_array((int)$rel['id'], $userWishlistIds, true);
            ?>
                <div class="card-product-lux group">
                    <div class="product-media-wrap" onclick="location.href='<?= base_url('/shop/product/' . (int)$rel['id']) ?>'">
                        <img src="<?= e(product_image_url($rel['image'])) ?>" alt="<?= e($rel['title']) ?>"
                             onerror="this.onerror=null;this.src='<?= e(product_image_url('')) ?>';"
                             class="product-media-img" loading="lazy"/>

                        <div class="badge-floating-corner">
                            <?php if ($relDisc > 0): ?>
                                <span class="badge-lux-sale">-<?= $relDisc ?>%</span>
                            <?php endif ?>
                            <?php if (!empty($rel['brand'])): ?>
                                <span class="badge-lux-new"><?= e($rel['brand']) ?></span>
                            <?php endif ?>
                        </div>

                        <button type="button" class="btn-wishlist-float <?= $relIsWish ? 'wishlisted' : '' ?>"
                                data-wishlist-toggle="<?= (int)$rel['id'] ?>" title="Save to wishlist" aria-label="Wishlist"
                                onclick="event.stopPropagation()">
                            <svg width="17" height="17" viewBox="0 0 24 24" fill="<?= $relIsWish ? '#be123c' : 'none' ?>" stroke="<?= $relIsWish ? '#be123c' : 'currentColor' ?>" stroke-width="2">
                                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                            </svg>
                        </button>
                    </div>

                    <div class="product-info-wrap">
                        <div>
                            <p class="product-brand-tag"><?= e($rel['category'] ?? 'Atelier') ?></p>
                            <h4 class="product-title-lux">
                                <a href="<?= base_url('/shop/product/' . (int)$rel['id']) ?>"><?= e($rel['title']) ?></a>
                            </h4>
                            <div class="product-meta-row">
                                <?= renderStars($rel['averageReview'], 12) ?>
                                <span class="product-reviews-count">(<?= round((float)$rel['averageReview'], 1) ?>)</span>
                            </div>
                        </div>

                        <div class="product-price-row">
                            <div>
                                <span class="price-current-lux"><?= formatCurrency($relPrice) ?></span>
                                <?php if ($relOrig > $relPrice): ?>
                                    <span class="price-original-lux"><?= formatCurrency($relOrig) ?></span>
                                <?php endif ?>
                            </div>
                            <span class="text-[11px] font-bold text-emerald-700">In Stock</span>
                        </div>
                    </div>
                </div>
            <?php endforeach ?>
        </div>
    </section>
    <?php endif ?>
</div>

<script>
const __UID = '<?= $user ? (int)$user['id'] : '' ?>';
const __PID = <?= (int)$product['id'] ?>;

function selectProductSize(btn) {
    document.querySelectorAll('.size-pill-lux').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
}

function changeQty(delta) {
    const input = document.getElementById('productQuantity');
    if (!input) return;
    const max = parseInt(input.getAttribute('max') || '10');
    let val = parseInt(input.value || '1') + delta;
    if (val < 1) val = 1;
    if (val > max) val = max;
    input.value = val;
}

async function handleAddToCart() {
    if (!__UID) {
        toast('Sign In Required', 'Please sign in to add items to your shopping bag', 'info');
        setTimeout(() => window.location.href = (window.APP_BASE || '') + '/auth/login', 1200);
        return;
    }
    const qty = parseInt(document.getElementById('productQuantity')?.value || '1');
    const btn = document.getElementById('addToCartBtn');
    btn.disabled = true;
    try {
        await CartApi.add(__UID, __PID, qty);
        toast('Added to Bag', 'Item successfully added to your shopping bag!', 'success');
    } catch(e) {}
    finally {
        btn.disabled = false;
    }
}

async function handleBuyNow() {
    if (!__UID) {
        toast('Sign In Required', 'Please sign in to proceed with checkout', 'info');
        setTimeout(() => window.location.href = (window.APP_BASE || '') + '/auth/login', 1200);
        return;
    }
    const qty = parseInt(document.getElementById('productQuantity')?.value || '1');
    try {
        await CartApi.add(__UID, __PID, qty, { silent: true });
        window.location.href = (window.APP_BASE || '') + '/shop/checkout';
    } catch(e) {}
}

async function handleReviewSubmit(e) {
    e.preventDefault();
    const val = parseInt(document.getElementById('revVal').value);
    const msg = document.getElementById('revMsg').value.trim();
    if (!msg) return;
    const btn = document.getElementById('submitReviewBtn');
    btn.disabled = true;
    try {
        await ReviewApi.add({
            productId: __PID,
            reviewValue: val,
            reviewMessage: msg
        });
        toast('Review Submitted', 'Thank you for your valuable feedback!', 'success');
        setTimeout(() => location.reload(), 600);
    } catch(e) {
        btn.disabled = false;
    }
}
</script>

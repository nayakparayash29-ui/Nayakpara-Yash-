<?php
/**
 * Payment Success / Order Confirmation Page
 * Celebratory confirmation receipt with order summary, item list,
 * delivery pipeline tracker, and navigation actions.
 */
if (!isset($viewContent)) $viewContent = __FILE__;
requireLogin();
$user = currentUser();
$pageTitle = 'Order Confirmed';

$sessionId = $_GET['session_id'] ?? null;
$orderId   = $_GET['order_id'] ?? null;
$orderData = null;

require_once __DIR__ . '/../../models/Order.php';
$om = new OrderModel();

// If order_id provided
if ($orderId) {
    $orderData = $om->findById((int)$orderId);
    if ($orderData && (int)$orderData['userId'] !== (int)$user['id']) $orderData = null;
}

// Confirm a real Stripe Checkout session after the customer returns
if (!$orderData && $sessionId && preg_match('/^cs_(test|live)_/', $sessionId)) {
    require_once __DIR__ . '/../../includes/stripe.php';
    [$code, $session] = stripeApi('GET', '/checkout/sessions/' . rawurlencode($sessionId));
    $paidOrderId = $session['metadata']['order_id'] ?? $session['client_reference_id'] ?? '';
    if ($code === 200 && $paidOrderId) {
        $o = $om->findById($paidOrderId);
        if ($o && (int)$o['userId'] === (int)$user['id']) {
            if (($session['payment_status'] ?? '') === 'paid') {
                $orderData = fulfillStripeOrder($o);
            } else {
                $orderData = $o;
            }
        }
    }
}
?>
<div class="container py-10 max-w-3xl space-y-6">
    <div class="card-lux overflow-hidden shadow-2xl">
        <!-- Top Celebration Banner -->
        <div class="p-8 sm:p-12 text-center bg-gradient-to-b from-amber-50/60 via-emerald-50/30 to-transparent border-b border-border">
            <div class="w-20 h-20 mx-auto mb-4 bg-emerald-600 text-white rounded-full flex items-center justify-center text-3xl shadow-lg animate-fade-in-scale">
                ✓
            </div>
            <span class="inline-block text-[11px] font-extrabold uppercase tracking-widest px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200 mb-2">
                Order Confirmed & Secured
            </span>
            <h1 class="font-display text-2xl sm:text-4xl font-extrabold text-foreground m-0 tracking-tight">
                Thank You for Entrusting Us
            </h1>
            <p class="text-xs sm:text-sm text-muted-foreground mt-2 max-w-md mx-auto leading-relaxed">
                Your order is safely in our atelier pipeline. A verified digital confirmation has been delivered to <strong><?= e($user['email']) ?></strong>.
            </p>
        </div>

        <div class="p-6 sm:p-8 space-y-8">
            <?php if ($orderData): ?>
                <!-- Key Details Metrics Grid -->
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div class="p-4 rounded-2xl bg-slate-50 border border-border text-center">
                        <span class="text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground block">Order Ref</span>
                        <strong class="font-display text-base font-extrabold text-foreground mt-1 block">#<?= str_pad($orderData['id'], 6, '0', STR_PAD_LEFT) ?></strong>
                    </div>
                    <div class="p-4 rounded-2xl bg-slate-50 border border-border text-center">
                        <span class="text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground block">Date Placed</span>
                        <strong class="text-xs font-bold text-foreground mt-1 block">
                            <?= $orderData['orderDate'] ? date('d M Y', strtotime($orderData['orderDate'])) : date('d M Y') ?>
                        </strong>
                    </div>
                    <div class="p-4 rounded-2xl bg-slate-50 border border-border text-center">
                        <span class="text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground block">Payment Mode</span>
                        <span class="text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full inline-block mt-1">
                            <?= strtoupper(e($orderData['paymentMethod'])) ?> • <?= ucfirst(e($orderData['paymentStatus'])) ?>
                        </span>
                    </div>
                    <div class="p-4 rounded-2xl bg-slate-50 border border-border text-center">
                        <span class="text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground block">Grand Total</span>
                        <strong class="font-display text-base font-black text-foreground mt-1 block"><?= formatCurrency($orderData['totalAmount']) ?></strong>
                    </div>
                </div>

                <!-- Order Tracking Timeline Pipeline -->
                <div class="p-6 rounded-2xl bg-slate-50 border border-border space-y-4">
                    <div class="flex items-center justify-between">
                        <h4 class="font-bold text-xs uppercase tracking-wider text-foreground m-0">Fulfillment Pipeline</h4>
                        <span class="text-xs font-bold text-emerald-700">Estimated Delivery: 3–5 Business Days</span>
                    </div>
                    <div class="grid grid-cols-4 text-center text-xs relative pt-2">
                        <div class="space-y-1">
                            <div class="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold mx-auto shadow-sm">✓</div>
                            <span class="font-bold text-foreground block">Confirmed</span>
                            <span class="text-[10px] text-muted-foreground">Order In Queue</span>
                        </div>
                        <div class="space-y-1">
                            <div class="w-8 h-8 rounded-full <?= in_array($orderData['orderStatus'], ['confirmed','shipped','delivered']) ? 'bg-slate-900 text-white':'bg-slate-200 text-slate-500' ?> flex items-center justify-center font-bold mx-auto">
                                <?= in_array($orderData['orderStatus'], ['confirmed','shipped','delivered']) ? '✓':'2' ?>
                            </div>
                            <span class="font-semibold block">Tailoring</span>
                            <span class="text-[10px] text-muted-foreground">Packing & QC</span>
                        </div>
                        <div class="space-y-1">
                            <div class="w-8 h-8 rounded-full <?= in_array($orderData['orderStatus'], ['shipped','delivered']) ? 'bg-slate-900 text-white':'bg-slate-200 text-slate-500' ?> flex items-center justify-center font-bold mx-auto">
                                <?= in_array($orderData['orderStatus'], ['shipped','delivered']) ? '✓':'3' ?>
                            </div>
                            <span class="font-semibold block">Dispatched</span>
                            <span class="text-[10px] text-muted-foreground">Courier En Route</span>
                        </div>
                        <div class="space-y-1">
                            <div class="w-8 h-8 rounded-full <?= $orderData['orderStatus'] === 'delivered' ? 'bg-slate-900 text-white':'bg-slate-200 text-slate-500' ?> flex items-center justify-center font-bold mx-auto">
                                <?= $orderData['orderStatus'] === 'delivered' ? '✓':'4' ?>
                            </div>
                            <span class="font-semibold block">Delivered</span>
                            <span class="text-[10px] text-muted-foreground">At Doorstep</span>
                        </div>
                    </div>
                </div>

                <!-- Items Breakdown -->
                <div class="space-y-3">
                    <h4 class="font-bold text-xs uppercase tracking-wider text-foreground m-0">Garments in this consignment (<?= count($orderData['cartItems']) ?>)</h4>
                    <div class="divide-y divide-border border border-border rounded-2xl overflow-hidden bg-white">
                        <?php foreach ($orderData['cartItems'] as $it):
                            $p = (float)($it['salePrice'] ?? $it['price']);
                        ?>
                            <div class="p-3.5 sm:p-4 flex items-center gap-3">
                                <div class="w-14 h-16 rounded-xl bg-slate-100 flex-shrink-0 overflow-hidden border border-border/80">
                                    <img src="<?= e(product_image_url($it['image'] ?? '')) ?>" alt=""
                                         onerror="this.onerror=null;this.src='<?= e(product_image_url('')) ?>';"
                                         class="w-full h-full object-cover"/>
                                </div>
                                <div class="flex-1 min-w-0">
                                    <h5 class="text-xs sm:text-sm font-semibold text-foreground line-clamp-1 m-0"><?= e($it['title']) ?></h5>
                                    <p class="text-[11px] text-muted-foreground m-0 mt-0.5">Quantity: <?= (int)$it['quantity'] ?> × <?= formatCurrency($p) ?></p>
                                </div>
                                <span class="font-display text-xs sm:text-sm font-bold text-foreground flex-shrink-0"><?= formatCurrency($p * (int)$it['quantity']) ?></span>
                            </div>
                        <?php endforeach ?>
                    </div>
                </div>

                <!-- Shipping Destination Snapshot -->
                <?php if (!empty($orderData['addressInfo'])): ?>
                    <div class="p-5 rounded-2xl bg-white border border-border space-y-1 text-xs">
                        <strong class="text-foreground font-bold block uppercase tracking-wider text-[10px] mb-1">Delivering To:</strong>
                        <p class="m-0 font-bold text-foreground"><?= e($user['userName']) ?></p>
                        <p class="m-0 text-muted-foreground"><?= e($orderData['addressInfo']['address']) ?></p>
                        <p class="m-0 text-muted-foreground"><?= e($orderData['addressInfo']['city']) ?>, PIN: <?= e($orderData['addressInfo']['pincode']) ?></p>
                        <p class="m-0 pt-1 font-semibold text-foreground">📞 <?= e($orderData['addressInfo']['phone']) ?></p>
                    </div>
                <?php endif ?>
            <?php else: ?>
                <div class="text-center py-8">
                    <p class="text-xs text-muted-foreground m-0">Your order is being registered in our system. You can review all details directly inside your customer portal.</p>
                </div>
            <?php endif ?>

            <!-- Navigation Actions -->
            <div class="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4 border-t border-border">
                <a href="<?= base_url('/shop/account?tab=orders') ?>" class="btn-lux btn-lux-primary w-full sm:w-auto text-xs text-center">
                    Track in My Orders &rarr;
                </a>
                <a href="<?= base_url('/shop/listing') ?>" class="btn-lux btn-lux-outline w-full sm:w-auto text-xs text-center">
                    Continue Shopping
                </a>
            </div>
        </div>
    </div>
</div>

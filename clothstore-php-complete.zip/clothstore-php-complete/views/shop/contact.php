<?php
/**
 * Contact Us & Concierge Helpdesk
 * Luxury customer care cards, concierge inquiry form, and FAQ accordion.
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'contact';
$pageTitle = 'Concierge Helpdesk & Support';
?>
<div class="container py-10 space-y-12 max-w-5xl">
    <!-- Header -->
    <div class="text-center space-y-3 max-w-xl mx-auto">
        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-900 border border-amber-200 text-[10px] uppercase font-extrabold tracking-widest">
            Atelier Client Relations
        </span>
        <h1 class="font-display text-3xl sm:text-5xl font-extrabold text-foreground tracking-tight m-0">
            Dedicated Concierge Care
        </h1>
        <p class="text-xs sm:text-sm text-muted-foreground leading-relaxed m-0">
            Have questions regarding sizing nuances, bespoke tailoring, order tracking, or exchange pickups? Our concierge team is at your service.
        </p>
    </div>

    <!-- Concierge Cards Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="stat-box-lux p-5 text-center space-y-2">
            <div class="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-xl mx-auto shadow-sm">
                📞
            </div>
            <h4 class="font-display font-bold text-sm text-foreground m-0">Direct Concierge</h4>
            <p class="text-[11px] text-muted-foreground m-0">Mon – Sat: 10AM – 7PM IST</p>
            <a href="tel:+919876543210" class="text-xs font-bold text-foreground hover:underline block pt-1">+91 98765 43210</a>
        </div>

        <div class="stat-box-lux p-5 text-center space-y-2">
            <div class="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-xl mx-auto shadow-sm">
                ✉️
            </div>
            <h4 class="font-display font-bold text-sm text-foreground m-0">Private Inquiries</h4>
            <p class="text-[11px] text-muted-foreground m-0">Response within 24 hours</p>
            <a href="mailto:concierge@clothstore.com" class="text-xs font-bold text-foreground hover:underline block pt-1">concierge@clothstore.com</a>
        </div>

        <div class="stat-box-lux p-5 text-center space-y-2">
            <div class="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-xl mx-auto shadow-sm">
                📍
            </div>
            <h4 class="font-display font-bold text-sm text-foreground m-0">Flagship Atelier</h4>
            <p class="text-[11px] text-muted-foreground m-0">CG Road, Navrangpura</p>
            <span class="text-xs font-bold text-foreground block pt-1">Ahmedabad, Gujarat</span>
        </div>

        <div class="stat-box-lux p-5 text-center space-y-2">
            <div class="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-xl mx-auto shadow-sm">
                🔄
            </div>
            <h4 class="font-display font-bold text-sm text-foreground m-0">Concierge Returns</h4>
            <p class="text-[11px] text-muted-foreground m-0">7-Day doorstep pickup</p>
            <a href="<?= base_url('/shop/policies/returns') ?>" class="text-xs font-bold text-foreground hover:underline block pt-1">View Policy &rarr;</a>
        </div>
    </div>

    <!-- Inquiry Form & FAQ Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        <!-- Inquiry Form -->
        <div class="card-lux p-6 sm:p-8 space-y-5">
            <div>
                <h3 class="font-display text-xl font-bold text-foreground m-0">Dispatch a Message</h3>
                <p class="text-xs text-muted-foreground m-0 mt-0.5">Please share your contact details and inquiry details below.</p>
            </div>

            <form id="contactForm" class="space-y-4" onsubmit="handleContactSubmit(event)">
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="text-xs font-bold text-foreground block mb-1">Your Full Name <span class="text-rose-500">*</span></label>
                        <input type="text" id="contactName" required placeholder="Elena Rostova" class="form-input-lux text-xs"/>
                    </div>
                    <div>
                        <label class="text-xs font-bold text-foreground block mb-1">Email Address <span class="text-rose-500">*</span></label>
                        <input type="email" id="contactEmail" required placeholder="elena@example.com" class="form-input-lux text-xs"/>
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="text-xs font-bold text-foreground block mb-1">Phone Number <span class="text-muted-foreground font-normal">(Optional)</span></label>
                        <input type="tel" id="contactPhone" placeholder="+91 98765 43210" class="form-input-lux text-xs"/>
                    </div>
                    <div>
                        <label class="text-xs font-bold text-foreground block mb-1">Inquiry Nature <span class="text-rose-500">*</span></label>
                        <select id="contactSubject" class="form-select-lux text-xs">
                            <option value="Order Tracking">Order Fulfillment & Tracking</option>
                            <option value="Returns & Exchanges">Doorstep Exchange / Return</option>
                            <option value="Sizing Consultation">Garment Sizing & Fit Advice</option>
                            <option value="Bespoke Order">Bespoke / Bulk Inquiries</option>
                            <option value="General">General Inquiries</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label class="text-xs font-bold text-foreground block mb-1">Detailed Message <span class="text-rose-500">*</span></label>
                    <textarea id="contactMessage" required placeholder="Please describe how we can assist you..." class="form-textarea-lux text-xs" style="min-height:5.5rem;"></textarea>
                </div>

                <button type="submit" id="contactSubmitBtn" class="btn-lux btn-lux-primary w-full text-xs">
                    Dispatch Inquiry to Concierge &rarr;
                </button>
            </form>
        </div>

        <!-- FAQ Accordion -->
        <div class="space-y-4">
            <div>
                <h3 class="font-display text-xl font-bold text-foreground m-0">Frequently Addressed Inquiries</h3>
                <p class="text-xs text-muted-foreground m-0 mt-0.5">Quick answers regarding orders, fittings, and doorstep deliveries</p>
            </div>

            <div class="space-y-3">
                <div class="faq-item-lux p-4 space-y-1">
                    <h5 class="font-bold text-xs text-foreground m-0">How do I monitor my order fulfillment in real-time?</h5>
                    <p class="text-xs text-muted-foreground m-0 leading-relaxed pt-1">
                        Log into your account, navigate to <a href="<?= base_url('/shop/account?tab=orders') ?>" class="text-foreground font-bold hover:underline">My Orders</a>, and click "View Details" to view courier milestones and live tracking status.
                    </p>
                </div>

                <div class="faq-item-lux p-4 space-y-1">
                    <h5 class="font-bold text-xs text-foreground m-0">What is the complimentary exchange duration?</h5>
                    <p class="text-xs text-muted-foreground m-0 leading-relaxed pt-1">
                        We provide a 7-day complimentary exchange window from delivery date. We arrange free doorstep reverse pickup within 24 to 48 hours.
                    </p>
                </div>

                <div class="faq-item-lux p-4 space-y-1">
                    <h5 class="font-bold text-xs text-foreground m-0">Is Cash on Delivery (COD) supported nationwide?</h5>
                    <p class="text-xs text-muted-foreground m-0 leading-relaxed pt-1">
                        Yes, Cash on Delivery is supported on all orders up to ₹10,000 across India. You can pay via cash or UPI directly to our delivery courier.
                    </p>
                </div>

                <div class="faq-item-lux p-4 space-y-1">
                    <h5 class="font-bold text-xs text-foreground m-0">How are your archival fabrics ethically sourced?</h5>
                    <p class="text-xs text-muted-foreground m-0 leading-relaxed pt-1">
                        All Supima cotton, Belgian linens, and Italian wools are sourced from OEKO-TEX certified partners that follow zero-waste and fair-wage standards.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function handleContactSubmit(e) {
    e.preventDefault();
    const btn = document.getElementById('contactSubmitBtn');
    btn.disabled = true;
    btn.textContent = 'Transmitting...';

    setTimeout(() => {
        toast('Message Transmitted', 'Thank you for reaching out. Our concierge desk will respond within 24 hours.', 'success');
        document.getElementById('contactForm').reset();
        btn.disabled = false;
        btn.innerHTML = `Dispatch Inquiry to Concierge &rarr;`;
    }, 500);
}
</script>

<?php
/**
 * Dedicated Shopping Cart Page
 * Full page luxury shopping bag experience with live quantity changes,
 * milestone progress bar, promotional codes, and verified checkout routing.
 */
if (!isset($viewContent)) $viewContent = __FILE__;
$active = 'cart';
$pageTitle = 'Shopping Bag';

require_once __DIR__ . '/../../models/Cart.php';
$user = currentUser();

$items = [];
$subtotal = 0;
if ($user) {
    $cm = new CartModel();
    $cart = $cm->getPopulatedCart($user['id']);
    if ($cart) $items = $cart['items'] ?? [];
    foreach ($items as $it) {
        $p = (float)($it['salePrice'] ?: $it['price']);
        $subtotal += $p * (int)$it['quantity'];
    }
}
$shipping = $subtotal > 0 ? ($subtotal >= 1000 ? 0 : 99) : 0;
$tax = round($subtotal * 0.05, 2);
$total = $subtotal + $shipping + $tax;
?>
<div class="container py-8 space-y-8">
    <!-- Header & Breadcrumbs -->
    <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-border">
        <div>
            <nav class="flex items-center gap-1.5 text-xs text-muted-foreground mb-2">
                <a href="<?= base_url('/shop/home') ?>" class="hover:text-foreground transition">Home</a>
                <span>/</span>
                <span class="text-foreground font-bold">Shopping Bag</span>
            </nav>
            <h1 class="font-display text-3xl sm:text-4xl font-extrabold text-foreground m-0 tracking-tight">
                Your Shopping Bag
            </h1>
            <p class="text-xs text-muted-foreground m-0 mt-1">
                You currently have <strong><?= count($items) ?></strong> unique item(s) selected
            </p>
        </div>
        <a href="<?= base_url('/shop/listing') ?>" class="btn-lux btn-lux-outline btn-lux-sm self-start sm:self-auto">
            ← Continue Browsing
        </a>
    </div>

    <?php if (empty($items)): ?>
        <div class="card p-16 text-center rounded-3xl max-w-lg mx-auto border border-dashed border-border bg-white shadow-sm space-y-4">
            <div class="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
                <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                    <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                </svg>
            </div>
            <h3 class="font-display text-xl font-bold text-foreground m-0">Your Bag is Empty</h3>
            <p class="text-xs text-muted-foreground max-w-xs mx-auto leading-relaxed">
                Discover exceptional tailoring, fluid silhouettes, and essential wardrobe foundations.
            </p>
            <div class="pt-2">
                <a href="<?= base_url('/shop/listing') ?>" class="btn-lux btn-lux-primary btn-lux-sm">
                    Discover Collections &rarr;
                </a>
            </div>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
            <!-- Left 2 Cols: Cart Item Rows -->
            <div class="lg:col-span-2 space-y-4">
                <!-- Free Delivery Milestone -->
                <div class="free-delivery-milestone">
                    <?php if ($subtotal >= 1000): ?>
                        <div class="flex items-center gap-2 text-emerald-700 font-bold text-xs">
                            <span class="text-base">🎉</span>
                            <span>You've unlocked <strong>Complimentary Express Delivery</strong> across India!</span>
                        </div>
                        <div class="progress-track">
                            <div class="progress-bar-fill" style="width: 100%;"></div>
                        </div>
                    <?php else: ?>
                        <?php $pct = min(100, round(($subtotal / 1000) * 100)); ?>
                        <div class="flex items-center justify-between text-xs text-muted-foreground">
                            <span>Add <strong><?= formatCurrency(1000 - $subtotal) ?></strong> more to qualify for <strong>Free Delivery</strong></span>
                            <span class="font-bold text-foreground"><?= $pct ?>%</span>
                        </div>
                        <div class="progress-track">
                            <div class="progress-bar-fill" style="width: <?= $pct ?>%;"></div>
                        </div>
                    <?php endif ?>
                </div>

                <!-- Bag Items List -->
                <div class="space-y-3">
                    <?php foreach ($items as $it):
                        $p = (float)($it['salePrice'] ?: $it['price']);
                        $lineTotal = $p * (int)$it['quantity'];
                    ?>
                        <div class="p-4 sm:p-5 flex gap-4 items-center bg-white border border-border rounded-2xl shadow-sm hover:border-slate-300 transition">
                            <div class="w-20 h-24 sm:w-24 sm:h-28 bg-slate-100 rounded-xl flex-shrink-0 overflow-hidden border border-border/80">
                                <img src="<?= e(product_image_url($it['image'] ?? '')) ?>" alt="<?= e($it['title']) ?>"
                                     onerror="this.onerror=null;this.src='<?= e(product_image_url('')) ?>';"
                                     class="w-full h-full object-cover"/>
                            </div>

                            <div class="flex-1 min-w-0 space-y-1">
                                <div class="flex items-start justify-between gap-2">
                                    <h3 class="font-bold text-sm sm:text-base text-foreground line-clamp-1 m-0">
                                        <a href="<?= base_url('/shop/product/' . (int)$it['productId']) ?>" class="hover:text-amber-800 transition"><?= e($it['title']) ?></a>
                                    </h3>
                                    <button type="button" class="cart-remove-btn"
                                            onclick="removeFullCartItem(<?= (int)$it['productId'] ?>)" title="Remove item" aria-label="Remove item">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
                                    </button>
                                </div>
                                <p class="text-xs text-muted-foreground font-medium m-0">Unit Price: <?= formatCurrency($p) ?></p>

                                <div class="flex items-center justify-between pt-2">
                                    <!-- Stepper -->
                                    <div class="qty-stepper-lux" style="height:34px;">
                                        <button type="button" class="qty-stepper-btn" style="width:30px;"
                                                onclick="updateFullCartQty(<?= (int)$it['productId'] ?>, <?= max(1, (int)$it['quantity'] - 1) ?>)">
                                            -
                                        </button>
                                        <span class="qty-stepper-val text-xs" style="width:30px;"><?= (int)$it['quantity'] ?></span>
                                        <button type="button" class="qty-stepper-btn" style="width:30px;"
                                                onclick="updateFullCartQty(<?= (int)$it['productId'] ?>, <?= (int)$it['quantity'] + 1 ?>)">
                                            +
                                        </button>
                                    </div>

                                    <div class="text-right">
                                        <span class="font-display text-base sm:text-lg font-extrabold text-foreground block"><?= formatCurrency($lineTotal) ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach ?>
                </div>
            </div>

            <!-- Right 1 Col: Summary Card -->
            <div class="lg:col-span-1 space-y-4 sticky top-28">
                <!-- Promo Code Box -->
                <div class="card-lux p-5 space-y-3">
                    <label class="text-xs font-extrabold uppercase tracking-widest text-muted-foreground block">Atelier Privilege Code</label>
                    <div class="flex gap-2">
                        <input type="text" id="fullCartCouponInput" placeholder="Promo code (e.g. WELCOME20)"
                               class="form-input-lux text-xs uppercase font-bold flex-1" style="height:2.6rem;"/>
                        <button type="button" onclick="applyFullCartCoupon()" class="btn-lux btn-lux-outline btn-lux-sm px-4">
                            Apply
                        </button>
                    </div>
                    <div id="fullCartCouponResult" class="text-xs font-semibold hidden"></div>
                </div>

                <!-- Financial Breakdown -->
                <div class="card-lux p-6 space-y-4">
                    <h3 class="font-display text-lg font-extrabold text-foreground m-0 pb-3 border-b border-border">Order Summary</h3>

                    <div class="space-y-2.5 text-xs">
                        <div class="flex justify-between text-muted-foreground">
                            <span>Bag Subtotal</span>
                            <span class="font-bold text-foreground" id="fullCartSubtotal"><?= formatCurrency($subtotal) ?></span>
                        </div>
                        <div id="fullCartDiscountRow" class="flex justify-between text-emerald-700 font-bold" style="display:none;">
                            <span>Promo Discount</span>
                            <span id="fullCartDiscountVal">-₹0.00</span>
                        </div>
                        <div class="flex justify-between text-muted-foreground">
                            <span>Estimated Express Delivery</span>
                            <span class="font-bold" id="fullCartShipping">
                                <?= $shipping === 0 ? '<span class="text-emerald-700 font-bold">FREE</span>' : formatCurrency($shipping) ?>
                            </span>
                        </div>
                        <div class="flex justify-between text-muted-foreground">
                            <span>Applicable Taxes (GST 5%)</span>
                            <span class="font-bold text-foreground" id="fullCartTax"><?= formatCurrency($tax) ?></span>
                        </div>
                        <div class="pt-3 border-t border-border flex justify-between items-baseline">
                            <div>
                                <strong class="text-sm font-extrabold text-foreground block">Estimated Grand Total</strong>
                                <span class="text-[11px] text-muted-foreground">Including all duties & taxes</span>
                            </div>
                            <span class="font-display text-2xl font-black text-foreground" id="fullCartTotal"><?= formatCurrency($total) ?></span>
                        </div>
                    </div>

                    <div class="pt-2">
                        <a href="<?= base_url('/shop/checkout') ?>" class="btn-lux btn-lux-primary w-full text-center">
                            Proceed to Secure Checkout &rarr;
                        </a>
                    </div>

                    <!-- Payment Assurance Badges -->
                    <div class="pt-2 text-center border-t border-border space-y-2">
                        <span class="text-[11px] text-muted-foreground block">🔒 Certified 256-Bit SSL Encrypted</span>
                        <div class="flex items-center justify-center gap-2 opacity-75">
                            <img src="https://img.icons8.com/color/48/visa.png" alt="Visa" style="height:14px;width:auto;display:inline-block;"/>
                            <img src="https://img.icons8.com/color/48/mastercard.png" alt="Mastercard" style="height:14px;width:auto;display:inline-block;"/>
                            <img src="https://img.icons8.com/color/48/upi.png" alt="UPI" style="height:14px;width:auto;display:inline-block;"/>
                            <img src="https://img.icons8.com/color/48/rupay.png" alt="RuPay" style="height:14px;width:auto;display:inline-block;"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif ?>
</div>

<script>
const __UID = '<?= (int)($user['id'] ?? 0) ?>';
let __fullDiscount = 0;

async function updateFullCartQty(productId, newQty) {
    if (!__UID || newQty < 1) return;
    try {
        await CartApi.updateQty(__UID, productId, newQty);
        location.reload();
    } catch(e) {}
}

async function removeFullCartItem(productId) {
    if (!__UID) return;
    try {
        await CartApi.remove(__UID, productId);
        location.reload();
    } catch(e) {}
}

async function applyFullCartCoupon() {
    const inp = document.getElementById('fullCartCouponInput');
    const resBox = document.getElementById('fullCartCouponResult');
    const code = inp ? inp.value.trim().toUpperCase() : '';
    if (!code) return;

    const subtotal = <?= $subtotal ?>;
    try {
        const res = await CouponApi.apply(code, subtotal);
        const disc = res.data.discountAmount || 0;
        __fullDiscount = disc;
        resBox.className = 'text-xs font-bold text-emerald-700 block';
        resBox.textContent = `Coupon Applied! Saved ₹${disc.toFixed(2)}`;

        document.getElementById('fullCartDiscountRow').style.display = 'flex';
        document.getElementById('fullCartDiscountVal').textContent = `-₹${disc.toFixed(2)}`;

        const shipping = subtotal >= 1000 ? 0 : 99;
        const newSub = Math.max(0, subtotal - disc);
        const tax = Math.round(newSub * 0.05 * 100) / 100;
        const newTotal = newSub + shipping + tax;

        document.getElementById('fullCartTax').textContent = formatCurrency(tax);
        document.getElementById('fullCartTotal').textContent = formatCurrency(newTotal);

        sessionStorage.setItem('applied_coupon', JSON.stringify(res.data));
        toast('Privilege Code Applied', res.message, 'success');
    } catch(err) {
        resBox.className = 'text-xs font-bold text-rose-600 block';
        resBox.textContent = err.message || 'Invalid promotion code';
    }
}
</script>

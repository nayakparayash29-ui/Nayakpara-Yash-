<?php
if (!isset($viewContent)) $viewContent = __FILE__;
$pageTitle = 'Create account';
?>
<div class="auth-intro">
    <h1>Create account</h1>
    <p>Save your bag, addresses, and order history.</p>
</div>

<form id="registerForm" class="auth-form" novalidate>
    <div id="registerAlert" class="form-alert hidden" role="alert"></div>

    <div class="auth-field">
        <label for="userName">Username</label>
        <input id="userName" name="userName" type="text" placeholder="Your name" required class="form-input-lux" autocomplete="username"/>
    </div>

    <div class="auth-field">
        <label for="email">Email</label>
        <input id="email" name="email" type="email" placeholder="you@example.com" required class="form-input-lux" autocomplete="email"/>
    </div>

    <div class="auth-field">
        <label for="password">Password</label>
        <div class="input-password-wrap">
            <input id="password" name="password" type="password" placeholder="At least 4 characters" required minlength="4" class="form-input-lux" autocomplete="new-password"/>
            <button type="button" class="input-password-toggle" data-toggle-password="password" aria-label="Show password">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            </button>
        </div>
        <p class="auth-hint">Use at least 4 characters.</p>
    </div>

    <div class="auth-field">
        <label for="confirmPassword">Confirm password</label>
        <div class="input-password-wrap">
            <input id="confirmPassword" type="password" placeholder="Re-enter password" required minlength="4" class="form-input-lux" autocomplete="new-password"/>
            <button type="button" class="input-password-toggle" data-toggle-password="confirmPassword" aria-label="Show password">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            </button>
        </div>
    </div>

    <label class="auth-check" for="termsCheck">
        <input type="checkbox" id="termsCheck" required/>
        <span>I agree to the <a href="<?= base_url('/shop/policies/terms') ?>">Terms</a> and <a href="<?= base_url('/shop/policies/privacy') ?>">Privacy Policy</a>.</span>
    </label>

    <button type="submit" id="registerBtn" class="btn-lux btn-lux-primary w-full">Create account</button>
</form>

<p class="auth-switch">
    Already have an account? <a href="<?= base_url('/auth/login') ?>">Sign in</a>
</p>

<script>
function showRegisterError(message) {
    const alert = document.getElementById('registerAlert');
    alert.textContent = message;
    alert.classList.remove('hidden');
}

document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    document.getElementById('registerAlert').classList.add('hidden');

    const form = e.target;
    const userName = form.userName.value.trim();
    const email = form.email.value.trim();
    const password = document.getElementById('password').value;
    const confirm = document.getElementById('confirmPassword').value;

    if (!userName || !email || !password) {
        showRegisterError('Fill in your username, email, and password.');
        return;
    }
    if (password.length < 4) {
        showRegisterError('Password must be at least 4 characters.');
        return;
    }
    if (password !== confirm) {
        showRegisterError('Password and confirmation do not match.');
        return;
    }
    if (!document.getElementById('termsCheck').checked) {
        showRegisterError('Accept the Terms and Privacy Policy to create an account.');
        return;
    }

    const btn = document.getElementById('registerBtn');
    btn.disabled = true;
    btn.textContent = 'Creating account...';

    try {
        await Auth.register(userName, email, password);
        toast('Account created', 'You can sign in with your new account.', 'success');
        window.location.href = (window.APP_BASE || '') + '/auth/login';
    } catch (err) {
        btn.disabled = false;
        btn.textContent = 'Create account';
        showRegisterError(err.message || 'Could not create the account.');
    }
});
</script>

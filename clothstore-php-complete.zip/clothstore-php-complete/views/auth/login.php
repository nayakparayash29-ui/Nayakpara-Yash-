<?php
if (!isset($viewContent)) $viewContent = __FILE__;
$pageTitle = 'Sign in';
?>
<div class="auth-intro">
    <h1>Sign in</h1>
    <p>Use the email and password for your ClothStore account.</p>
</div>

<form id="loginForm" class="auth-form" novalidate>
    <div id="loginAlert" class="form-alert hidden" role="alert"></div>

    <div class="auth-field">
        <label for="email">Email</label>
        <input id="email" name="email" type="email" placeholder="you@example.com" required autocomplete="email" class="form-input-lux"/>
    </div>

    <div class="auth-field">
        <div class="auth-label-row">
            <label for="password">Password</label>
            <a href="<?= base_url('/auth/forgot-password') ?>" class="auth-inline-link">Forgot password?</a>
        </div>
        <div class="input-password-wrap">
            <input id="password" name="password" type="password" placeholder="Enter your password" required autocomplete="current-password" class="form-input-lux"/>
            <button type="button" class="input-password-toggle" data-toggle-password="password" aria-label="Show password">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            </button>
        </div>
    </div>

    <button type="submit" id="loginBtn" class="btn-lux btn-lux-primary w-full">Sign in</button>
</form>

<p class="auth-switch">
    New here? <a href="<?= base_url('/auth/register') ?>">Create an account</a>
</p>

<script>
function showLoginError(message) {
    const alert = document.getElementById('loginAlert');
    alert.textContent = message;
    alert.classList.remove('hidden');
}

document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const alert = document.getElementById('loginAlert');
    alert.classList.add('hidden');

    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    if (!email || !password) {
        showLoginError('Enter both your email and password.');
        return;
    }

    const btn = document.getElementById('loginBtn');
    btn.disabled = true;
    btn.textContent = 'Signing in...';

    try {
        const res = await Auth.login(email, password);
        toast('Signed in', 'Welcome back, ' + (res.data.user.userName || ''), 'success');
        const role = res.data.user.role;
        const base = window.APP_BASE || '';
        window.location.href = role === 'admin' ? base + '/admin/dashboard' : base + '/shop/home';
    } catch (err) {
        btn.disabled = false;
        btn.textContent = 'Sign in';
        showLoginError(err.message || 'Could not sign in. Check your email and password.');
    }
});
</script>

<?php
if (!isset($viewContent)) $viewContent = __FILE__;
$pageTitle = 'Reset password';
?>
<div class="auth-intro">
    <h1>Reset password</h1>
    <p>Enter the email on your account, then choose a new password.</p>
</div>

<form id="forgotStep1Form" class="auth-form">
    <div id="resetAlert" class="form-alert hidden" role="alert"></div>
    <div class="auth-field">
        <label for="recoveryEmail">Email</label>
        <input type="email" id="recoveryEmail" required placeholder="you@example.com" class="form-input-lux" autocomplete="email"/>
    </div>
    <button type="submit" id="step1Btn" class="btn-lux btn-lux-primary w-full">Continue</button>
</form>

<form id="forgotStep2Form" class="auth-form hidden">
    <div id="resetAlert2" class="form-alert hidden" role="alert"></div>
    <div class="form-alert form-alert-success" role="status">
        Account found for <strong id="verifiedEmailDisplay"></strong>. Choose a new password.
    </div>
    <div class="auth-field">
        <label for="resetNewPass">New password</label>
        <div class="input-password-wrap">
            <input type="password" id="resetNewPass" required minlength="4" placeholder="At least 4 characters" class="form-input-lux" autocomplete="new-password"/>
            <button type="button" class="input-password-toggle" data-toggle-password="resetNewPass" aria-label="Show password">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            </button>
        </div>
    </div>
    <div class="auth-field">
        <label for="resetCnfPass">Confirm new password</label>
        <div class="input-password-wrap">
            <input type="password" id="resetCnfPass" required minlength="4" placeholder="Re-enter password" class="form-input-lux" autocomplete="new-password"/>
            <button type="button" class="input-password-toggle" data-toggle-password="resetCnfPass" aria-label="Show password">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            </button>
        </div>
    </div>
    <button type="submit" id="step2Btn" class="btn-lux btn-lux-primary w-full">Save password</button>
</form>

<p class="auth-switch">
    <a href="<?= base_url('/auth/login') ?>">Back to sign in</a>
</p>

<script>
let verifiedEmail = '';

function showResetError(id, message) {
    const alert = document.getElementById(id);
    alert.textContent = message;
    alert.classList.remove('hidden');
}

document.getElementById('forgotStep1Form').addEventListener('submit', async (e) => {
    e.preventDefault();
    document.getElementById('resetAlert').classList.add('hidden');
    const email = document.getElementById('recoveryEmail').value.trim();
    if (!email) {
        showResetError('resetAlert', 'Enter the email on your account.');
        return;
    }

    const btn = document.getElementById('step1Btn');
    btn.disabled = true;
    btn.textContent = 'Checking email...';

    try {
        await Auth.forgotPassword(email);
        verifiedEmail = email;
        document.getElementById('verifiedEmailDisplay').textContent = email;
        document.getElementById('forgotStep1Form').classList.add('hidden');
        document.getElementById('forgotStep2Form').classList.remove('hidden');
    } catch (err) {
        btn.disabled = false;
        btn.textContent = 'Continue';
        showResetError('resetAlert', err.message || 'No account was found for that email.');
    }
});

document.getElementById('forgotStep2Form').addEventListener('submit', async (e) => {
    e.preventDefault();
    document.getElementById('resetAlert2').classList.add('hidden');
    const next = document.getElementById('resetNewPass').value;
    const confirm = document.getElementById('resetCnfPass').value;

    if (next.length < 4) {
        showResetError('resetAlert2', 'Password must be at least 4 characters.');
        return;
    }
    if (next !== confirm) {
        showResetError('resetAlert2', 'The two passwords do not match.');
        return;
    }

    const btn = document.getElementById('step2Btn');
    btn.disabled = true;
    btn.textContent = 'Saving password...';

    try {
        const res = await Auth.forgotPassword(verifiedEmail, next);
        toast('Password updated', res.message || 'You can sign in with your new password.', 'success');
        window.location.href = (window.APP_BASE || '') + '/auth/login';
    } catch (err) {
        btn.disabled = false;
        btn.textContent = 'Save password';
        showResetError('resetAlert2', err.message || 'Could not update the password.');
    }
});
</script>

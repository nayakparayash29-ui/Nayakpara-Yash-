<?php
/**
 * Auth Controller (matches auth-controller.js)
 */
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../models/User.php';

class AuthController {
    private $userModel;

    public function __construct() {
        $this->userModel = new UserModel();
    }

    // POST /api/auth/register
    public function register() {
        $data = getJsonBody();
        $userName   = trim($data['userName'] ?? '');
        $email      = trim($data['email'] ?? '');
        $password   = $data['password'] ?? '';
        $adminSecret = $_SERVER['HTTP_X_ADMIN_SECRET'] ?? $data['adminSecret'] ?? null;

        if (!$userName || !$email || !$password) {
            jsonResponse(false, 'Missing required fields', null, 400);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(false, 'Invalid email format');
        }
        if (strlen($password) < 4) {
            jsonResponse(false, 'Password must be at least 4 characters');
        }

        if ($this->userModel->findByEmail($email)) {
            jsonResponse(false, 'User Already exists with the same email! Please try again');
        }
        if ($this->userModel->findByUserName($userName)) {
            jsonResponse(false, 'User Already exists with the same username! Please try again');
        }

        $role = ($adminSecret && $adminSecret === ADMIN_SIGNUP_SECRET) ? 'admin' : 'user';
        $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

        $id = $this->userModel->create([
            'userName' => $userName,
            'email'    => $email,
            'password' => $hash,
            'role'     => $role,
        ]);

        jsonResponse(true, 'Registration successful', ['id' => $id]);
    }

    // POST /api/auth/login
    public function login() {
        $data = getJsonBody();
        $email    = trim($data['email'] ?? '');
        $password = $data['password'] ?? '';

        if (!$email || !$password) {
            jsonResponse(false, 'Missing credentials', null, 400);
        }

        // Default admin bootstrap (matches server behavior: sanju123@gmail.com / sanju123)
        if ($email === 'sanju123@gmail.com' && $password === 'sanju123') {
            $user = $this->userModel->findByEmail($email);
            if (!$user) {
                $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
                $id = $this->userModel->create([
                    'userName' => 'admin',
                    'email'    => $email,
                    'password' => $hash,
                    'role'     => 'admin',
                ]);
                $user = $this->userModel->findById($id);
            } elseif ($user['role'] !== 'admin') {
                $this->userModel->update($user['id'], ['role' => 'admin']);
                $user = $this->userModel->findById($user['id']);
            }
            $this->loginUser($user);
            return;
        }

        $user = $this->userModel->findByEmail($email);
        if (!$user) {
            jsonResponse(false, "User doesn't exists! Please register first");
        }
        if (!password_verify($password, $user['password'])) {
            jsonResponse(false, 'Incorrect password! Please try again');
        }
        $this->loginUser($user);
    }

    private function loginUser($user) {
        setUserSession([
            'id'       => $user['id'],
            'email'    => $user['email'],
            'userName' => $user['userName'],
            'role'     => $user['role'],
        ]);
        // Emulate cookie token behaviour
        $payload = json_encode([
            'id'       => $user['id'],
            'role'     => $user['role'],
            'email'    => $user['email'],
            'userName' => $user['userName'],
            'exp'      => time() + 3600,
        ]);
        $token = base64_encode($payload);
        setcookie('token', $token, [
            'expires'  => time() + 3600,
            'path'     => '/',
            'httponly' => true,
            'secure'   => false,
        ]);
        jsonResponse(true, 'Logged in successfully', [
            'user' => [
                'id'       => (string)$user['id'],
                'email'    => $user['email'],
                'userName' => $user['userName'],
                'role'     => $user['role'],
            ],
        ]);
    }

    // POST /api/auth/logout
    public function logout() {
        logoutUserSession();
        setcookie('token', '', time() - 3600, '/');
        jsonResponse(true, 'Logged out successfully!');
    }

    // GET /api/auth/check-auth
    public function checkAuth() {
        if (isLoggedIn()) {
            jsonResponse(true, 'Authenticated user!', currentUser());
        }
        jsonResponse(false, 'Unauthorised user!', null, 401);
    }

    // POST /api/auth/update-password
    public function updatePassword() {
        if (!isLoggedIn()) {
            jsonResponse(false, 'Please log in first', null, 401);
        }
        $userSession = currentUser();
        $dbUser = $this->userModel->findById((int)$userSession['id']);
        if (!$dbUser) {
            jsonResponse(false, 'User not found', null, 404);
        }

        $data = getJsonBody();
        $currentPassword = $data['currentPassword'] ?? '';
        $newPassword     = $data['newPassword'] ?? '';
        $confirmPassword = $data['confirmPassword'] ?? '';

        if (!$currentPassword || !$newPassword) {
            jsonResponse(false, 'Current password and new password are required', null, 400);
        }
        if ($newPassword !== $confirmPassword) {
            jsonResponse(false, 'New passwords do not match', null, 400);
        }
        if (strlen($newPassword) < 4) {
            jsonResponse(false, 'Password must be at least 4 characters', null, 400);
        }
        if (!password_verify($currentPassword, $dbUser['password'])) {
            jsonResponse(false, 'Current password is incorrect', null, 400);
        }

        $hash = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 12]);
        $this->userModel->update($dbUser['id'], ['password' => $hash]);

        jsonResponse(true, 'Password updated successfully!');
    }

    // POST /api/auth/update-profile
    public function updateProfile() {
        if (!isLoggedIn()) {
            jsonResponse(false, 'Please log in first', null, 401);
        }
        $userSession = currentUser();
        $dbUser = $this->userModel->findById((int)$userSession['id']);
        if (!$dbUser) {
            jsonResponse(false, 'User not found', null, 404);
        }

        $data = getJsonBody();
        $userName = trim($data['userName'] ?? '');
        $email    = trim($data['email'] ?? '');

        if (!$userName || !$email) {
            jsonResponse(false, 'Username and email are required', null, 400);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(false, 'Invalid email format', null, 400);
        }

        // Check if username taken by another user
        $existing = $this->userModel->findByUserName($userName);
        if ($existing && (int)$existing['id'] !== (int)$dbUser['id']) {
            jsonResponse(false, 'Username is already taken', null, 400);
        }

        // Check if email taken by another user
        $existingEmail = $this->userModel->findByEmail($email);
        if ($existingEmail && (int)$existingEmail['id'] !== (int)$dbUser['id']) {
            jsonResponse(false, 'Email is already taken', null, 400);
        }

        $this->userModel->update($dbUser['id'], [
            'userName' => $userName,
            'email'    => $email,
        ]);

        // Update session
        setUserSession([
            'id'       => $dbUser['id'],
            'email'    => $email,
            'userName' => $userName,
            'role'     => $dbUser['role'],
        ]);

        jsonResponse(true, 'Profile updated successfully!', [
            'userName' => $userName,
            'email'    => $email,
        ]);
    }

    // POST /api/auth/forgot-password
    public function forgotPassword() {
        $data = getJsonBody();
        $email = trim($data['email'] ?? '');
        $newPassword = $data['newPassword'] ?? '';

        if (!$email) {
            jsonResponse(false, 'Please enter your registered email address', null, 400);
        }

        $user = $this->userModel->findByEmail($email);
        if (!$user) {
            jsonResponse(false, 'No account found with this email address', null, 404);
        }

        // If new password provided, reset it directly
        if (!empty($newPassword)) {
            if (strlen($newPassword) < 4) {
                jsonResponse(false, 'New password must be at least 4 characters', null, 400);
            }
            $hash = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 12]);
            $this->userModel->update($user['id'], ['password' => $hash]);
            jsonResponse(true, 'Password has been reset successfully! You can now log in.');
        }

        // Otherwise return simulated reset instruction
        jsonResponse(true, 'A password reset token has been verified for this account.', [
            'email' => $email,
            'readyToReset' => true
        ]);
    }
}


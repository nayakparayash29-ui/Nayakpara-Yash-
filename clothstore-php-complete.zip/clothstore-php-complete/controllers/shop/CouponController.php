<?php
/**
 * Shop Coupon Controller
 * Validates promo codes during cart and checkout
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../models/Coupon.php';

class ShopCouponController {
    private $couponModel;

    public function __construct() {
        $this->couponModel = new CouponModel();
    }

    // POST /api/shop/coupon/apply
    public function apply() {
        $body = getJsonBody();
        $code = strtoupper(trim($body['code'] ?? ''));
        $subtotal = (float)($body['subtotal'] ?? 0);

        if (!$code) {
            jsonResponse(false, 'Please enter a coupon code', null, 400);
        }

        $coupon = $this->couponModel->findByCode($code);
        if (!$coupon) {
            jsonResponse(false, 'Invalid coupon code', null, 404);
        }

        if ($coupon['status'] !== 'active') {
            jsonResponse(false, 'This coupon is no longer active', null, 400);
        }

        if (!empty($coupon['expiry']) && strtotime($coupon['expiry']) < strtotime(date('Y-m-d'))) {
            jsonResponse(false, 'This coupon has expired', null, 400);
        }

        $minPurchase = (float)($coupon['minPurchase'] ?? 0);
        if ($subtotal < $minPurchase) {
            jsonResponse(false, "Minimum purchase of ₹{$minPurchase} required for this coupon", null, 400);
        }

        // Calculate discount
        $discountAmount = 0;
        $val = (float)$coupon['value'];
        if ($coupon['type'] === 'percent') {
            $discountAmount = round(($subtotal * $val) / 100, 2);
        } else {
            $discountAmount = min($val, $subtotal);
        }

        jsonResponse(true, "Coupon {$coupon['code']} applied successfully!", [
            'code' => $coupon['code'],
            'type' => $coupon['type'],
            'value' => $val,
            'discountAmount' => $discountAmount,
            'description' => $coupon['description'] ?? ''
        ]);
    }
}

<?php
/**
 * Shop Order Controller (matches shop/order-controller.js)
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../models/Order.php';
require_once __DIR__ . '/../../models/Cart.php';
require_once __DIR__ . '/../../models/Product.php';

class ShopOrderController {
    private $orderModel;
    private $cartModel;
    private $productModel;

    public function __construct() {
        $this->orderModel   = new OrderModel();
        $this->cartModel    = new CartModel();
        $this->productModel = new ProductModel();
    }

    // POST /api/shop/order
    public function createOrder() {
        requireLogin();
        $auth = currentUser();
        $data = getJsonBody();
        $data['userId'] = $auth['id'];
        $id = $this->orderModel->create($data);
        $order = $this->orderModel->findById($id);
        jsonResponse(true, '', ['orderId' => (string)$id, 'data' => $order], 201);
    }

    // POST /api/shop/order/capture
    public function capturePayment() {
        requireLogin();
        $data = getJsonBody();
        $orderId = $data['orderId'] ?? null;
        $order = $this->orderModel->findById($orderId);
        if (!$order) jsonResponse(false, 'Order can not be found', null, 404);

        // Update order
        $this->orderModel->update($orderId, [
            'paymentStatus'   => 'paid',
            'orderStatus'     => 'confirmed',
            'orderUpdateDate' => date('Y-m-d H:i:s'),
        ]);

        // Reduce stock
        foreach ($order['cartItems'] as $item) {
            $p = $this->productModel->findById($item['productId']);
            if (!$p) continue;
            $newStock = max(0, (int)$p['totalStock'] - (int)$item['quantity']);
            $this->productModel->update($p['id'], ['totalStock' => $newStock]);
        }

        // Clear cart
        if (!empty($order['cartId'])) {
            $this->cartModel->deleteCart($order['cartId']);
        } else {
            $this->cartModel->deleteCartByUser($order['userId']);
        }

        $order = $this->orderModel->findById($orderId);
        jsonResponse(true, 'Order confirmed', $order);
    }

    // GET /api/shop/order/user/:userId
    public function getAllOrdersByUser($userId) {
        requireLogin();
        $auth = currentUser();
        if ($auth['role'] !== 'admin' && $auth['id'] != $userId) {
            $userId = $auth['id'];
        }
        $orders = $this->orderModel->findByUserId($userId);
        if (empty($orders)) jsonResponse(false, 'No orders found!', null, 404);
        jsonResponse(true, '', $orders);
    }

    // GET /api/shop/order/:id
    public function getOrderDetails($id) {
        requireLogin();
        $auth = currentUser();
        $order = $this->orderModel->findById($id);
        if (!$order) jsonResponse(false, 'Order not found!', null, 404);
        if ($auth['role'] !== 'admin' && $order['userId'] != $auth['id']) {
            jsonResponse(false, 'Unauthorised!', null, 403);
        }
        jsonResponse(true, '', $order);
    }

    // POST /api/shop/order/stripe-checkout
    public function createStripeCheckoutSession() {
        requireLogin();
        require_once __DIR__ . '/../../includes/stripe.php';
        $auth = currentUser();
        $data = getJsonBody();
        if (stripeSecretKey() === '') {
            jsonResponse(false, 'Stripe is not ready yet. Add the secret key in Admin → Settings → Payment Gateways.', null, 400);
        }
        $data['userId'] = $auth['id'];
        $data['orderStatus']    = 'pending';
        $data['paymentMethod']  = 'stripe';
        $data['paymentStatus']  = 'pending';
        $data['orderDate']      = date('Y-m-d H:i:s');
        $data['orderUpdateDate']= date('Y-m-d H:i:s');

        $id = $this->orderModel->create($data);
        [$code, $session] = stripeCreateCheckoutSession($id, $data['totalAmount'] ?? 0, 'inr');
        if ($code < 200 || $code >= 300 || empty($session['url'])) {
            $this->orderModel->delete($id);
            $message = $session['error']['message'] ?? 'Stripe could not start the card payment.';
            jsonResponse(false, $message, null, 400);
        }
        $this->orderModel->update($id, [
            'paymentId' => $session['id'] ?? null,
            'orderUpdateDate' => date('Y-m-d H:i:s'),
        ]);
        jsonResponse(true, '', [
            'sessionId' => $session['id'],
            'url'       => $session['url'],
            'orderId'   => (string)$id,
        ]);
    }

    // POST /api/shop/order/stripe-verify
    public function verifyStripeSession() {
        requireLogin();
        require_once __DIR__ . '/../../includes/stripe.php';
        $data = getJsonBody();
        $sessionId = trim((string)($data['sessionId'] ?? ''));
        if (!preg_match('/^cs_(test|live)_/', $sessionId)) {
            jsonResponse(false, 'Session not found', null, 404);
        }
        [$code, $session] = stripeApi('GET', '/checkout/sessions/' . rawurlencode($sessionId));
        if ($code !== 200 || ($session['payment_status'] ?? '') !== 'paid') {
            jsonResponse(false, $session['error']['message'] ?? 'Payment is not completed yet.', null, 400);
        }
        $orderId = $session['metadata']['order_id'] ?? $session['client_reference_id'] ?? '';
        $order = $this->orderModel->findById($orderId);
        $auth = currentUser();
        if (!$order || ($auth['role'] !== 'admin' && (string)$order['userId'] !== (string)$auth['id'])) {
            jsonResponse(false, 'Order can not be found', null, 404);
        }
        $paid = fulfillStripeOrder($order);
        jsonResponse(true, '', [
            'paymentStatus' => 'paid',
            'orderId'       => (string)$paid['id'],
        ]);
    }
}

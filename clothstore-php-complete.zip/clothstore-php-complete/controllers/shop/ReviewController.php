<?php
/**
 * Shop Product Review Controller
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../models/Review.php';

class ShopReviewController {
    private $reviewModel;

    public function __construct() {
        $this->reviewModel = new ReviewModel();
    }

    // GET /api/shop/review/:productId
    public function getProductReviews($productId) {
        $list = $this->reviewModel->findByProduct($productId);
        $out = array_map(function($r) {
            $r['_id']         = (string)$r['id'];
            $r['productId']   = (string)$r['product_id'];
            $r['userId']      = (string)$r['user_id'];
            $r['reviewValue'] = (int)($r['reviewValue'] ?? 0);
            return $r;
        }, $list);
        jsonResponse(true, '', $out);
    }

    // POST /api/shop/review
    public function addReview() {
        requireLogin();
        $auth = currentUser();
        $data = getJsonBody();
        $data['userId']   = $auth['id'];
        $data['userName'] = $data['userName'] ?? $auth['userName'];
        $id = $this->reviewModel->create($data);
        $r = $this->reviewModel->findById($id);
        $r['_id']         = (string)$r['id'];
        $r['productId']   = (string)$r['product_id'];
        $r['userId']      = (string)$r['user_id'];
        $r['reviewValue'] = (int)($r['reviewValue'] ?? 0);
        jsonResponse(true, 'Review added successfully', $r, 201);
    }

    // PUT /api/shop/review/:id
    public function updateReview($id) {
        requireLogin();
        $auth = currentUser();
        $r = $this->reviewModel->findById($id);
        if (!$r) jsonResponse(false, 'Review not found', null, 404);
        if ($r['user_id'] != $auth['id'] && $auth['role'] !== 'admin') {
            jsonResponse(false, 'Unauthorised', null, 403);
        }
        $data = getJsonBody();
        $this->reviewModel->update($id, $data);
        $r = $this->reviewModel->findById($id);
        $r['_id']         = (string)$r['id'];
        $r['productId']   = (string)$r['product_id'];
        $r['userId']      = (string)$r['user_id'];
        $r['reviewValue'] = (int)($r['reviewValue'] ?? 0);
        jsonResponse(true, 'Review updated successfully', $r);
    }

    // DELETE /api/shop/review/:id
    public function deleteReview($id) {
        requireLogin();
        $auth = currentUser();
        $r = $this->reviewModel->findById($id);
        if (!$r) jsonResponse(false, 'Review not found', null, 404);
        if ($r['user_id'] != $auth['id'] && $auth['role'] !== 'admin') {
            jsonResponse(false, 'Unauthorised', null, 403);
        }
        $this->reviewModel->delete($id);
        jsonResponse(true, 'Review deleted successfully');
    }
}

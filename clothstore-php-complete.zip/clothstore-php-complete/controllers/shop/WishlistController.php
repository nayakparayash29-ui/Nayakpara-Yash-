<?php
/**
 * Shop Wishlist Controller
 * REST endpoints for customer wishlist management
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../models/Wishlist.php';
require_once __DIR__ . '/../../models/Product.php';

class ShopWishlistController {
    private $wishlistModel;
    private $productModel;

    public function __construct() {
        $this->wishlistModel = new WishlistModel();
        $this->productModel = new ProductModel();
    }

    private function getAuthUserId() {
        if (!isLoggedIn()) {
            jsonResponse(false, 'Please sign in to access your wishlist', null, 401);
        }
        $user = currentUser();
        return (int)$user['id'];
    }

    // GET /api/shop/wishlist
    public function getWishlist() {
        $userId = $this->getAuthUserId();
        $items = $this->wishlistModel->getByUserId($userId);
        $count = count($items);
        $ids = array_map(function($it) { return (int)$it['id']; }, $items);

        jsonResponse(true, 'Wishlist retrieved', [
            'count' => $count,
            'items' => $items,
            'productIds' => $ids
        ]);
    }

    // POST /api/shop/wishlist/toggle
    public function toggleWishlist() {
        $userId = $this->getAuthUserId();
        $body = getJsonBody();
        $productId = (int)($body['productId'] ?? 0);

        if ($productId <= 0) {
            jsonResponse(false, 'Valid Product ID is required', null, 400);
        }

        $product = $this->productModel->findById($productId);
        if (!$product) {
            jsonResponse(false, 'Product not found', null, 404);
        }

        $added = $this->wishlistModel->toggle($userId, $productId);
        $count = $this->wishlistModel->countByUser($userId);

        jsonResponse(true, $added ? 'Added to your wishlist' : 'Removed from your wishlist', [
            'isWishlisted' => $added,
            'productId' => $productId,
            'count' => $count
        ]);
    }

    // DELETE /api/shop/wishlist/{productId}
    public function removeWishlist($productId) {
        $userId = $this->getAuthUserId();
        $productId = (int)$productId;

        $this->wishlistModel->remove($userId, $productId);
        $count = $this->wishlistModel->countByUser($userId);

        jsonResponse(true, 'Removed from wishlist', [
            'isWishlisted' => false,
            'productId' => $productId,
            'count' => $count
        ]);
    }
}

<?php
/**
 * Shop Address Controller
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../models/Address.php';

class ShopAddressController {
    private $addressModel;

    public function __construct() {
        $this->addressModel = new AddressModel();
    }

    // GET /api/shop/address/:userId
    public function getAddresses($userId) {
        requireLogin();
        $auth = currentUser();
        if (!$userId || $auth['id'] != $userId) {
            // Users can only see their own
            $userId = $auth['id'];
        }
        $list = $this->addressModel->findByUserId($userId);
        $out = array_map(function($a) {
            $a['_id']    = (string)$a['id'];
            $a['userId'] = (string)$a['user_id'];
            return $a;
        }, $list);
        jsonResponse(true, '', $out);
    }

    // POST /api/shop/address
    public function addAddress() {
        requireLogin();
        $auth = currentUser();
        $data = getJsonBody();
        $data['userId'] = $auth['id'];
        $id = $this->addressModel->create($data);
        $a = $this->addressModel->findById($id);
        $a['_id']    = (string)$a['id'];
        $a['userId'] = (string)$a['user_id'];
        jsonResponse(true, 'Address added successfully', $a, 201);
    }

    // PUT /api/shop/address/:id
    public function updateAddress($id) {
        requireLogin();
        $auth = currentUser();
        $existing = $this->addressModel->findById($id);
        if (!$existing || $existing['user_id'] != $auth['id']) {
            jsonResponse(false, 'Address not found', null, 404);
        }
        $data = getJsonBody();
        $this->addressModel->update($id, $data);
        $a = $this->addressModel->findById($id);
        $a['_id']    = (string)$a['id'];
        $a['userId'] = (string)$a['user_id'];
        jsonResponse(true, 'Address updated successfully', $a);
    }

    // DELETE /api/shop/address/:id
    public function deleteAddress($id) {
        requireLogin();
        $auth = currentUser();
        $deleted = $this->addressModel->delete($id, $auth['id']);
        if (!$deleted) jsonResponse(false, 'Address not found', null, 404);
        jsonResponse(true, 'Address deleted successfully');
    }
}

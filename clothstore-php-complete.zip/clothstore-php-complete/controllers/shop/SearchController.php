<?php
/**
 * Shop Search Controller
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../models/Product.php';

class ShopSearchController {
    private $productModel;

    public function __construct() {
        $this->productModel = new ProductModel();
    }

    // GET /api/shop/search?q=...
    public function search() {
        $q = trim($_GET['q'] ?? '');
        $sortBy = $_GET['sortBy'] ?? 'price-lowtohigh';
        $filters = [];
        if ($q !== '') $filters['search'] = $q;
        $products = $this->productModel->findAll($filters, $sortBy);
        $out = array_map(function($p) {
            $p['_id'] = (string)$p['id'];
            $p['price'] = (float)$p['price'];
            $p['salePrice'] = (float)$p['salePrice'];
            $p['totalStock'] = (int)$p['totalStock'];
            $p['averageReview'] = (float)$p['averageReview'];
            return $p;
        }, $products);
        jsonResponse(true, '', ['items' => $out, 'query' => $q]);
    }
}

<?php
/**
 * Shop Products Controller (public, user-side)
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../models/Product.php';

class ShopProductsController {
    private $productModel;

    public function __construct() {
        $this->productModel = new ProductModel();
    }

    // GET /api/shop/products?category=...&brand=...&sortBy=...
    public function getFilteredProducts() {
        $category = $_GET['category'] ?? '';
        $brand    = $_GET['brand'] ?? '';
        $sortBy   = $_GET['sortBy'] ?? 'price-lowtohigh';
        $filters = [];
        if ($category) $filters['category'] = $category;
        if ($brand)    $filters['brand']    = $brand;

        $products = $this->productModel->findAll($filters, $sortBy);
        $out = array_map(function($p) {
            $p['_id'] = (string)$p['id'];
            $p['price'] = (float)$p['price'];
            $p['salePrice'] = (float)$p['salePrice'];
            $p['totalStock'] = (int)$p['totalStock'];
            $p['averageReview'] = (float)$p['averageReview'];
            return $p;
        }, $products);
        jsonResponse(true, '', $out);
    }

    // GET /api/shop/products/:id
    public function getProductDetails($id) {
        $product = $this->productModel->findById($id);
        if (!$product) {
            jsonResponse(false, 'Product not found!', null, 404);
        }
        $product['_id'] = (string)$product['id'];
        $product['price'] = (float)$product['price'];
        $product['salePrice'] = (float)$product['salePrice'];
        $product['totalStock'] = (int)$product['totalStock'];
        $product['averageReview'] = (float)$product['averageReview'];

        // Include category/brand lists for filters page too
        $product['categories'] = $this->productModel->getDistinctCategories();
        $product['brands']     = $this->productModel->getDistinctBrands();

        jsonResponse(true, '', $product);
    }

    // GET /api/shop/products/meta (categories + brands)
    public function getMeta() {
        jsonResponse(true, '', [
            'categories' => $this->productModel->getDistinctCategories(),
            'brands'     => $this->productModel->getDistinctBrands(),
        ]);
    }
}

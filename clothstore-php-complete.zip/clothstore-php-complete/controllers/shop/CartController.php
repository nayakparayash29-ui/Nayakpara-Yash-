<?php
/**
 * Shop Cart Controller (matches cart-controller.js)
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../models/Cart.php';
require_once __DIR__ . '/../../models/Product.php';

class ShopCartController {
    private $cartModel;
    private $productModel;

    public function __construct() {
        $this->cartModel    = new CartModel();
        $this->productModel = new ProductModel();
    }

    // POST /api/shop/cart
    public function addToCart() {
        $data = getJsonBody();
        $userId    = $data['userId']    ?? null;
        $productId = $data['productId'] ?? null;
        $quantity  = (int)($data['quantity'] ?? 0);

        $authUser = currentUser();
        if ($authUser && !$userId) $userId = $authUser['id'];

        if (!$userId || !$productId || $quantity <= 0) {
            jsonResponse(false, 'Invalid data provided!', null, 400);
        }

        $product = $this->productModel->findById($productId);
        if (!$product) {
            jsonResponse(false, 'Product not found', null, 404);
        }

        $cart = $this->cartModel->getOrCreateCart($userId);
        $this->cartModel->addItem($cart['id'], $productId, $quantity);
        $populated = $this->cartModel->getPopulatedCart($userId);

        jsonResponse(true, '', $populated);
    }

    // GET /api/shop/cart/:userId
    public function fetchCartItems($userId) {
        $authUser = currentUser();
        if ($authUser && !$userId) $userId = $authUser['id'];
        if (!$userId) jsonResponse(false, 'User id is manadatory!', null, 400);

        $cart = $this->cartModel->getPopulatedCart($userId);
        if (!$cart) {
            jsonResponse(false, 'Cart not found!', null, 404);
        }
        jsonResponse(true, '', $cart);
    }

    // PUT /api/shop/cart
    public function updateCartItemQty() {
        $data = getJsonBody();
        $userId    = $data['userId']    ?? null;
        $productId = $data['productId'] ?? null;
        $quantity  = (int)($data['quantity'] ?? 0);

        $authUser = currentUser();
        if ($authUser && !$userId) $userId = $authUser['id'];

        if (!$userId || !$productId || $quantity <= 0) {
            jsonResponse(false, 'Invalid data provided!', null, 400);
        }
        $cart = $this->cartModel->findByUserId($userId);
        if (!$cart) jsonResponse(false, 'Cart not found!', null, 404);

        $existing = $this->cartModel->findCartItemIndex($cart['id'], $productId);
        if (!$existing) {
            jsonResponse(false, 'Cart item not present !', null, 404);
        }

        $this->cartModel->updateItemQty($cart['id'], $productId, $quantity);
        $populated = $this->cartModel->getPopulatedCart($userId);
        jsonResponse(true, '', $populated);
    }

    // DELETE /api/shop/cart/:userId/:productId
    public function deleteCartItem($userId, $productId) {
        $authUser = currentUser();
        if ($authUser && !$userId) $userId = $authUser['id'];
        if (!$userId || !$productId) {
            jsonResponse(false, 'Invalid data provided!', null, 400);
        }
        $cart = $this->cartModel->findByUserId($userId);
        if (!$cart) jsonResponse(false, 'Cart not found!', null, 404);
        $this->cartModel->removeItem($cart['id'], $productId);
        $populated = $this->cartModel->getPopulatedCart($userId);
        jsonResponse(true, '', $populated);
    }
}

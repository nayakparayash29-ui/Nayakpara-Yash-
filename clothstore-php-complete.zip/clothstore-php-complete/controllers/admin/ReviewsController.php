<?php
/**
 * Admin Reviews Controller
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../models/Review.php';

class AdminReviewsController {
    private $reviewModel;

    public function __construct() {
        $this->reviewModel = new ReviewModel();
    }

    // GET /api/admin/reviews
    public function getAllReviews() {
        requireAdmin();
        $reviews = $this->reviewModel->findAll();
        $out = array_map(function($r) {
            $r['_id'] = (string)$r['id'];
            $r['productId'] = (string)($r['product_id'] ?? '');
            $r['userId']    = (string)($r['user_id'] ?? '');
            $r['reviewValue'] = (int)($r['reviewValue'] ?? 0);
            return $r;
        }, $reviews);
        jsonResponse(true, '', $out);
    }

    // DELETE /api/admin/reviews/:id
    public function deleteReview($id) {
        requireAdmin();
        $r = $this->reviewModel->findById($id);
        if (!$r) jsonResponse(false, 'Review not found', null, 404);
        $this->reviewModel->delete($id);
        jsonResponse(true, 'Review deleted successfully');
    }
}

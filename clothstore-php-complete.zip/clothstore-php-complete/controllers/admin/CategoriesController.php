<?php
/**
 * Admin Categories & Brands Controller
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../models/Category.php';

class AdminCategoriesController {
    private $catModel;

    public function __construct() {
        $this->catModel = new CategoryModel();
    }

    public function getAll() {
        requireAdmin();
        $categories = $this->catModel->getCategories();
        $brands = $this->catModel->getBrands();
        jsonResponse(true, '', [
            'categories' => $categories,
            'brands'     => $brands,
        ]);
    }

    public function addCategory() {
        requireAdmin();
        $data = getJsonBody();
        $name = trim($data['name'] ?? '');
        $icon = trim($data['icon'] ?? '📦');
        if ($name === '') {
            jsonResponse(false, 'Category name is required', null, 400);
        }
        $created = $this->catModel->addCategory($name, $icon);
        jsonResponse(true, 'Category added successfully', $created, 201);
    }

    public function renameCategory() {
        requireAdmin();
        $data = getJsonBody();
        $oldName = trim($data['oldName'] ?? '');
        $newName = trim($data['newName'] ?? '');
        if ($oldName === '' || $newName === '') {
            jsonResponse(false, 'Old and new category names are required', null, 400);
        }
        $this->catModel->renameCategory($oldName, $newName);
        jsonResponse(true, 'Category renamed successfully');
    }

    public function deleteCategory() {
        requireAdmin();
        $data = getJsonBody();
        $name = trim($data['name'] ?? ($_GET['name'] ?? ''));
        if ($name === '') {
            jsonResponse(false, 'Category name is required', null, 400);
        }
        $this->catModel->deleteCategory($name);
        jsonResponse(true, 'Category deleted successfully');
    }

    public function addBrand() {
        requireAdmin();
        $data = getJsonBody();
        $name = trim($data['name'] ?? '');
        if ($name === '') {
            jsonResponse(false, 'Brand name is required', null, 400);
        }
        $created = $this->catModel->addBrand($name);
        jsonResponse(true, 'Brand added successfully', $created, 201);
    }

    public function renameBrand() {
        requireAdmin();
        $data = getJsonBody();
        $oldName = trim($data['oldName'] ?? '');
        $newName = trim($data['newName'] ?? '');
        if ($oldName === '' || $newName === '') {
            jsonResponse(false, 'Old and new brand names are required', null, 400);
        }
        $this->catModel->renameBrand($oldName, $newName);
        jsonResponse(true, 'Brand renamed successfully');
    }

    public function deleteBrand() {
        requireAdmin();
        $data = getJsonBody();
        $name = trim($data['name'] ?? ($_GET['name'] ?? ''));
        if ($name === '') {
            jsonResponse(false, 'Brand name is required', null, 400);
        }
        $this->catModel->deleteBrand($name);
        jsonResponse(true, 'Brand deleted successfully');
    }
}

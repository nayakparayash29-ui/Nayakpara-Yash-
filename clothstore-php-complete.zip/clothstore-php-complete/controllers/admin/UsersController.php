<?php
/**
 * Admin Users (Customers) Controller
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../models/User.php';

class AdminUsersController {
    private $userModel;

    public function __construct() {
        $this->userModel = new UserModel();
    }

    // GET /api/admin/users
    public function getAllUsers() {
        requireAdmin();
        $users = $this->userModel->getAll('user');
        $out = array_map(function($u) {
            unset($u['password']);
            $u['_id'] = (string)$u['id'];
            return $u;
        }, $users);
        jsonResponse(true, '', $out);
    }

    // GET /api/admin/users/:id
    public function getUserById($id) {
        requireAdmin();
        $u = $this->userModel->findById($id);
        if (!$u) jsonResponse(false, 'User not found', null, 404);
        unset($u['password']);
        $u['_id'] = (string)$u['id'];
        jsonResponse(true, '', $u);
    }

    // PUT /api/admin/users/:id
    public function updateUser($id) {
        requireAdmin();
        $data = getJsonBody();
        $u = $this->userModel->findById($id);
        if (!$u) jsonResponse(false, 'User not found', null, 404);
        if (isset($data['password']) && !empty($data['password'])) {
            $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => 12]);
        } else {
            unset($data['password']);
        }
        $this->userModel->update($id, $data);
        $u = $this->userModel->findById($id);
        unset($u['password']);
        $u['_id'] = (string)$u['id'];
        jsonResponse(true, 'User updated successfully', $u);
    }

    // DELETE /api/admin/users/:id
    public function deleteUser($id) {
        requireAdmin();
        $u = $this->userModel->findById($id);
        if (!$u) jsonResponse(false, 'User not found', null, 404);
        $this->userModel->delete($id);
        jsonResponse(true, 'User deleted successfully');
    }
}

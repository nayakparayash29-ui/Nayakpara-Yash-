<?php
/**
 * Admin Coupons Controller
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../models/Coupon.php';

class AdminCouponsController {
    private $couponModel;

    public function __construct() {
        $this->couponModel = new CouponModel();
    }

    public function getAll() {
        requireAdmin();
        $coupons = $this->couponModel->findAll();
        jsonResponse(true, '', $coupons);
    }

    public function create() {
        requireAdmin();
        $data = getJsonBody();
        if (empty($data['code'])) {
            jsonResponse(false, 'Coupon code is required', null, 400);
        }
        $existing = $this->couponModel->findByCode($data['code']);
        if ($existing) {
            jsonResponse(false, 'Coupon code already exists', null, 400);
        }
        $id = $this->couponModel->create($data);
        $coupon = $this->couponModel->findById($id);
        jsonResponse(true, 'Coupon created successfully', $coupon, 201);
    }

    public function update($id) {
        requireAdmin();
        $data = getJsonBody();
        $existing = $this->couponModel->findById($id);
        if (!$existing) {
            jsonResponse(false, 'Coupon not found', null, 404);
        }
        $updated = $this->couponModel->update($id, $data);
        jsonResponse(true, 'Coupon updated successfully', $updated);
    }

    public function delete($id) {
        requireAdmin();
        $existing = $this->couponModel->findById($id);
        if (!$existing) {
            jsonResponse(false, 'Coupon not found', null, 404);
        }
        $this->couponModel->delete($id);
        jsonResponse(true, 'Coupon deleted successfully');
    }

    public function toggle($id) {
        requireAdmin();
        $existing = $this->couponModel->findById($id);
        if (!$existing) {
            jsonResponse(false, 'Coupon not found', null, 404);
        }
        $updated = $this->couponModel->toggleStatus($id);
        jsonResponse(true, 'Coupon status updated', $updated);
    }
}

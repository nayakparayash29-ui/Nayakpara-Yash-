<?php
/**
 * Admin Settings Controller
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../models/Setting.php';

class AdminSettingsController {
    private $settingModel;

    public function __construct() {
        $this->settingModel = new SettingModel();
    }

    public function getSettings() {
        requireAdmin();
        $settings = $this->settingModel->getAll();
        jsonResponse(true, '', $settings);
    }

    public function saveSettings() {
        requireAdmin();
        $data = getJsonBody();
        if (empty($data) || !is_array($data)) {
            jsonResponse(false, 'Invalid payload', null, 400);
        }
        $this->settingModel->setMany($data);
        $settings = $this->settingModel->getAll();
        jsonResponse(true, 'Settings saved successfully', $settings);
    }

    public function resetSettings() {
        requireAdmin();
        $this->settingModel->seedDefaults();
        $settings = $this->settingModel->getAll();
        jsonResponse(true, 'Settings reset to default values', $settings);
    }
}

<?php
/**
 * Admin Orders Controller
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../models/Order.php';
require_once __DIR__ . '/../../models/Cart.php';
require_once __DIR__ . '/../../models/Product.php';

class AdminOrdersController {
    private $orderModel;
    private $cartModel;
    private $productModel;

    public function __construct() {
        $this->orderModel   = new OrderModel();
        $this->cartModel    = new CartModel();
        $this->productModel = new ProductModel();
    }

    // GET /api/admin/orders
    public function getAllOrders() {
        requireAdmin();
        $orders = $this->orderModel->findAll();
        jsonResponse(true, '', $orders);
    }

    // GET /api/admin/orders/:id
    public function getOrderDetails($id) {
        requireAdmin();
        $order = $this->orderModel->findById($id);
        if (!$order) jsonResponse(false, 'Order not found!', null, 404);
        jsonResponse(true, '', $order);
    }

    // PUT /api/admin/orders/:id
    public function updateOrderStatus($id) {
        requireAdmin();
        $data = getJsonBody();
        $existing = $this->orderModel->findById($id);
        if (!$existing) jsonResponse(false, 'Order not found!', null, 404);

        $update = [];
        foreach (['orderStatus', 'paymentStatus'] as $k) {
            if (isset($data[$k])) $update[$k] = $data[$k];
        }
        $update['orderUpdateDate'] = date('Y-m-d H:i:s');

        $updated = $this->orderModel->update($id, $update);
        jsonResponse(true, 'Order updated successfully', $updated);
    }

    // Helper analytics
    public function getAnalytics() {
        requireAdmin();
        $revenue = $this->orderModel->totalRevenue();
        $total = count($this->orderModel->findAll());
        $confirmed = $this->orderModel->countByStatus('confirmed');
        $pending   = $this->orderModel->countByStatus('pending');
        $shipped   = $this->orderModel->countByStatus('shipped');
        $delivered = $this->orderModel->countByStatus('delivered');
        $sales     = $this->orderModel->salesByDate(30);
        $top       = $this->orderModel->topSelling(5);
        jsonResponse(true, '', [
            'revenue'    => $revenue,
            'totalOrders'=> $total,
            'confirmed'  => $confirmed,
            'pending'    => $pending,
            'shipped'    => $shipped,
            'delivered'  => $delivered,
            'salesChart' => $sales,
            'topSelling' => $top,
        ]);
    }
}

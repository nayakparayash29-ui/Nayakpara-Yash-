<?php
/**
 * Admin Products Controller
 */
require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../models/Product.php';

class AdminProductsController {
    private $productModel;

    public function __construct() {
        $this->productModel = new ProductModel();
    }

    // POST /api/admin/products/upload
    public function uploadImage() {
        requireAdmin();
        $result = uploadFile('image');
        if (!$result['success']) {
            jsonResponse(false, $result['message'] ?? 'Upload failed');
        }
        $fileUrl = '/uploads/' . $result['filename'];
        jsonResponse(true, '', ['url' => $fileUrl]);
    }

    // POST /api/admin/products
    public function addProduct() {
        requireAdmin();
        $data = getJsonBody();

        $required = ['image', 'title', 'description', 'category', 'brand'];
        foreach ($required as $r) {
            if (empty($data[$r])) {
                jsonResponse(false, 'Missing required fields', null, 400);
            }
        }

        $product = [
            'image'         => $data['image'],
            'title'         => $data['title'],
            'description'   => $data['description'],
            'category'      => $data['category'],
            'brand'         => $data['brand'],
            'price'         => (float)($data['price'] ?? 0),
            'salePrice'     => (float)($data['salePrice'] ?? 0),
            'totalStock'    => (int)($data['totalStock'] ?? 0),
            'averageReview' => (float)($data['averageReview'] ?? 0),
        ];

        $id = $this->productModel->create($product);
        $product['id'] = (string)$id;
        jsonResponse(true, '', $product, 201);
    }

    // GET /api/admin/products
    public function fetchAll() {
        requireAdmin();
        $products = $this->productModel->findAll();
        // Format output like mongoose docs (_id string)
        $out = array_map(function($p) {
            $p['_id'] = (string)$p['id'];
            $p['price'] = (float)$p['price'];
            $p['salePrice'] = (float)$p['salePrice'];
            $p['totalStock'] = (int)$p['totalStock'];
            $p['averageReview'] = (float)$p['averageReview'];
            return $p;
        }, $products);
        jsonResponse(true, '', $out);
    }

    // PUT /api/admin/products/:id
    public function editProduct($id) {
        requireAdmin();
        $data = getJsonBody();
        $existing = $this->productModel->findById($id);
        if (!$existing) {
            jsonResponse(false, 'Product not found', null, 404);
        }
        $updated = $this->productModel->update($id, $data);
        $updated['_id'] = (string)$updated['id'];
        $updated['price'] = (float)$updated['price'];
        $updated['salePrice'] = (float)$updated['salePrice'];
        $updated['totalStock'] = (int)$updated['totalStock'];
        jsonResponse(true, '', $updated);
    }

    // DELETE /api/admin/products/:id
    public function deleteProduct($id) {
        requireAdmin();
        $existing = $this->productModel->findById($id);
        if (!$existing) {
            jsonResponse(false, 'Product not found', null, 404);
        }
        $this->productModel->delete($id);
        jsonResponse(true, 'Product delete successfully');
    }
}

<?php
/**
 * Common Feature Controller (homepage banners)
 */
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../models/Feature.php';

class FeatureController {
    private $featureModel;

    public function __construct() {
        $this->featureModel = new FeatureModel();
    }

    // GET /api/common/feature
    public function getAll() {
        $list = $this->featureModel->findAll();
        $out = array_map(function($f) {
            $f['_id'] = (string)$f['id'];
            return $f;
        }, $list);
        jsonResponse(true, '', $out);
    }

    // POST /api/common/feature (admin)
    public function add() {
        requireAdmin();
        $data = getJsonBody();
        if (empty($data['image'])) jsonResponse(false, 'Missing image', null, 400);
        $id = $this->featureModel->create($data['image']);
        $f = $this->featureModel->findById($id);
        $f['_id'] = (string)$f['id'];
        jsonResponse(true, 'Feature added', $f, 201);
    }

    // PUT /api/common/feature/:id
    public function update($id) {
        requireAdmin();
        $data = getJsonBody();
        $f = $this->featureModel->findById($id);
        if (!$f) jsonResponse(false, 'Not found', null, 404);
        if (isset($data['image'])) {
            $this->featureModel->update($id, $data['image']);
        }
        $f = $this->featureModel->findById($id);
        $f['_id'] = (string)$f['id'];
        jsonResponse(true, 'Feature updated', $f);
    }

    // DELETE /api/common/feature/:id
    public function delete($id) {
        requireAdmin();
        $f = $this->featureModel->findById($id);
        if (!$f) jsonResponse(false, 'Not found', null, 404);
        $this->featureModel->delete($id);
        jsonResponse(true, 'Feature deleted');
    }

    // POST /api/common/feature/upload
    public function upload() {
        requireAdmin();
        $result = uploadFile('image');
        if (!$result['success']) jsonResponse(false, $result['message'] ?? 'Upload failed');
        $fileUrl = '/uploads/' . $result['filename'];
        jsonResponse(true, '', ['url' => $fileUrl]);
    }
}

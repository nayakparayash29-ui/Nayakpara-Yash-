/* ============================================
   ClothStore PHP — Client-side JavaScript
   Handles: fetch API, toast notifications,
   dialogs, dropdowns, cart interactions
   ============================================ */
(function () {
    'use strict';

    const API_BASE = (window.APP_BASE || '') + '/api';

    // ============== Toast ==============
    function toast(title, msg, type = 'info') {
        const container = document.querySelector('.toast-container') || (() => {
            const el = document.createElement('div');
            el.className = 'toast-container';
            document.body.appendChild(el);
            return el;
        })();
        const el = document.createElement('div');
        el.className = `toast toast-${type}`;
        el.innerHTML = `
            <div>
                <p class="toast-title">${_esc(title)}</p>
                ${msg ? `<p class="toast-msg">${_esc(msg)}</p>` : ''}
            </div>
            <button class="btn-icon btn-ghost" aria-label="Close" style="margin-left:auto;flex:0 0 auto;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>`;
        container.appendChild(el);
        el.querySelector('button').addEventListener('click', () => el.remove());
        setTimeout(() => el.remove(), 4500);
    }
    window.toast = toast;

    function _esc(s) {
        if (s == null) return '';
        return String(s).replace(/[&<>"']/g, c => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[c]));
    }
    window._esc = _esc;

    function formatImageUrl(image) {
        if (!image) {
            return 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="500" viewBox="0 0 400 500" fill="#f1f5f9"><rect width="400" height="500" fill="#f8fafc"/><path d="M160 180 L200 200 L240 180 L270 230 L240 240 L240 330 L160 330 L160 240 L130 230 Z" fill="#cbd5e1"/><text x="50%" y="375" text-anchor="middle" font-family="sans-serif" font-size="14" fill="#94a3b8" font-weight="600">ClothShop</text></svg>');
        }
        const str = String(image).trim();
        if (/^(https?:|data:)/i.test(str)) {
            return str;
        }
        const base = window.APP_BASE || '';
        if (str.startsWith('/')) {
            return base + str;
        }
        if (str.startsWith('uploads/')) {
            return base + '/' + str;
        }
        return base + '/uploads/' + str;
    }
    window.formatImageUrl = formatImageUrl;

    // ============== HTTP ==============
    async function api(url, options = {}) {
        const full = url.startsWith('http') ? url : API_BASE + url;
        const opts = {
            credentials: 'include',
            headers: {
                'Accept': 'application/json',
            },
            ...options,
        };
        if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
            opts.headers['Content-Type'] = 'application/json';
            opts.body = JSON.stringify(options.body);
        }
        const res = await fetch(full, opts);
        const data = await res.json().catch(() => ({}));
        if (!res.ok || data.success === false) {
            const msg = data.message || `Request failed (${res.status})`;
            toast('Error', msg, 'error');
            throw new Error(msg);
        }
        return data;
    }
    window.api = api;

    // ============== Auth helpers ==============
    window.Auth = {
        async check() {
            try {
                const res = await api('/auth/check-auth');
                return res.data || null;
            } catch (e) { return null; }
        },
        async login(email, password) {
            return api('/auth/login', { method: 'POST', body: { email, password } });
        },
        async register(userName, email, password, adminSecret) {
            const body = { userName, email, password };
            if (adminSecret) body.adminSecret = adminSecret;
            return api('/auth/register', {
                method: 'POST',
                body,
                headers: adminSecret ? { 'X-Admin-Secret': adminSecret } : {},
            });
        },
        async logout() {
            return api('/auth/logout', { method: 'POST' });
        },
        async updatePassword(currentPassword, newPassword, confirmPassword) {
            return api('/auth/update-password', {
                method: 'POST',
                body: { currentPassword, newPassword, confirmPassword }
            });
        },
        async updateProfile(userName, email) {
            return api('/auth/update-profile', {
                method: 'POST',
                body: { userName, email }
            });
        },
        async forgotPassword(email, newPassword = '') {
            return api('/auth/forgot-password', {
                method: 'POST',
                body: { email, newPassword }
            });
        },
    };

    // ============== Cart helpers ==============
    function openCartSheet() {
        const sheet = document.getElementById('cartSheet');
        const overlay = document.querySelector('[data-sheet-overlay="cartSheet"]');
        sheet?.classList.add('open');
        overlay?.classList.add('open');
    }
    window.openCartSheet = openCartSheet;

    async function refreshCartSheet(open) {
        const sheet = document.getElementById('cartSheetContent');
        if (!sheet) return;
        const res = await fetch(window.location.href, { credentials: 'same-origin' });
        const html = await res.text();
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const next = doc.getElementById('cartSheetContent');
        if (next) {
            sheet.innerHTML = next.innerHTML;
            sheet.querySelectorAll('script').forEach((old) => old.remove());
        }
        const nextCount = doc.getElementById('cartSheetCount');
        const liveCount = document.getElementById('cartSheetCount');
        if (nextCount && liveCount) liveCount.textContent = nextCount.textContent;
        const nextBadge = doc.getElementById('headerCartCount');
        const liveBadge = document.getElementById('headerCartCount');
        if (nextBadge && liveBadge) {
            liveBadge.textContent = nextBadge.textContent.trim();
            liveBadge.style.display = nextBadge.textContent.trim() === '0' || nextBadge.style.display === 'none'
                ? 'none'
                : 'flex';
        }
        if (open) openCartSheet();
    }
    window.refreshCartSheet = refreshCartSheet;

    window.CartApi = {
        async get(userId) { return api(`/shop/cart/${userId}`); },
        async add(userId, productId, quantity = 1, options = {}) {
            const res = await api('/shop/cart', { method: 'POST', body: { userId, productId, quantity } });
            if (!options.silent) await refreshCartSheet(true);
            return res;
        },
        async updateQty(userId, productId, quantity) {
            const res = await api('/shop/cart', { method: 'PUT', body: { userId, productId, quantity } });
            await refreshCartSheet(true);
            return res;
        },
        async remove(userId, productId) {
            const res = await api(`/shop/cart/${userId}/${productId}`, { method: 'DELETE' });
            await refreshCartSheet(true);
            return res;
        },
    };

    window.updateCartItemQty = async function (productId, newQty) {
        const userId = window.CART_USER_ID;
        if (!userId || newQty < 1) return;
        openCartSheet();
        try {
            await CartApi.updateQty(userId, productId, newQty);
        } catch (e) {
            openCartSheet();
        }
    };

    window.removeCartItem = async function (productId) {
        const userId = window.CART_USER_ID;
        if (!userId) return;
        openCartSheet();
        try {
            await CartApi.remove(userId, productId);
        } catch (e) {
            openCartSheet();
        }
    };

    window.applyDrawerCoupon = async function () {
        const inp = document.getElementById('drawerCouponInput');
        const resBox = document.getElementById('drawerCouponResult');
        const code = inp ? inp.value.trim().toUpperCase() : '';
        if (!code) return;
        const subtotalText = document.getElementById('drawerSubtotal')?.textContent || '0';
        const subtotal = parseFloat(String(subtotalText).replace(/[^0-9.]/g, '')) || 0;
        try {
            const res = await CouponApi.apply(code, subtotal);
            const disc = res.data.discountAmount || 0;
            if (resBox) {
                resBox.className = 'text-[11px] font-bold mt-1.5 text-emerald-600';
                resBox.textContent = 'Coupon applied. Saved ₹' + Number(disc).toFixed(2);
                resBox.style.display = 'block';
            }
            const row = document.getElementById('drawerDiscountRow');
            if (row) row.style.display = 'flex';
            const discEl = document.getElementById('drawerDiscountVal');
            if (discEl) discEl.textContent = '-₹' + Number(disc).toFixed(2);
            const shipping = subtotal >= 1000 ? 0 : 99;
            const totalEl = document.getElementById('drawerTotal');
            if (totalEl) totalEl.textContent = formatCurrency(Math.max(0, subtotal + shipping - disc));
            sessionStorage.setItem('applied_coupon', JSON.stringify(res.data));
            toast('Promo code applied', res.message || 'Discount added to your bag', 'success');
        } catch (e) {
            if (resBox) {
                resBox.className = 'text-[11px] font-bold mt-1.5 text-rose-500';
                resBox.textContent = e.message || 'Invalid coupon code';
                resBox.style.display = 'block';
            }
        }
    };

    // ============== Orders ==============
    window.OrderApi = {
        async getByUser(userId) { return api(`/shop/order/user/${userId}`); },
        async get(id) { return api(`/shop/order/${id}`); },
        async create(payload) {
            return api('/shop/order', { method: 'POST', body: payload });
        },
        async capture(orderId) {
            return api('/shop/order/capture', { method: 'POST', body: { orderId } });
        },
        async stripeCheckout(payload) {
            return api('/shop/order/stripe-checkout', { method: 'POST', body: payload });
        },
        async stripeVerify(sessionId) {
            return api('/shop/order/stripe-verify', { method: 'POST', body: { sessionId } });
        },
    };

    // ============== Addresses ==============
    window.AddressApi = {
        async get(userId) { return api(`/shop/address/${userId}`); },
        async add(payload) { return api('/shop/address', { method: 'POST', body: payload }); },
        async update(id, payload) { return api(`/shop/address/${id}`, { method: 'PUT', body: payload }); },
        async remove(id) { return api(`/shop/address/${id}`, { method: 'DELETE' }); },
    };

    // ============== Reviews ==============
    window.ReviewApi = {
        async get(productId) { return api(`/shop/review/${productId}`); },
        async add(payload) { return api('/shop/review', { method: 'POST', body: payload }); },
        async update(id, payload) { return api(`/shop/review/${id}`, { method: 'PUT', body: payload }); },
        async remove(id) { return api(`/shop/review/${id}`, { method: 'DELETE' }); },
    };

    // ============== Wishlist helpers ==============
    window.WishlistApi = {
        async get() { return api('/shop/wishlist'); },
        async toggle(productId) {
            return api('/shop/wishlist/toggle', { method: 'POST', body: { productId: Number(productId) } });
        },
        async remove(productId) {
            return api(`/shop/wishlist/${productId}`, { method: 'DELETE' });
        },
    };

    // ============== Coupon helpers ==============
    window.CouponApi = {
        async apply(code, subtotal) {
            return api('/shop/coupon/apply', { method: 'POST', body: { code, subtotal: Number(subtotal) } });
        },
    };

    // ============== Product helpers ==============
    window.ProductApi = {
        async all(params = {}) {
            const qs = new URLSearchParams(params).toString();
            return api('/shop/products' + (qs ? '?' + qs : ''));
        },
        async meta() { return api('/shop/products/meta'); },
        async one(id) { return api(`/shop/products/${id}`); },
        async search(q) { return api(`/shop/search?q=${encodeURIComponent(q)}`); },
    };

    // ============== Feature/banners ==============
    window.FeatureApi = {
        async all() { return api('/common/feature'); },
    };

    // ============== Utilities ==============
    window.formatCurrency = (n) => '₹' + Number(n || 0).toLocaleString('en-IN', {
        minimumFractionDigits: 2, maximumFractionDigits: 2,
    });
    window.displayPrice = (p) => Number(p?.salePrice || 0) > 0
        ? Number(p.salePrice)
        : Number(p?.price || 0);

    // Render stars
    window.renderStars = (rating = 0, size = 16) => {
        const r = Math.round(Number(rating || 0));
        let out = '<span class="stars">';
        for (let i = 1; i <= 5; i++) {
            const fill = i <= r ? '#eab308' : '#e5e7eb';
            out += `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="${fill}" stroke="${fill}" stroke-width="0">
                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`;
        }
        return out + '</span>';
    };

    // ============== UI: Dialogs, Dropdowns, Sheets ==============
    document.addEventListener('click', (e) => {
        // Dropdown toggle
        const trigger = e.target.closest('[data-dropdown-trigger]');
        if (trigger) {
            const id = trigger.getAttribute('data-dropdown-trigger');
            const menu = document.querySelector(`[data-dropdown="${id}"]`);
            // Close other open dropdowns first
            document.querySelectorAll('.dropdown-menu.open').forEach(m => {
                if (m !== menu) m.classList.remove('open');
            });
            if (menu) menu.classList.toggle('open');
            e.stopPropagation();
        } else if (!e.target.closest('.dropdown-menu')) {
            // Close dropdowns when clicking outside
            document.querySelectorAll('.dropdown-menu.open').forEach(m => m.classList.remove('open'));
        }

        // Dialog open/close
        const openBtn = e.target.closest('[data-dialog-open]');
        if (openBtn) {
            const id = openBtn.getAttribute('data-dialog-open');
            document.getElementById(id)?.classList.remove('hidden');
        }
        const closeBtn = e.target.closest('[data-dialog-close]');
        if (closeBtn) {
            const id = closeBtn.getAttribute('data-dialog-close')
                || closeBtn.closest('.dialog-overlay')?.id;
            if (id) document.getElementById(id)?.classList.add('hidden');
        }

        // Sheet toggle
        const sheetBtn = e.target.closest('[data-sheet-toggle]');
        if (sheetBtn) {
            const id = sheetBtn.getAttribute('data-sheet-toggle');
            const sheet = document.getElementById(id);
            const overlay = document.querySelector(`[data-sheet-overlay="${id}"]`);
            sheet?.classList.toggle('open');
            overlay?.classList.toggle('open');
        }
        const sheetOverlay = e.target.closest('[data-sheet-overlay]');
        if (sheetOverlay && !e.target.closest('.sheet')) {
            sheetOverlay.classList.remove('open');
            const id = sheetOverlay.getAttribute('data-sheet-overlay');
            document.getElementById(id)?.classList.remove('open');
        }

        // Mobile Nav Drawer
        const navOpen = e.target.closest('[data-mobile-nav-toggle]');
        if (navOpen) {
            document.getElementById('mobileNavDrawer')?.classList.add('open');
            document.getElementById('mobileNavBackdrop')?.classList.add('open');
            document.body.style.overflow = 'hidden';
        }
        const navClose = e.target.closest('[data-mobile-nav-close]') || (e.target.id === 'mobileNavBackdrop');
        if (navClose) {
            document.getElementById('mobileNavDrawer')?.classList.remove('open');
            document.getElementById('mobileNavBackdrop')?.classList.remove('open');
            document.body.style.overflow = '';
        }

        // Password visibility toggle
        const pwdToggle = e.target.closest('[data-toggle-password]');
        if (pwdToggle) {
            const targetId = pwdToggle.getAttribute('data-toggle-password');
            const input = document.getElementById(targetId);
            if (input) {
                const isPass = input.type === 'password';
                input.type = isPass ? 'text' : 'password';
                pwdToggle.setAttribute('aria-pressed', isPass ? 'true' : 'false');
                pwdToggle.innerHTML = isPass ? `
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                ` : `
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                `;
            }
        }

        // Wishlist button click
        const wishBtn = e.target.closest('[data-wishlist-toggle]');
        if (wishBtn) {
            e.preventDefault();
            e.stopPropagation();
            const pid = wishBtn.getAttribute('data-wishlist-toggle');
            if (!pid) return;
            wishBtn.disabled = true;
            WishlistApi.toggle(pid).then(res => {
                const isW = res.data.isWishlisted;
                const count = res.data.count;
                wishBtn.classList.toggle('wishlisted', isW);
                const svg = wishBtn.querySelector('svg');
                if (svg) {
                    svg.setAttribute('fill', isW ? '#ef4444' : 'none');
                    svg.setAttribute('stroke', isW ? '#ef4444' : 'currentColor');
                }
                // Update header badge
                const badge = document.getElementById('headerWishlistCount');
                if (badge) {
                    badge.textContent = count;
                    badge.style.display = count > 0 ? 'flex' : 'none';
                }
                toast(isW ? 'Saved' : 'Removed', res.message, 'success');
            }).catch(err => {
                // If 401 or not logged in, prompt user
                if (err.message && err.message.toLowerCase().includes('sign in')) {
                    toast('Login Required', 'Please sign in to add items to your wishlist', 'info');
                    setTimeout(() => {
                        window.location.href = (window.APP_BASE || '') + '/auth/login';
                    }, 1200);
                }
            }).finally(() => {
                wishBtn.disabled = false;
            });
        }
    });

    // Close dialogs on overlay click
    document.addEventListener('click', (e) => {
        const overlay = e.target.closest('.dialog-overlay');
        if (overlay && e.target === overlay && overlay.dataset.closable !== 'false') {
            overlay.classList.add('hidden');
        }
    });

    // Escape closes topmost dialog/sheet/drawer
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            const openDialog = document.querySelector('.dialog-overlay:not(.hidden)');
            if (openDialog) { openDialog.classList.add('hidden'); return; }
            const openSheet = document.querySelector('.sheet.open');
            if (openSheet) {
                openSheet.classList.remove('open');
                document.querySelector(`[data-sheet-overlay="${openSheet.id}"]`)?.classList.remove('open');
                return;
            }
            const openDrawer = document.getElementById('mobileNavDrawer');
            if (openDrawer && openDrawer.classList.contains('open')) {
                openDrawer.classList.remove('open');
                document.getElementById('mobileNavBackdrop')?.classList.remove('open');
                document.body.style.overflow = '';
            }
        }
    });

    // Global header search submit
    document.addEventListener('submit', (e) => {
        const form = e.target.closest('[data-search-form]');
        if (form) {
            e.preventDefault();
            const q = form.querySelector('[name="q"]')?.value?.trim() || '';
            if (q) {
                window.location.href = (window.APP_BASE || '') + '/shop/search?q=' + encodeURIComponent(q);
            } else {
                window.location.href = (window.APP_BASE || '') + '/shop/listing';
            }
        }

        // Newsletter form
        const newsForm = e.target.closest('[data-newsletter-form]');
        if (newsForm) {
            e.preventDefault();
            const inp = newsForm.querySelector('input[type="email"]');
            if (inp && inp.value) {
                toast('Subscribed!', 'Thank you for subscribing to ClothShop newsletters.', 'success');
                inp.value = '';
            }
        }
    });

    // Init: process deferred callbacks
    document.addEventListener('DOMContentLoaded', () => {
        if (typeof window.__onAppReady === 'function') window.__onAppReady();
    });
})();

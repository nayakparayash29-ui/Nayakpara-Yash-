/**
 * ClothStore Admin Panel — Core Interactive Engine
 * Handles sidebar toggles, dropdowns, modals, client-side pagination,
 * filters, CSV export, and button loading states.
 */
(function() {
    'use strict';

    // =========================================================================
    // Sidebar & Drawer Management
    // =========================================================================
    const layout = document.getElementById('adminLayout');
    const backdrop = document.getElementById('adminBackdrop');
    const mobileToggle = document.getElementById('admMobileToggle');
    const desktopCollapse = document.getElementById('admCollapseToggle');
    const mobileClose = document.getElementById('admSidebarClose');

    // Restore desktop collapsed state
    if (localStorage.getItem('admin_sidebar_collapsed') === 'true') {
        layout?.classList.add('sidebar-collapsed');
    }

    // Keep the sidebar menu where the user left it after navigation
    const sideNav = document.querySelector('.adm-sidebar-nav');
    if (sideNav) {
        const savedScroll = sessionStorage.getItem('adm_nav_scroll');
        if (savedScroll !== null) {
            sideNav.scrollTop = parseInt(savedScroll, 10) || 0;
        }
        document.querySelectorAll('.adm-sidebar-nav a').forEach(link => {
            link.addEventListener('click', () => {
                sessionStorage.setItem('adm_nav_scroll', String(sideNav.scrollTop));
            });
        });
    }

    // Mobile Drawer Open
    mobileToggle?.addEventListener('click', () => {
        layout?.classList.add('open-sidebar');
        backdrop?.classList.add('active');
        document.body.style.overflow = 'hidden';
    });

    // Mobile Drawer Close
    function closeMobileSidebar() {
        layout?.classList.remove('open-sidebar');
        backdrop?.classList.remove('active');
        document.body.style.overflow = '';
    }

    mobileClose?.addEventListener('click', closeMobileSidebar);
    backdrop?.addEventListener('click', closeMobileSidebar);

    // Desktop Collapse Toggle
    desktopCollapse?.addEventListener('click', () => {
        layout?.classList.toggle('sidebar-collapsed');
        const isCollapsed = layout?.classList.contains('sidebar-collapsed');
        localStorage.setItem('admin_sidebar_collapsed', isCollapsed ? 'true' : 'false');
    });

    // Auto-close mobile drawer when clicking a link inside it
    document.querySelectorAll('.adm-sidebar-nav a').forEach(link => {
        link.addEventListener('click', () => {
            if (window.innerWidth <= 1024) closeMobileSidebar();
        });
    });

    // Window resize handler
    window.addEventListener('resize', () => {
        if (window.innerWidth > 1024) {
            closeMobileSidebar();
        }
    });

    // =========================================================================
    // Dropdowns Management (Outside click & toggle)
    // =========================================================================
    document.addEventListener('click', (e) => {
        const trigger = e.target.closest('[data-adm-dropdown-trigger]');
        if (trigger) {
            const wrap = trigger.closest('.adm-dropdown-wrap');
            if (wrap) {
                const isOpen = wrap.classList.contains('open');
                // Close other open dropdowns first
                document.querySelectorAll('.adm-dropdown-wrap.open').forEach(w => {
                    if (w !== wrap) w.classList.remove('open');
                });
                wrap.classList.toggle('open', !isOpen);
                e.stopPropagation();
                return;
            }
        }

        // Close dropdowns when clicking outside
        if (!e.target.closest('.adm-dropdown-pop')) {
            document.querySelectorAll('.adm-dropdown-wrap.open').forEach(w => w.classList.remove('open'));
        }
    });

    // =========================================================================
    // Modals & Dialogs Handling
    // =========================================================================
    // Prevent clicks inside dialog from closing the overlay
    document.querySelectorAll('.dialog').forEach(dlg => {
        dlg.addEventListener('click', (e) => {
            e.stopPropagation();
        });
    });

    // Close on overlay backdrop click
    document.querySelectorAll('.dialog-overlay').forEach(overlay => {
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay && overlay.dataset.closable !== 'false') {
                overlay.classList.add('hidden');
            }
        });
    });

    // ESC key closes topmost dialog, dropdown, or mobile drawer
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            // Close open dropdowns
            const openDropdown = document.querySelector('.adm-dropdown-wrap.open');
            if (openDropdown) {
                openDropdown.classList.remove('open');
                return;
            }

            // Close open dialog
            const openDialog = document.querySelector('.dialog-overlay:not(.hidden)');
            if (openDialog && openDialog.dataset.closable !== 'false') {
                openDialog.classList.add('hidden');
                return;
            }

            // Close mobile sidebar
            if (layout?.classList.contains('open-sidebar')) {
                closeMobileSidebar();
            }
        }
    });

    // =========================================================================
    // Button Loading State Helper
    // =========================================================================
    window.setButtonLoading = function(btn, loading = true, customText = '') {
        if (!btn) return;
        if (loading) {
            btn.dataset.originalHtml = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<span class="adm-spinner"></span> ${customText || 'Processing...'}`;
        } else {
            btn.disabled = false;
            btn.innerHTML = btn.dataset.originalHtml || btn.innerHTML;
        }
    };

    // =========================================================================
    // Confirmation Dialog Modal Helper
    // =========================================================================
    window.showConfirmModal = function({
        title = 'Confirm Action',
        message = 'Are you sure you want to proceed?',
        confirmText = 'Confirm',
        cancelText = 'Cancel',
        isDanger = true,
        onConfirm = () => {},
    }) {
        let modal = document.getElementById('globalConfirmModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'globalConfirmModal';
            modal.className = 'dialog-overlay hidden';
            modal.innerHTML = `
                <div class="dialog" style="max-width: 26rem;">
                    <div class="dialog-header">
                        <h3 class="dialog-title" id="gConfTitle"></h3>
                        <button class="btn btn-ghost btn-icon btn-sm" id="gConfClose">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
                        </button>
                    </div>
                    <div class="dialog-content">
                        <p class="text-sm text-muted-foreground m-0" id="gConfMsg" style="line-height:1.5;"></p>
                    </div>
                    <div class="dialog-footer">
                        <button type="button" class="btn btn-outline btn-sm" id="gConfCancel">Cancel</button>
                        <button type="button" class="btn btn-sm" id="gConfOk">Confirm</button>
                    </div>
                </div>`;
            document.body.appendChild(modal);
        }

        const titleEl = modal.querySelector('#gConfTitle');
        const msgEl = modal.querySelector('#gConfMsg');
        const okBtn = modal.querySelector('#gConfOk');
        const cancelBtn = modal.querySelector('#gConfCancel');
        const closeBtn = modal.querySelector('#gConfClose');

        titleEl.textContent = title;
        msgEl.innerHTML = message;
        okBtn.textContent = confirmText;
        cancelBtn.textContent = cancelText;
        okBtn.className = `btn btn-sm ${isDanger ? 'btn-destructive' : 'btn-primary'}`;

        modal.classList.remove('hidden');

        const closeIt = () => modal.classList.add('hidden');
        closeBtn.onclick = closeIt;
        cancelBtn.onclick = closeIt;
        modal.onclick = (e) => { if (e.target === modal) closeIt(); };

        okBtn.onclick = async () => {
            closeIt();
            try { await onConfirm(); } catch (err) { console.error(err); }
        };
    };

    // =========================================================================
    // Client-side Table Controller (Pagination, Filter, Search, CSV Export)
    // =========================================================================
    window.initAdminTable = function(tableId, options = {}) {
        const table = document.getElementById(tableId);
        if (!table) return null;

        const tbody = table.querySelector('tbody');
        const searchInput = options.searchId ? document.getElementById(options.searchId) : null;
        const filterSelect = options.filterId ? document.getElementById(options.filterId) : null;
        const pageSizeSelect = options.pageSizeId ? document.getElementById(options.pageSizeId) : null;
        const paginationContainer = options.paginationId ? document.getElementById(options.paginationId) : null;

        let currentPage = 1;
        let pageSize = options.defaultPageSize || 10;
        let allRows = Array.from(tbody.querySelectorAll('tr'));
        let filteredRows = [...allRows];

        const extraFilters = (options.extraFilters || []).map(f => ({
            el: document.getElementById(f.id),
            attr: f.attr,
        })).filter(f => f.el);

        function applySearchAndFilter() {
            const query = searchInput ? searchInput.value.toLowerCase().trim() : '';
            const filterVal = filterSelect ? filterSelect.value : 'all';

            filteredRows = allRows.filter(row => {
                // If it's an empty-state row, ignore
                if (row.querySelector('td[colspan]')) return false;

                // Match Search Query
                const searchData = (row.dataset.search || row.textContent).toLowerCase();
                const matchQuery = !query || searchData.includes(query);

                // Match Dropdown Filter
                let matchFilter = true;
                if (filterVal && filterVal !== 'all') {
                    if (options.filterAttr) {
                        matchFilter = row.getAttribute(options.filterAttr) === filterVal;
                    } else if (row.dataset.status) {
                        matchFilter = row.dataset.status === filterVal;
                    } else if (row.dataset.category) {
                        matchFilter = row.dataset.category === filterVal;
                    } else if (row.classList.contains(filterVal) || row.classList.contains('s-' + filterVal) || row.classList.contains('r-' + filterVal)) {
                        matchFilter = true;
                    } else {
                        matchFilter = false;
                    }
                }

                const matchExtra = extraFilters.every(f => {
                    const val = f.el.value;
                    if (!val || val === 'all') return true;
                    return row.getAttribute(f.attr) === val;
                });

                return matchQuery && matchFilter && matchExtra;
            });

            currentPage = 1;
            renderPage();
        }

        function renderPage() {
            const total = filteredRows.length;
            const totalPages = Math.max(1, Math.ceil(total / pageSize));
            if (currentPage > totalPages) currentPage = totalPages;

            const startIdx = (currentPage - 1) * pageSize;
            const endIdx = startIdx + pageSize;

            // Hide all rows first
            allRows.forEach(r => r.style.display = 'none');

            if (total === 0) {
                // Show empty indicator row if available or create one
                let emptyRow = tbody.querySelector('.adm-empty-row');
                if (!emptyRow) {
                    emptyRow = document.createElement('tr');
                    emptyRow.className = 'adm-empty-row';
                    const colCount = table.querySelectorAll('thead th').length || 6;
                    emptyRow.innerHTML = `<td colspan="${colCount}" class="text-center py-10 text-muted-foreground">
                        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="mx-auto mb-2 opacity-40"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                        <p class="m-0 text-sm">No matching records found.</p>
                    </td>`;
                    tbody.appendChild(emptyRow);
                }
                emptyRow.style.display = '';
            } else {
                const emptyRow = tbody.querySelector('.adm-empty-row');
                if (emptyRow) emptyRow.style.display = 'none';

                // Display rows for current page slice
                filteredRows.slice(startIdx, endIdx).forEach(r => r.style.display = '');
            }

            renderPaginationControls(total, totalPages, startIdx, endIdx);
        }

        function renderPaginationControls(total, totalPages, startIdx, endIdx) {
            if (!paginationContainer) return;

            const startNum = total === 0 ? 0 : startIdx + 1;
            const endNum = Math.min(total, endIdx);

            let buttonsHtml = '';
            buttonsHtml += `<button type="button" class="adm-page-btn prevPage" ${currentPage <= 1 ? 'disabled' : ''}>← Prev</button>`;

            // Page numbers
            const maxPills = 5;
            let startP = Math.max(1, currentPage - 2);
            let endP = Math.min(totalPages, startP + maxPills - 1);
            if (endP - startP < maxPills - 1) {
                startP = Math.max(1, endP - maxPills + 1);
            }

            for (let p = startP; p <= endP; p++) {
                buttonsHtml += `<button type="button" class="adm-page-btn numPage ${p === currentPage ? 'active' : ''}" data-page="${p}">${p}</button>`;
            }

            buttonsHtml += `<button type="button" class="adm-page-btn nextPage" ${currentPage >= totalPages ? 'disabled' : ''}>Next →</button>`;

            paginationContainer.innerHTML = `
                <div class="text-xs text-muted-foreground">
                    Showing <strong class="text-main">${startNum}</strong> to <strong class="text-main">${endNum}</strong> of <strong class="text-main">${total}</strong> records
                </div>
                <div class="adm-page-controls">
                    ${buttonsHtml}
                </div>`;

            // Bind click events on buttons
            paginationContainer.querySelector('.prevPage')?.addEventListener('click', () => {
                if (currentPage > 1) { currentPage--; renderPage(); }
            });
            paginationContainer.querySelector('.nextPage')?.addEventListener('click', () => {
                if (currentPage < totalPages) { currentPage++; renderPage(); }
            });
            paginationContainer.querySelectorAll('.numPage').forEach(btn => {
                btn.addEventListener('click', () => {
                    currentPage = parseInt(btn.dataset.page);
                    renderPage();
                });
            });
        }

        // Attach event listeners
        if (searchInput) searchInput.addEventListener('input', applySearchAndFilter);
        if (filterSelect) filterSelect.addEventListener('change', applySearchAndFilter);
        extraFilters.forEach(f => f.el.addEventListener('change', applySearchAndFilter));
        if (pageSizeSelect) {
            pageSizeSelect.addEventListener('change', (e) => {
                pageSize = parseInt(e.target.value) || 10;
                currentPage = 1;
                renderPage();
            });
        }

        // Initial render
        applySearchAndFilter();

        return {
            refresh() {
                allRows = Array.from(tbody.querySelectorAll('tr:not(.adm-empty-row)'));
                applySearchAndFilter();
            },
            exportCSV(filename = 'export.csv') {
                window.exportTableToCSV(tableId, filename);
            }
        };
    };

    // =========================================================================
    // CSV Export Utility
    // =========================================================================
    window.exportTableToCSV = function(tableId, filename = 'export.csv') {
        const table = document.getElementById(tableId);
        if (!table) return;

        const rows = [];
        // Extract headers
        const headerCells = Array.from(table.querySelectorAll('thead th'));
        const headers = headerCells.map(th => {
            const txt = th.textContent.trim().replace(/"/g, '""');
            return `"${txt}"`;
        });
        rows.push(headers.join(','));

        // Extract visible/data rows
        const dataRows = Array.from(table.querySelectorAll('tbody tr')).filter(r => r.style.display !== 'none' && !r.classList.contains('adm-empty-row'));
        dataRows.forEach(tr => {
            const cells = Array.from(tr.querySelectorAll('td'));
            const rowData = cells.map(td => {
                // Strip buttons/action text if last column is action
                let text = td.innerText.trim();
                text = text.replace(/"/g, '""').replace(/\n/g, ' ');
                return `"${text}"`;
            });
            rows.push(rowData.join(','));
        });

        const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + encodeURIComponent(rows.join('\r\n'));
        const link = document.createElement('a');
        link.setAttribute('href', csvContent);
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

})();

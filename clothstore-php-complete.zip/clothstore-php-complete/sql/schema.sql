-- ============================================
-- ClothStore PHP - MySQL Database Schema
-- Converted from MongoDB MERN structure
-- ============================================

CREATE DATABASE IF NOT EXISTS clothstore_php DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE clothstore_php;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userName VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(191) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image TEXT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NULL,
    category VARCHAR(100) NULL,
    brand VARCHAR(100) NULL,
    price DECIMAL(10,2) DEFAULT 0,
    salePrice DECIMAL(10,2) DEFAULT 0,
    totalStock INT DEFAULT 0,
    averageReview DECIMAL(3,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Carts table
CREATE TABLE IF NOT EXISTS carts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cart items table (embedded items array in MongoDB)
CREATE TABLE IF NOT EXISTS cart_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cart_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1 CHECK (quantity >= 1),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (cart_id) REFERENCES carts(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Addresses table
CREATE TABLE IF NOT EXISTS addresses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    address TEXT NULL,
    city VARCHAR(100) NULL,
    pincode VARCHAR(20) NULL,
    phone VARCHAR(20) NULL,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    cart_id INT NULL,
    orderStatus VARCHAR(50) DEFAULT 'pending',
    paymentMethod VARCHAR(50) NULL,
    paymentStatus VARCHAR(50) DEFAULT 'pending',
    totalAmount DECIMAL(10,2) DEFAULT 0,
    orderDate DATETIME NULL,
    orderUpdateDate DATETIME NULL,
    paymentId VARCHAR(255) NULL,
    payerId VARCHAR(255) NULL,
    -- Address info (duplicated for order snapshot)
    address_id INT NULL,
    address TEXT NULL,
    city VARCHAR(100) NULL,
    pincode VARCHAR(20) NULL,
    phone VARCHAR(20) NULL,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Order items table (embedded cartItems array in MongoDB)
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NULL,
    title VARCHAR(255) NULL,
    image TEXT NULL,
    price DECIMAL(10,2) DEFAULT 0,
    quantity INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Product Reviews table
CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    user_id INT NOT NULL,
    userName VARCHAR(100) NULL,
    reviewMessage TEXT NULL,
    reviewValue INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Features table (homepage banners)
CREATE TABLE IF NOT EXISTS features (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Sample Data (for testing)
-- ============================================

-- Default admin user (password: sanju123, hashed with password_hash)
INSERT IGNORE INTO users (userName, email, password, role) VALUES
('admin', 'sanju123@gmail.com', '$2y$12$vMDvs6AySf.8KJL5nVYag.QQF22G.a3KG8kOWqGaCGzXTzkI6EOaG', 'admin');

-- Sample products
INSERT IGNORE INTO products (image, title, description, category, brand, price, salePrice, totalStock, averageReview) VALUES
('/uploads/1770634020211_Men-Tshirt-n.webp', 'Premium Men T-Shirt', 'High quality cotton t-shirt for men', 'Men', 'Highlander', 799.00, 499.00, 50, 4.5),
('/uploads/1770633809347_m-hlsh010903-highlander-original-imafpchzahavusud.webp', 'Highlander Men Shirt', 'Casual cotton shirt', 'Men', 'Highlander', 1299.00, 899.00, 35, 4.2),
('/uploads/1770633899410_m-dh0858-010-nike-original-imagbks2gphdfayk.webp', 'Nike Sports Shoes', 'Comfortable running shoes', 'Footwear', 'Nike', 3999.00, 2999.00, 20, 4.7),
('/uploads/1770634095130_Women1.webp', 'Women Casual Wear', 'Elegant dress for women', 'Women', 'Nivick', 1599.00, 999.00, 40, 4.3),
('/uploads/1770634163763_women2.webp', 'Women Kurti', 'Designer kurti collection', 'Women', 'Libas', 999.00, 699.00, 45, 4.1),
('/uploads/1770634223782_women3.webp', 'Women Top', 'Trendy top for daily wear', 'Women', 'Nivick', 699.00, 399.00, 60, 4.0),
('/uploads/1770633137053_Footwear1.webp', 'Casual Footwear', 'Daily use casual shoes', 'Footwear', 'Campus', 1499.00, 999.00, 30, 4.4),
('/uploads/1770632845173_Accessories1.webp', 'Fashion Accessories', 'Trendy fashion accessories set', 'Accessories', 'Puma', 799.00, 499.00, 80, 4.0),
('/uploads/1770633375854_kids1.webp', 'Kids Casual Dress', 'Comfortable cotton dress for kids', 'Kids', 'Mothercare', 699.00, 449.00, 25, 4.6),
('/uploads/1770633501013_kids2.webp', 'Kids T-Shirt', 'Fun printed t-shirt for kids', 'Kids', 'UCB', 399.00, 249.00, 55, 4.2);

import re
import pathlib

root = pathlib.Path(r"c:\xampp\htdocs\clothstore-php-complete\views\admin")
css = (
    pathlib.Path(r"c:\xampp\htdocs\clothstore-php-complete\public\css\style.css").read_text(encoding="utf-8")
    + "\n"
    + pathlib.Path(r"c:\xampp\htdocs\clothstore-php-complete\public\css\admin.css").read_text(encoding="utf-8")
)
classes = set()
for p in root.glob("*.php"):
    t = p.read_text(encoding="utf-8", errors="ignore")
    for m in re.findall(r'class="([^"]+)"', t):
        for c in m.split():
            if "$" in c or "<?" in c:
                continue
            classes.add(c)

missing = []
for c in sorted(classes):
    needle = "." + c.replace(":", r"\:").replace(".", r"\.").replace("[", r"\[").replace("]", r"\]").replace("/", r"\/")
    if needle not in css and ("." + c) not in css:
        missing.append(c)

print("TOTAL", len(classes))
print("MISSING", len(missing))
for m in missing:
    print(m)

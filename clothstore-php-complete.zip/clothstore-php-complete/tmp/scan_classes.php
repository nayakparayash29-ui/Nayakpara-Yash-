<?php
$root = __DIR__ . '/../views/admin';
$css = file_get_contents(__DIR__ . '/../public/css/style.css') . "\n" . file_get_contents(__DIR__ . '/../public/css/admin.css');
$classes = [];
foreach (glob($root . '/*.php') as $file) {
    $t = file_get_contents($file);
    if (preg_match_all('/class="([^"]+)"/', $t, $m)) {
        foreach ($m[1] as $blob) {
            foreach (preg_split('/\s+/', $blob) as $c) {
                if ($c === '' || str_contains($c, '$') || str_contains($c, '<?')) continue;
                $classes[$c] = true;
            }
        }
    }
}
$missing = [];
foreach (array_keys($classes) as $c) {
    $needle = '.' . str_replace([':', '.', '[', ']', '/'], ['\\:', '\\.', '\\[', '\\]', '\\/'], $c);
    if (!str_contains($css, $needle) && !str_contains($css, '.' . $c)) {
        $missing[] = $c;
    }
}
sort($missing);
echo "TOTAL " . count($classes) . "\nMISSING " . count($missing) . "\n";
echo implode("\n", $missing), "\n";

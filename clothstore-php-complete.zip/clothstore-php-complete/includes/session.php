<?php
/**
 * Session & Authentication Management
 * (Replaces JWT from Node.js version)
 */

if (!defined('APP_NAME')) {
    require_once __DIR__ . '/../config/config.php';
}

if (session_status() === PHP_SESSION_NONE) {
    $sessionDir = __DIR__ . '/../tmp/sessions';
    if (!is_dir($sessionDir)) {
        @mkdir($sessionDir, 0777, true);
    }
    if (is_dir($sessionDir) && is_writable($sessionDir)) {
        session_save_path($sessionDir);
    }
    ini_set('session.use_strict_mode', 1);
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_secure', (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'));
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_lifetime', SESSION_LIFETIME);
    ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
    session_name('clothstore_session');
    @session_start();
    if (session_id() === '') {
        @session_start();
    }
}

if (!isset($_SESSION['_csrf'])) {
    $_SESSION['_csrf'] = bin2hex(random_bytes(32));
}

// Auth helpers
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function currentUser() {
    if (!isLoggedIn()) return null;
    return [
        'id'       => $_SESSION['user_id'],
        'email'    => $_SESSION['user_email']    ?? null,
        'userName' => $_SESSION['user_name']    ?? null,
        'role'     => $_SESSION['user_role']    ?? 'user',
    ];
}

function isAdmin() {
    return isLoggedIn() && ($_SESSION['user_role'] ?? '') === 'admin';
}

function requireLogin() {
    if (!isLoggedIn()) {
        if (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) {
            jsonResponse(false, 'Unauthorised user!', null, 401);
            exit;
        }
        header('Location: /auth/login');
        exit;
    }
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        if (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) {
            jsonResponse(false, 'Admin access required!', null, 403);
            exit;
        }
        header('Location: /unauth-page');
        exit;
    }
}

function setUserSession($user) {
    $_SESSION['user_id']    = $user['id'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_name']  = $user['userName'];
    $_SESSION['user_role']  = $user['role'];
    $_SESSION['_logged_at'] = time();
}

function logoutUserSession() {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params['path'], $params['domain'],
            $params['secure'], $params['httponly']);
    }
    session_destroy();
    if (session_status() === PHP_SESSION_NONE) {
        $sessionDir = __DIR__ . '/../tmp/sessions';
        if (!is_dir($sessionDir)) {
            @mkdir($sessionDir, 0777, true);
        }
        if (is_dir($sessionDir) && is_writable($sessionDir)) {
            session_save_path($sessionDir);
        }
        ini_set('session.use_strict_mode', 1);
        ini_set('session.cookie_httponly', 1);
        ini_set('session.cookie_secure', (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'));
        ini_set('session.use_only_cookies', 1);
        ini_set('session.cookie_lifetime', SESSION_LIFETIME);
        ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
        session_name('clothstore_session');
        @session_start();
    }
    if (!isset($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
}

// Flash messages
function setFlash($key, $message) {
    $_SESSION['_flash'][$key] = $message;
}

function getFlash($key) {
    if (isset($_SESSION['_flash'][$key])) {
        $msg = $_SESSION['_flash'][$key];
        unset($_SESSION['_flash'][$key]);
        return $msg;
    }
    return null;
}

// CSRF
function csrfToken() {
    return $_SESSION['_csrf'] ?? ($_SESSION['_csrf'] = bin2hex(random_bytes(32)));
}

function verifyCsrf($token) {
    return isset($_SESSION['_csrf']) && hash_equals($_SESSION['_csrf'], $token);
}

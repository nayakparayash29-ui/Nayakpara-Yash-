<?php
/**
 * Stripe Checkout helpers. Uses the store secret key from Admin Settings.
 */

function stripeSecretKey() {
    require_once __DIR__ . '/../models/Setting.php';
    $settings = (new SettingModel())->getAll();
    $key = trim((string)($settings['stripe_secret'] ?? ''));
    if ($key === '' && defined('STRIPE_SECRET_KEY')) {
        $key = trim((string)STRIPE_SECRET_KEY);
    }
    return $key;
}

function stripeApi($method, $path, $params = null, $secret = null) {
    $secret = $secret ?: stripeSecretKey();
    if ($secret === '') {
        return [0, ['error' => ['message' => 'Add your Stripe secret key in Admin Settings, under Payment Gateways.']]];
    }
    $url = 'https://api.stripe.com/v1' . $path;
    $ch = curl_init($url);
    $opts = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_USERPWD        => $secret . ':',
        CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
        CURLOPT_TIMEOUT        => 30,
    ];
    if ($params !== null) {
        $opts[CURLOPT_POSTFIELDS] = is_array($params) ? http_build_query($params) : $params;
    }
    curl_setopt_array($ch, $opts);
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $json = json_decode($raw ?: '', true);
    if (!is_array($json)) {
        $json = ['error' => ['message' => 'Stripe did not return a valid response.']];
    }
    return [$code, $json];
}

function stripeCreateCheckoutSession($orderId, $amountRupees, $currency = 'inr') {
    $amount = (int)round(((float)$amountRupees) * 100);
    if ($amount < 50) {
        return [400, ['error' => ['message' => 'Stripe needs an order total of at least ₹0.50.']]];
    }
    $success = APP_URL . '/shop/payment-success?session_id={CHECKOUT_SESSION_ID}';
    $cancel  = APP_URL . '/shop/checkout';
    $params = [
        'mode' => 'payment',
        'client_reference_id' => (string)$orderId,
        'metadata[order_id]' => (string)$orderId,
        'line_items[0][quantity]' => 1,
        'line_items[0][price_data][currency]' => strtolower($currency ?: 'inr'),
        'line_items[0][price_data][unit_amount]' => $amount,
        'line_items[0][price_data][product_data][name]' => APP_NAME . ' order #' . $orderId,
        'cancel_url' => $cancel,
    ];
    $body = http_build_query($params);
    $encodedSuccess = rawurlencode($success);
    $encodedSuccess = str_replace(['%7B', '%7D'], ['{', '}'], $encodedSuccess);
    $body .= '&success_url=' . $encodedSuccess;
    return stripeApi('POST', '/checkout/sessions', $body);
}

function fulfillStripeOrder($order) {
    require_once __DIR__ . '/../models/Order.php';
    require_once __DIR__ . '/../models/Product.php';
    require_once __DIR__ . '/../models/Cart.php';
    $orders = new OrderModel();
    $products = new ProductModel();
    $carts = new CartModel();
    if (($order['paymentStatus'] ?? '') === 'paid') {
        return $orders->findById($order['id']);
    }
    $orders->update($order['id'], [
        'paymentStatus'   => 'paid',
        'orderStatus'     => 'confirmed',
        'orderUpdateDate' => date('Y-m-d H:i:s'),
    ]);
    foreach ($order['cartItems'] as $item) {
        $p = $products->findById($item['productId']);
        if (!$p) continue;
        $products->update($p['id'], [
            'totalStock' => max(0, (int)$p['totalStock'] - (int)$item['quantity']),
        ]);
    }
    if (!empty($order['cartId'])) {
        $carts->deleteCart($order['cartId']);
    } else {
        $carts->deleteCartByUser($order['userId']);
    }
    return $orders->findById($order['id']);
}

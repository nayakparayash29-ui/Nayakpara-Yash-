<?php
/**
 * Global Helper Functions
 */

if (!defined('APP_NAME')) {
    require_once __DIR__ . '/../config/config.php';
}

// JSON response helper (mimics Node.js res.json pattern)
function jsonResponse($success, $message = '', $data = null, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    $response = ['success' => $success];
    if ($message !== '') $response['message'] = $message;
    if ($data !== null)    $response['data']    = $data;
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// Get JSON body from request
function getJsonBody() {
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

// Clean input
function e($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

function cleanInput($data) {
    if (is_array($data)) {
        return array_map('cleanInput', $data);
    }
    return trim((string)$data);
}

// Currency formatting (matches JS currency.js)
function formatCurrency($amount, $currency = '₹') {
    return $currency . number_format((float)$amount, 2, '.', ',');
}

function getDisplayPrice($product) {
    $salePrice = $product['salePrice'] ?? 0;
    return ($salePrice > 0) ? (float)$salePrice : (float)($product['price'] ?? 0);
}

// Base URL helper (prepends BASE_PATH)
function base_url($path = '') {
    $base = BASE_PATH;
    if ($path === '' || $path === '/') return $base === '' ? '/' : $base;
    $path = '/' . ltrim($path, '/');
    return $base . $path;
}

// Asset URL helper (for css/js/uploads)
function asset_url($path = '') {
    $url = base_url(ltrim($path, '/'));
    $file = dirname(__DIR__) . '/public/' . ltrim($path, '/');
    if (is_file($file)) {
        $url .= '?v=' . filemtime($file);
    }
    return $url;
}

// Product & Banner Image URL helper (safely resolves root/subfolder paths with SVG placeholder fallback)
function product_image_url($image = '') {
    if (empty($image)) {
        return 'data:image/svg+xml;utf8,' . rawurlencode('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="500" viewBox="0 0 400 500" fill="#f1f5f9"><rect width="400" height="500" fill="#f8fafc"/><path d="M160 180 L200 200 L240 180 L270 230 L240 240 L240 330 L160 330 L160 240 L130 230 Z" fill="#cbd5e1"/><text x="50%" y="375" text-anchor="middle" font-family="sans-serif" font-size="14" fill="#94a3b8" font-weight="600">ClothShop</text></svg>');
    }
    $image = trim((string)$image);
    if (preg_match('#uploads/([^?\s"\']+)$#i', $image, $m)) {
        return base_url('/uploads/' . $m[1]);
    }
    if (preg_match('#^(https?:|data:)#i', $image)) {
        return $image;
    }
    if (strpos($image, '/') === 0) {
        return base_url($image);
    }
    if (strpos($image, 'uploads/') === 0) {
        return base_url('/' . $image);
    }
    return base_url('/uploads/' . $image);
}

// Redirect (auto-prepends BASE_PATH)
function redirect($url) {
    // If absolute URL, leave as-is
    if (preg_match('#^https?:#i', $url)) {
        header('Location: ' . $url);
        exit;
    }
    header('Location: ' . base_url($url));
    exit;
}

// Slugify
function slugify($text) {
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9-]+/', '-', $text);
    return trim($text, '-');
}

// Upload file
function uploadFile($fileInputName, $allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif']) {
    if (!isset($_FILES[$fileInputName]) || $_FILES[$fileInputName]['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'No file uploaded or error'];
    }
    $file = $_FILES[$fileInputName];
    if (!in_array($file['type'], $allowedTypes)) {
        return ['success' => false, 'message' => 'Invalid file type'];
    }
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        return ['success' => false, 'message' => 'File too large'];
    }
    if (!is_dir(UPLOAD_DIR)) @mkdir(UPLOAD_DIR, 0777, true);
    $ext  = pathinfo($file['name'], PATHINFO_EXTENSION);
    $name = time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = UPLOAD_DIR . $name;
    if (@move_uploaded_file($file['tmp_name'], $dest)) {
        return ['success' => true, 'url' => UPLOAD_URL . $name, 'filename' => $name];
    }
    return ['success' => false, 'message' => 'Upload failed'];
}

// Pagination helper
function paginate($page, $perPage, $total) {
    $totalPages = ceil($total / $perPage);
    $offset     = ($page - 1) * $perPage;
    return [
        'page'       => (int)$page,
        'perPage'    => (int)$perPage,
        'total'      => (int)$total,
        'totalPages' => (int)$totalPages,
        'offset'     => (int)$offset,
    ];
}

function renderStars($rating = 0, $size = 16) {
    $r = round((float)$rating);
    $out = '<span class="stars">';
    for ($i = 1; $i <= 5; $i++) {
        $fill = $i <= $r ? '#eab308' : '#e5e7eb';
        $out .= '<svg width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="'.$fill.'" stroke="'.$fill.'" stroke-width="0"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
    }
    return $out . '</span>';
}

<?php
/**
 * Application Configuration
 * ClothStore PHP
 */

// Detect base path (subdirectory support for XAMPP etc.)
$scriptName = dirname($_SERVER['SCRIPT_NAME'] ?? '');
$scriptName = str_replace('\\', '/', $scriptName);
$basePath = rtrim($scriptName, '/');
if ($basePath === '\\/' || $basePath === '' || $basePath === '/') $basePath = '';

// Checkout is created from api/index.php, so SCRIPT_NAME ends in /api.
// Storefront URLs (Stripe success and cancel) must stay on the shop pages.
if ($basePath === '/api' || substr($basePath, -4) === '/api') {
    $basePath = rtrim(substr($basePath, 0, -4), '/');
    if ($basePath === '/' || $basePath === '') $basePath = '';
}

define('BASE_PATH', $basePath);

// Detect current protocol + host dynamically
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || ($_SERVER['SERVER_PORT'] ?? 0) == 443) ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$baseUrl = $scheme . '://' . $host . BASE_PATH;

define('APP_NAME', 'ClothStore');
define('APP_URL', $baseUrl);
define('CLIENT_URL', $baseUrl);

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'clothstore_php');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Security
define('ADMIN_SIGNUP_SECRET', 'ADMIN123');
define('CLIENT_SECRET_KEY', 'CLIENT_SECRET_KEY');
define('SESSION_LIFETIME', 3600); // 1 hour

// Uploads
define('UPLOAD_DIR', __DIR__ . '/../public/uploads/');
define('UPLOAD_URL', BASE_PATH . '/uploads/');
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024); // 10MB

// Stripe (optional)
define('STRIPE_SECRET_KEY', '');
define('STRIPE_PUBLISHABLE_KEY', '');

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

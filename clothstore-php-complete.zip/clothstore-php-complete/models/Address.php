<?php
/**
 * Address Model (matches mongoose Address.js schema)
 */
require_once __DIR__ . '/../config/database.php';

class AddressModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function findByUserId($userId) {
        return $this->db->fetchAll(
            "SELECT * FROM addresses WHERE user_id = ? ORDER BY id DESC",
            [$userId]
        );
    }

    public function findById($id) {
        return $this->db->fetchOne(
            "SELECT * FROM addresses WHERE id = ? LIMIT 1",
            [$id]
        );
    }

    public function create($data) {
        return $this->db->insert(
            "INSERT INTO addresses (user_id, address, city, pincode, phone, notes) VALUES (?, ?, ?, ?, ?, ?)",
            [
                $data['userId']  ?? $data['user_id'],
                $data['address'] ?? null,
                $data['city']    ?? null,
                $data['pincode'] ?? null,
                $data['phone']   ?? null,
                $data['notes']   ?? null,
            ]
        );
    }

    public function update($id, $data) {
        $fields = [];
        $params = [];
        $allowed = ['address', 'city', 'pincode', 'phone', 'notes'];
        foreach ($allowed as $k) {
            if (array_key_exists($k, $data)) {
                $fields[] = "{$k} = ?";
                $params[] = $data[$k];
            }
        }
        if (empty($fields)) return 0;
        $params[] = $id;
        return $this->db->execute(
            "UPDATE addresses SET " . implode(', ', $fields) . " WHERE id = ?",
            $params
        );
    }

    public function delete($id, $userId = null) {
        if ($userId) {
            return $this->db->execute(
                "DELETE FROM addresses WHERE id = ? AND user_id = ?",
                [$id, $userId]
            );
        }
        return $this->db->execute("DELETE FROM addresses WHERE id = ?", [$id]);
    }
}

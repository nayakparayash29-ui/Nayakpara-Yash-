<?php
/**
 * Setting Model
 * Handles store settings persistence in MySQL
 */
require_once __DIR__ . '/../config/database.php';

class SettingModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->ensureTable();
    }

    private function ensureTable() {
        $sql = "CREATE TABLE IF NOT EXISTS settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(100) NOT NULL UNIQUE,
            setting_value TEXT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $this->db->query($sql);

        // Seed defaults if empty
        $cnt = (int)$this->db->fetchOne("SELECT COUNT(*) AS c FROM settings")['c'];
        if ($cnt === 0) {
            $this->seedDefaults();
        }
    }

    public function seedDefaults() {
        $defaults = [
            'store_name'               => 'ClothStore',
            'store_email'              => 'store@clothstore.com',
            'support_email'            => 'support@clothstore.com',
            'contact_phone'            => '+91 98765 43210',
            'default_currency'         => 'INR',
            'address_line1'            => '123 Fashion Street, MG Road',
            'city'                     => 'Mumbai',
            'state'                    => 'Maharashtra',
            'pincode'                  => '400001',
            'country'                  => 'India',
            'stripe_enabled'           => '1',
            'stripe_key'               => '',
            'stripe_secret'            => '',
            'cod_enabled'              => '1',
            'cod_max_limit'            => '5000',
            'bank_enabled'             => '0',
            'free_shipping_threshold'  => '999',
            'standard_shipping_rate'   => '79',
            'express_shipping_rate'    => '149',
            'notif_order_placed'       => '1',
            'notif_order_shipped'      => '1',
            'notif_low_stock'          => '1',
            'notif_daily_summary'      => '0',
        ];
        foreach ($defaults as $k => $v) {
            $this->set($k, $v);
        }
    }

    public function getAll() {
        $rows = $this->db->fetchAll("SELECT setting_key, setting_value FROM settings");
        $out = [];
        foreach ($rows as $r) {
            $out[$r['setting_key']] = $r['setting_value'];
        }
        return $out;
    }

    public function get($key, $default = null) {
        $row = $this->db->fetchOne("SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1", [$key]);
        return $row ? $row['setting_value'] : $default;
    }

    public function set($key, $value) {
        $existing = $this->db->fetchOne("SELECT id FROM settings WHERE setting_key = ? LIMIT 1", [$key]);
        if ($existing) {
            $this->db->execute("UPDATE settings SET setting_value = ? WHERE setting_key = ?", [(string)$value, $key]);
        } else {
            $this->db->insert("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)", [$key, (string)$value]);
        }
    }

    public function setMany($pairs) {
        foreach ($pairs as $k => $v) {
            $this->set($k, $v);
        }
    }
}

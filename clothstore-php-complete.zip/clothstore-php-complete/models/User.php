<?php
/**
 * User Model (matches mongoose User.js schema)
 */
require_once __DIR__ . '/../config/database.php';

class UserModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function findByEmail($email) {
        return $this->db->fetchOne(
            "SELECT * FROM users WHERE email = ? LIMIT 1",
            [$email]
        );
    }

    public function findByUserName($userName) {
        return $this->db->fetchOne(
            "SELECT * FROM users WHERE userName = ? LIMIT 1",
            [$userName]
        );
    }

    public function findById($id) {
        return $this->db->fetchOne(
            "SELECT * FROM users WHERE id = ? LIMIT 1",
            [$id]
        );
    }

    public function create($data) {
        return $this->db->insert(
            "INSERT INTO users (userName, email, password, role) VALUES (?, ?, ?, ?)",
            [
                $data['userName'],
                $data['email'],
                $data['password'],
                $data['role'] ?? 'user',
            ]
        );
    }

    public function update($id, $data) {
        $fields = [];
        $params = [];
        foreach ($data as $key => $val) {
            if (in_array($key, ['userName', 'email', 'password', 'role'])) {
                $fields[] = "{$key} = ?";
                $params[] = $val;
            }
        }
        if (empty($fields)) return 0;
        $params[] = $id;
        return $this->db->execute(
            "UPDATE users SET " . implode(', ', $fields) . " WHERE id = ?",
            $params
        );
    }

    public function getAll($role = null) {
        if ($role) {
            return $this->db->fetchAll(
                "SELECT * FROM users WHERE role = ? ORDER BY created_at DESC",
                [$role]
            );
        }
        return $this->db->fetchAll("SELECT * FROM users ORDER BY created_at DESC");
    }

    public function countAll() {
        return (int)$this->db->fetchOne("SELECT COUNT(*) AS c FROM users")['c'];
    }

    public function delete($id) {
        return $this->db->execute("DELETE FROM users WHERE id = ?", [$id]);
    }
}

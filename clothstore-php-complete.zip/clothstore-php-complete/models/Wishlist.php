<?php
/**
 * Wishlist Model
 * Manages customer product wishlists in MySQL
 */
require_once __DIR__ . '/../config/database.php';

class WishlistModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->ensureTable();
    }

    private function ensureTable() {
        $sql = "CREATE TABLE IF NOT EXISTS wishlists (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            product_id INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY user_product (user_id, product_id),
            INDEX idx_user (user_id),
            INDEX idx_product (product_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $this->db->query($sql);
    }

    public function getByUserId($userId) {
        $sql = "SELECT w.id AS wishlist_id, w.created_at AS wishlisted_at, p.* 
                FROM wishlists w
                JOIN products p ON w.product_id = p.id
                WHERE w.user_id = ?
                ORDER BY w.created_at DESC";
        return $this->db->fetchAll($sql, [$userId]);
    }

    public function getProductIdsByUser($userId) {
        $sql = "SELECT product_id FROM wishlists WHERE user_id = ?";
        $rows = $this->db->fetchAll($sql, [$userId]);
        return array_map(function($r) { return (int)$r['product_id']; }, $rows);
    }

    public function isWishlisted($userId, $productId) {
        $row = $this->db->fetchOne(
            "SELECT id FROM wishlists WHERE user_id = ? AND product_id = ? LIMIT 1",
            [$userId, $productId]
        );
        return !empty($row);
    }

    public function add($userId, $productId) {
        if ($this->isWishlisted($userId, $productId)) {
            return true;
        }
        return $this->db->insert(
            "INSERT INTO wishlists (user_id, product_id) VALUES (?, ?)",
            [$userId, $productId]
        );
    }

    public function remove($userId, $productId) {
        return $this->db->execute(
            "DELETE FROM wishlists WHERE user_id = ? AND product_id = ?",
            [$userId, $productId]
        );
    }

    public function toggle($userId, $productId) {
        if ($this->isWishlisted($userId, $productId)) {
            $this->remove($userId, $productId);
            return false; // removed
        } else {
            $this->add($userId, $productId);
            return true; // added
        }
    }

    public function countByUser($userId) {
        $row = $this->db->fetchOne(
            "SELECT COUNT(*) AS c FROM wishlists WHERE user_id = ?",
            [$userId]
        );
        return (int)($row['c'] ?? 0);
    }
}

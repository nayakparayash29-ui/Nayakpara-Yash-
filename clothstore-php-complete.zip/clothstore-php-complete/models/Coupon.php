<?php
/**
 * Coupon Model
 * Handles coupon persistence in MySQL
 */
require_once __DIR__ . '/../config/database.php';

class CouponModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->ensureTable();
    }

    private function ensureTable() {
        $sql = "CREATE TABLE IF NOT EXISTS coupons (
            id INT AUTO_INCREMENT PRIMARY KEY,
            code VARCHAR(50) NOT NULL UNIQUE,
            type ENUM('percent', 'flat') DEFAULT 'percent',
            value DECIMAL(10,2) DEFAULT 0,
            minPurchase DECIMAL(10,2) DEFAULT 0,
            expiry DATE NULL,
            status ENUM('active', 'inactive', 'paused') DEFAULT 'active',
            usageCount INT DEFAULT 0,
            description TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $this->db->query($sql);

        // Seed default coupons if empty
        $cnt = (int)$this->db->fetchOne("SELECT COUNT(*) AS c FROM coupons")['c'];
        if ($cnt === 0) {
            $defaults = [
                ['WELCOME20', 'percent', 20, 999, date('Y-m-d', strtotime('+60 days')), 'active', 142, 'New customer welcome discount'],
                ['FLAT500', 'flat', 500, 2999, date('Y-m-d', strtotime('+30 days')), 'active', 87, 'Flat ₹500 off on orders above ₹2999'],
                ['SUMMER10', 'percent', 10, 0, date('Y-m-d', strtotime('+14 days')), 'active', 256, 'Summer sale - no minimum order'],
                ['FREESHIP', 'flat', 99, 499, date('Y-m-d', strtotime('+180 days')), 'active', 310, 'Free shipping equivalent discount'],
                ['VIP30', 'percent', 30, 4999, date('Y-m-d', strtotime('+7 days')), 'active', 23, 'VIP exclusive high-value discount'],
                ['EXPIRED15', 'percent', 15, 1999, date('Y-m-d', strtotime('-10 days')), 'inactive', 64, 'Old promo - expired'],
                ['MEGASALE', 'percent', 40, 9999, date('Y-m-d', strtotime('+3 days')), 'paused', 11, 'End of season mega sale (paused)'],
            ];
            foreach ($defaults as $d) {
                $this->db->insert(
                    "INSERT INTO coupons (code, type, value, minPurchase, expiry, status, usageCount, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    $d
                );
            }
        }
    }

    public function findAll() {
        return $this->db->fetchAll("SELECT * FROM coupons ORDER BY id DESC");
    }

    public function findById($id) {
        return $this->db->fetchOne("SELECT * FROM coupons WHERE id = ? LIMIT 1", [$id]);
    }

    public function findByCode($code) {
        return $this->db->fetchOne("SELECT * FROM coupons WHERE UPPER(code) = UPPER(?) LIMIT 1", [trim($code)]);
    }

    public function create($data) {
        return $this->db->insert(
            "INSERT INTO coupons (code, type, value, minPurchase, expiry, status, usageCount, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [
                strtoupper(trim($data['code'])),
                $data['type'] ?? 'percent',
                (float)($data['value'] ?? 0),
                (float)($data['minPurchase'] ?? 0),
                $data['expiry'] ?? date('Y-m-d', strtotime('+30 days')),
                $data['status'] ?? 'active',
                (int)($data['usageCount'] ?? 0),
                $data['description'] ?? '',
            ]
        );
    }

    public function update($id, $data) {
        $existing = $this->findById($id);
        if (!$existing) return null;

        $code = strtoupper(trim($data['code'] ?? $existing['code']));
        $type = $data['type'] ?? $existing['type'];
        $value = isset($data['value']) ? (float)$data['value'] : $existing['value'];
        $minPurchase = isset($data['minPurchase']) ? (float)$data['minPurchase'] : $existing['minPurchase'];
        $expiry = $data['expiry'] ?? $existing['expiry'];
        $status = $data['status'] ?? $existing['status'];
        $description = $data['description'] ?? $existing['description'];

        $this->db->execute(
            "UPDATE coupons SET code=?, type=?, value=?, minPurchase=?, expiry=?, status=?, description=? WHERE id=?",
            [$code, $type, $value, $minPurchase, $expiry, $status, $description, $id]
        );
        return $this->findById($id);
    }

    public function delete($id) {
        return $this->db->execute("DELETE FROM coupons WHERE id = ?", [$id]);
    }

    public function toggleStatus($id) {
        $c = $this->findById($id);
        if (!$c) return null;
        $newStatus = ($c['status'] === 'active') ? 'paused' : 'active';
        $this->db->execute("UPDATE coupons SET status = ? WHERE id = ?", [$newStatus, $id]);
        return $this->findById($id);
    }
}

<?php
/**
 * Feature Model (homepage banners)
 */
require_once __DIR__ . '/../config/database.php';

class FeatureModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function findAll() {
        return $this->db->fetchAll("SELECT * FROM features ORDER BY id DESC");
    }

    public function findById($id) {
        return $this->db->fetchOne(
            "SELECT * FROM features WHERE id = ? LIMIT 1",
            [$id]
        );
    }

    public function create($image) {
        return $this->db->insert(
            "INSERT INTO features (image) VALUES (?)",
            [$image]
        );
    }

    public function update($id, $image) {
        return $this->db->execute(
            "UPDATE features SET image = ? WHERE id = ?",
            [$image, $id]
        );
    }

    public function delete($id) {
        return $this->db->execute("DELETE FROM features WHERE id = ?", [$id]);
    }
}

<?php
/**
 * Cart Model (matches mongoose Cart.js schema + embedded items)
 */
require_once __DIR__ . '/../config/database.php';

class CartModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function findByUserId($userId) {
        return $this->db->fetchOne(
            "SELECT * FROM carts WHERE user_id = ? LIMIT 1",
            [$userId]
        );
    }

    public function create($userId) {
        return $this->db->insert(
            "INSERT INTO carts (user_id) VALUES (?)",
            [$userId]
        );
    }

    public function getOrCreateCart($userId) {
        $cart = $this->findByUserId($userId);
        if (!$cart) {
            $id = $this->create($userId);
            $cart = $this->db->fetchOne("SELECT * FROM carts WHERE id = ?", [$id]);
        }
        return $cart;
    }

    public function getItems($cartId) {
        return $this->db->fetchAll(
            "SELECT ci.*, p.image, p.title, p.price, p.salePrice
             FROM cart_items ci
             LEFT JOIN products p ON p.id = ci.product_id
             WHERE ci.cart_id = ?
             ORDER BY ci.id ASC",
            [$cartId]
        );
    }

    public function getPopulatedCart($userId) {
        $cart = $this->findByUserId($userId);
        if (!$cart) return null;
        $rawItems = $this->getItems($cart['id']);
        $validItems = [];
        foreach ($rawItems as $it) {
            if (!empty($it['title'])) {
                $validItems[] = [
                    'productId' => $it['product_id'],
                    'image'     => $it['image'],
                    'title'     => $it['title'],
                    'price'     => (float)$it['price'],
                    'salePrice' => (float)$it['salePrice'],
                    'quantity'  => (int)$it['quantity'],
                    'cartItemId'=> $it['id'],
                ];
            }
        }
        // Clean invalid items silently
        if (count($validItems) !== count($rawItems)) {
            foreach ($rawItems as $it) {
                if (empty($it['title'])) {
                    $this->db->execute("DELETE FROM cart_items WHERE id = ?", [$it['id']]);
                }
            }
        }
        return [
            '_id'      => $cart['id'],
            'id'       => $cart['id'],
            'userId'   => $cart['user_id'],
            'items'    => $validItems,
            'createdAt'=> $cart['created_at'],
            'updatedAt'=> $cart['updated_at'],
        ];
    }

    public function findCartItemIndex($cartId, $productId) {
        $row = $this->db->fetchOne(
            "SELECT id, quantity FROM cart_items WHERE cart_id = ? AND product_id = ? LIMIT 1",
            [$cartId, $productId]
        );
        return $row;
    }

    public function addItem($cartId, $productId, $quantity) {
        $existing = $this->findCartItemIndex($cartId, $productId);
        if ($existing) {
            $newQty = (int)$existing['quantity'] + (int)$quantity;
            $this->db->execute(
                "UPDATE cart_items SET quantity = ? WHERE id = ?",
                [$newQty, $existing['id']]
            );
        } else {
            $this->db->insert(
                "INSERT INTO cart_items (cart_id, product_id, quantity) VALUES (?, ?, ?)",
                [$cartId, $productId, $quantity]
            );
        }
    }

    public function updateItemQty($cartId, $productId, $quantity) {
        return $this->db->execute(
            "UPDATE cart_items SET quantity = ? WHERE cart_id = ? AND product_id = ?",
            [$quantity, $cartId, $productId]
        );
    }

    public function removeItem($cartId, $productId) {
        return $this->db->execute(
            "DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?",
            [$cartId, $productId]
        );
    }

    public function clearCart($cartId) {
        return $this->db->execute("DELETE FROM cart_items WHERE cart_id = ?", [$cartId]);
    }

    public function deleteCart($id) {
        return $this->db->execute("DELETE FROM carts WHERE id = ?", [$id]);
    }

    public function deleteCartByUser($userId) {
        return $this->db->execute("DELETE FROM carts WHERE user_id = ?", [$userId]);
    }
}

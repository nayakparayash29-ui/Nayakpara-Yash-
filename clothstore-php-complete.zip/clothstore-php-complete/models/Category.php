<?php
/**
 * Category & Brand Model
 * Handles categories and brands persistence and synchronization with products
 */
require_once __DIR__ . '/../config/database.php';

class CategoryModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->ensureTables();
    }

    private function ensureTables() {
        $this->db->query("CREATE TABLE IF NOT EXISTS categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL UNIQUE,
            icon VARCHAR(50) DEFAULT '📦',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $this->db->query("CREATE TABLE IF NOT EXISTS brands (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL UNIQUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Sync from products if tables are empty
        $catCnt = (int)$this->db->fetchOne("SELECT COUNT(*) AS c FROM categories")['c'];
        if ($catCnt === 0) {
            $icons = [
                'Men' => '👔', 'Women' => '👗', 'Kids' => '🧒', 'Footwear' => '👟',
                'Accessories' => '👜', 'Unisex' => '🧥', 'Shirts' => '👕', 'Pants' => '👖',
            ];
            $distinctCats = $this->db->fetchAll("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != ''");
            foreach ($distinctCats as $r) {
                $c = trim($r['category']);
                if ($c !== '') {
                    $ico = $icons[$c] ?? '📦';
                    $this->db->query("INSERT IGNORE INTO categories (name, icon) VALUES (?, ?)", [$c, $ico]);
                }
            }
        }

        $brandCnt = (int)$this->db->fetchOne("SELECT COUNT(*) AS c FROM brands")['c'];
        if ($brandCnt === 0) {
            $distinctBrands = $this->db->fetchAll("SELECT DISTINCT brand FROM products WHERE brand IS NOT NULL AND brand != ''");
            foreach ($distinctBrands as $r) {
                $b = trim($r['brand']);
                if ($b !== '') {
                    $this->db->query("INSERT IGNORE INTO brands (name) VALUES (?)", [$b]);
                }
            }
        }
    }

    public function getCategories() {
        $cats = $this->db->fetchAll("SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category = c.name) AS product_count FROM categories c ORDER BY c.name ASC");
        return $cats;
    }

    public function getBrands() {
        $brands = $this->db->fetchAll("SELECT b.*, (SELECT COUNT(*) FROM products p WHERE p.brand = b.name) AS product_count FROM brands b ORDER BY b.name ASC");
        return $brands;
    }

    public function addCategory($name, $icon = '📦') {
        $name = trim($name);
        if ($name === '') return null;
        $this->db->query("INSERT INTO categories (name, icon) VALUES (?, ?) ON DUPLICATE KEY UPDATE icon = VALUES(icon)", [$name, $icon]);
        return $this->db->fetchOne("SELECT * FROM categories WHERE name = ? LIMIT 1", [$name]);
    }

    public function renameCategory($oldName, $newName) {
        $oldName = trim($oldName);
        $newName = trim($newName);
        if ($oldName === '' || $newName === '') return false;
        // Update products with this category
        $this->db->execute("UPDATE products SET category = ? WHERE category = ?", [$newName, $oldName]);
        // Update category table
        $this->db->execute("UPDATE categories SET name = ? WHERE name = ?", [$newName, $oldName]);
        return true;
    }

    public function deleteCategory($name) {
        $name = trim($name);
        if ($name === '') return false;
        // Reassign affected products to Uncategorized
        $this->db->execute("UPDATE products SET category = 'Uncategorized' WHERE category = ?", [$name]);
        // Delete category
        $this->db->execute("DELETE FROM categories WHERE name = ?", [$name]);
        return true;
    }

    public function addBrand($name) {
        $name = trim($name);
        if ($name === '') return null;
        $this->db->query("INSERT IGNORE INTO brands (name) VALUES (?)", [$name]);
        return $this->db->fetchOne("SELECT * FROM brands WHERE name = ? LIMIT 1", [$name]);
    }

    public function renameBrand($oldName, $newName) {
        $oldName = trim($oldName);
        $newName = trim($newName);
        if ($oldName === '' || $newName === '') return false;
        // Update products with this brand
        $this->db->execute("UPDATE products SET brand = ? WHERE brand = ?", [$newName, $oldName]);
        // Update brand table
        $this->db->execute("UPDATE brands SET name = ? WHERE name = ?", [$newName, $oldName]);
        return true;
    }

    public function deleteBrand($name) {
        $name = trim($name);
        if ($name === '') return false;
        // Reassign affected products to Generic
        $this->db->execute("UPDATE products SET brand = 'Generic' WHERE brand = ?", [$name]);
        // Delete brand
        $this->db->execute("DELETE FROM brands WHERE name = ?", [$name]);
        return true;
    }
}

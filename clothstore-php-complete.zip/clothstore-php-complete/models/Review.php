<?php
/**
 * Review Model (matches mongoose Product Review schema)
 */
require_once __DIR__ . '/../config/database.php';

class ReviewModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function findByProduct($productId) {
        return $this->db->fetchAll(
            "SELECT r.*, u.email AS user_email
             FROM reviews r
             LEFT JOIN users u ON u.id = r.user_id
             WHERE r.product_id = ? ORDER BY r.created_at DESC",
            [$productId]
        );
    }

    public function findAll() {
        return $this->db->fetchAll(
            "SELECT r.*, p.title AS product_title, p.image AS product_image
             FROM reviews r
             LEFT JOIN products p ON p.id = r.product_id
             ORDER BY r.created_at DESC"
        );
    }

    public function findById($id) {
        return $this->db->fetchOne(
            "SELECT * FROM reviews WHERE id = ? LIMIT 1",
            [$id]
        );
    }

    public function create($data) {
        $id = $this->db->insert(
            "INSERT INTO reviews (product_id, user_id, userName, reviewMessage, reviewValue) VALUES (?, ?, ?, ?, ?)",
            [
                $data['productId']    ?? $data['product_id'],
                $data['userId']       ?? $data['user_id'],
                $data['userName']     ?? null,
                $data['reviewMessage'] ?? $data['review_message'] ?? null,
                $data['reviewValue']  ?? $data['review_value'] ?? 0,
            ]
        );
        // Update product average
        require_once __DIR__ . '/Product.php';
        $pm = new ProductModel();
        $pm->updateAverageReview($data['productId'] ?? $data['product_id']);
        return $id;
    }

    public function update($id, $data) {
        $fields = [];
        $params = [];
        $allowed = ['reviewMessage', 'reviewValue'];
        foreach ($allowed as $k) {
            if (array_key_exists($k, $data)) {
                $fields[] = "{$k} = ?";
                $params[] = $data[$k];
            }
        }
        if (empty($fields)) return 0;
        $params[] = $id;
        $res = $this->db->execute(
            "UPDATE reviews SET " . implode(', ', $fields) . " WHERE id = ?",
            $params
        );
        $review = $this->findById($id);
        if ($review) {
            require_once __DIR__ . '/Product.php';
            $pm = new ProductModel();
            $pm->updateAverageReview($review['product_id']);
        }
        return $res;
    }

    public function delete($id) {
        $review = $this->findById($id);
        $productId = $review ? $review['product_id'] : null;
        $res = $this->db->execute("DELETE FROM reviews WHERE id = ?", [$id]);
        if ($productId) {
            require_once __DIR__ . '/Product.php';
            $pm = new ProductModel();
            $pm->updateAverageReview($productId);
        }
        return $res;
    }

    public function countAll() {
        return (int)$this->db->fetchOne("SELECT COUNT(*) AS c FROM reviews")['c'];
    }
}

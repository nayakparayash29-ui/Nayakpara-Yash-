<?php
/**
 * Product Model (matches mongoose Product.js schema)
 */
require_once __DIR__ . '/../config/database.php';

class ProductModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function findAll($filters = [], $sortBy = 'price-lowtohigh') {
        $where = [];
        $params = [];
        if (!empty($filters['category'])) {
            $cats = is_array($filters['category']) ? $filters['category'] : explode(',', $filters['category']);
            $placeholders = implode(',', array_fill(0, count($cats), '?'));
            $where[] = "category IN ({$placeholders})";
            $params = array_merge($params, $cats);
        }
        if (!empty($filters['brand'])) {
            $brands = is_array($filters['brand']) ? $filters['brand'] : explode(',', $filters['brand']);
            $placeholders = implode(',', array_fill(0, count($brands), '?'));
            $where[] = "brand IN ({$placeholders})";
            $params = array_merge($params, $brands);
        }
        if (!empty($filters['search'])) {
            $where[] = "(title LIKE ? OR description LIKE ? OR category LIKE ? OR brand LIKE ?)";
            $s = '%' . $filters['search'] . '%';
            array_push($params, $s, $s, $s, $s);
        }

        $sortMap = [
            'price-lowtohigh' => 'ORDER BY CAST(price AS DECIMAL(10,2)) ASC',
            'price-hightolow' => 'ORDER BY CAST(price AS DECIMAL(10,2)) DESC',
            'title-atoz'      => 'ORDER BY title ASC',
            'title-ztoa'      => 'ORDER BY title DESC',
        ];
        $order = $sortMap[$sortBy] ?? $sortMap['price-lowtohigh'];

        $sql = "SELECT * FROM products";
        if (!empty($where)) $sql .= " WHERE " . implode(' AND ', $where);
        $sql .= " {$order}";

        return $this->db->fetchAll($sql, $params);
    }

    public function findById($id) {
        return $this->db->fetchOne(
            "SELECT * FROM products WHERE id = ? LIMIT 1",
            [$id]
        );
    }

    public function create($data) {
        return $this->db->insert(
            "INSERT INTO products (image, title, description, category, brand, price, salePrice, totalStock, averageReview)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [
                $data['image']         ?? null,
                $data['title']         ?? '',
                $data['description']   ?? '',
                $data['category']      ?? '',
                $data['brand']         ?? '',
                $data['price']         ?? 0,
                $data['salePrice']     ?? 0,
                $data['totalStock']    ?? 0,
                $data['averageReview'] ?? 0,
            ]
        );
    }

    public function update($id, $data) {
        $existing = $this->findById($id);
        if (!$existing) return null;

        $merged = array_merge($existing, array_filter($data, function($v) { return $v !== null && $v !== ''; }));
        // Handle zero values explicitly
        foreach (['price', 'salePrice', 'totalStock', 'averageReview'] as $k) {
            if (array_key_exists($k, $data) && $data[$k] !== '') {
                $merged[$k] = $data[$k];
            }
        }

        $this->db->execute(
            "UPDATE products SET image=?, title=?, description=?, category=?, brand=?, price=?, salePrice=?, totalStock=?, averageReview=? WHERE id=?",
            [
                $merged['image'],
                $merged['title'],
                $merged['description'],
                $merged['category'],
                $merged['brand'],
                $merged['price'],
                $merged['salePrice'],
                $merged['totalStock'],
                $merged['averageReview'],
                $id,
            ]
        );
        return $this->findById($id);
    }

    public function delete($id) {
        return $this->db->execute("DELETE FROM products WHERE id = ?", [$id]);
    }

    public function countAll() {
        return (int)$this->db->fetchOne("SELECT COUNT(*) AS c FROM products")['c'];
    }

    public function getDistinctCategories() {
        $rows = $this->db->fetchAll("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != '' ORDER BY category");
        return array_column($rows, 'category');
    }

    public function getDistinctBrands() {
        $rows = $this->db->fetchAll("SELECT DISTINCT brand FROM products WHERE brand IS NOT NULL AND brand != '' ORDER BY brand");
        return array_column($rows, 'brand');
    }

    public function getLowStock($threshold = 10) {
        return $this->db->fetchAll(
            "SELECT * FROM products WHERE totalStock <= ? ORDER BY totalStock ASC",
            [$threshold]
        );
    }

    public function getOutOfStock() {
        return $this->db->fetchAll("SELECT * FROM products WHERE totalStock = 0 ORDER BY title ASC");
    }

    public function updateAverageReview($productId) {
        $row = $this->db->fetchOne(
            "SELECT AVG(reviewValue) AS avg_r, COUNT(*) AS cnt FROM reviews WHERE product_id = ?",
            [$productId]
        );
        $avg = $row['cnt'] > 0 ? round($row['avg_r'], 2) : 0;
        $this->db->execute("UPDATE products SET averageReview = ? WHERE id = ?", [$avg, $productId]);
        return $avg;
    }
}

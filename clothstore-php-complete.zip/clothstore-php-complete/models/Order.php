<?php
/**
 * Order Model (matches mongoose Order.js schema)
 */
require_once __DIR__ . '/../config/database.php';

class OrderModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function create($data) {
        $pdo = $this->db->getConnection();
        try {
            $pdo->beginTransaction();
            $orderId = $this->db->insert(
                "INSERT INTO orders
                 (user_id, cart_id, orderStatus, paymentMethod, paymentStatus, totalAmount,
                  orderDate, orderUpdateDate, paymentId, payerId,
                  address_id, address, city, pincode, phone, notes)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [
                    $data['userId']           ?? null,
                    $data['cartId']           ?? null,
                    $data['orderStatus']      ?? 'pending',
                    $data['paymentMethod']    ?? null,
                    $data['paymentStatus']    ?? 'pending',
                    $data['totalAmount']      ?? 0,
                    $data['orderDate']        ?? date('Y-m-d H:i:s'),
                    $data['orderUpdateDate']  ?? date('Y-m-d H:i:s'),
                    $data['paymentId']        ?? null,
                    $data['payerId']          ?? null,
                    $data['addressInfo']['addressId'] ?? null,
                    $data['addressInfo']['address']   ?? null,
                    $data['addressInfo']['city']      ?? null,
                    $data['addressInfo']['pincode']   ?? null,
                    $data['addressInfo']['phone']     ?? null,
                    $data['addressInfo']['notes']     ?? null,
                ]
            );
            if (!empty($data['cartItems'])) {
                foreach ($data['cartItems'] as $item) {
                    $this->db->insert(
                        "INSERT INTO order_items (order_id, product_id, title, image, price, quantity)
                         VALUES (?, ?, ?, ?, ?, ?)",
                        [
                            $orderId,
                            $item['productId'] ?? null,
                            $item['title']     ?? '',
                            $item['image']     ?? null,
                            $item['price']     ?? 0,
                            $item['quantity']  ?? 1,
                        ]
                    );
                }
            }
            $pdo->commit();
            return $orderId;
        } catch (Exception $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    public function findById($id) {
        $order = $this->db->fetchOne("SELECT * FROM orders WHERE id = ?", [$id]);
        if (!$order) return null;
        return $this->hydrate($order);
    }

    public function findByUserId($userId) {
        $rows = $this->db->fetchAll(
            "SELECT * FROM orders WHERE user_id = ? ORDER BY orderDate DESC, id DESC",
            [$userId]
        );
        return array_map([$this, 'hydrate'], $rows);
    }

    public function findAll($status = null) {
        $sql = "SELECT o.*, u.userName AS customerName, u.email AS customerEmail
                FROM orders o
                LEFT JOIN users u ON u.id = o.user_id";
        $params = [];
        if ($status) {
            $sql .= " WHERE o.orderStatus = ?";
            $params[] = $status;
        }
        $sql .= " ORDER BY o.orderDate DESC, o.id DESC";
        $rows = $this->db->fetchAll($sql, $params);
        return array_map([$this, 'hydrate'], $rows);
    }

    private function hydrate($order) {
        $items = $this->db->fetchAll(
            "SELECT * FROM order_items WHERE order_id = ?",
            [$order['id']]
        );
        $cartItems = array_map(function($i) {
            return [
                'productId' => $i['product_id'],
                'title'     => $i['title'],
                'image'     => $i['image'],
                'price'     => (float)$i['price'],
                'quantity'  => (int)$i['quantity'],
            ];
        }, $items);

        return [
            '_id'             => (string)$order['id'],
            'id'              => $order['id'],
            'userId'          => (string)$order['user_id'],
            'customerName'    => $order['customerName'] ?? '',
            'customerEmail'   => $order['customerEmail'] ?? '',
            'cartId'          => $order['cart_id'] ? (string)$order['cart_id'] : null,
            'cartItems'       => $cartItems,
            'addressInfo'     => [
                'addressId' => $order['address_id'],
                'address'   => $order['address'],
                'city'      => $order['city'],
                'pincode'   => $order['pincode'],
                'phone'     => $order['phone'],
                'notes'     => $order['notes'],
            ],
            'orderStatus'     => $order['orderStatus'],
            'paymentMethod'   => $order['paymentMethod'],
            'paymentStatus'   => $order['paymentStatus'],
            'totalAmount'     => (float)$order['totalAmount'],
            'orderDate'       => $order['orderDate'],
            'orderUpdateDate' => $order['orderUpdateDate'],
            'paymentId'       => $order['paymentId'],
            'payerId'         => $order['payerId'],
            'createdAt'       => $order['created_at'],
            'updatedAt'       => $order['updated_at'],
        ];
    }

    public function update($id, $data) {
        $fields = [];
        $params = [];
        $allowed = ['orderStatus', 'paymentStatus', 'paymentMethod', 'totalAmount',
                    'orderUpdateDate', 'paymentId', 'payerId',
                    'address', 'city', 'pincode', 'phone', 'notes'];
        foreach ($allowed as $k) {
            if (array_key_exists($k, $data)) {
                $fields[] = "{$k} = ?";
                $params[] = $data[$k];
            }
        }
        if (empty($fields)) return $this->findById($id);
        $params[] = $id;
        $this->db->execute(
            "UPDATE orders SET " . implode(', ', $fields) . " WHERE id = ?",
            $params
        );
        return $this->findById($id);
    }

    public function countByStatus($status) {
        $row = $this->db->fetchOne(
            "SELECT COUNT(*) AS c FROM orders WHERE orderStatus = ?",
            [$status]
        );
        return (int)($row['c'] ?? 0);
    }

    public function totalRevenue() {
        $row = $this->db->fetchOne(
            "SELECT COALESCE(SUM(totalAmount), 0) AS total FROM orders WHERE paymentStatus = 'paid'"
        );
        return (float)($row['total'] ?? 0);
    }

    public function salesByDate($days = 30) {
        return $this->db->fetchAll(
            "SELECT DATE(orderDate) AS date, SUM(totalAmount) AS revenue, COUNT(*) AS cnt
             FROM orders WHERE paymentStatus = 'paid'
               AND orderDate >= DATE_SUB(NOW(), INTERVAL ? DAY)
             GROUP BY DATE(orderDate) ORDER BY date ASC",
            [$days]
        );
    }

    public function topSelling($limit = 5) {
        return $this->db->fetchAll(
            "SELECT oi.title, oi.image, SUM(oi.quantity) AS qty,
                    SUM(oi.price * oi.quantity) AS revenue
             FROM order_items oi
             INNER JOIN orders o ON o.id = oi.order_id
             WHERE o.paymentStatus = 'paid'
             GROUP BY oi.product_id, oi.title, oi.image
             ORDER BY qty DESC LIMIT ?",
            [$limit]
        );
    }

    public function delete($id) {
        return $this->db->execute("DELETE FROM orders WHERE id = ?", [$id]);
    }
}
